# VB-OS Python SDK — Setup Instructions

## Prerequisites

- Python >= 3.10
- pip

## Development Setup

```bash
# Clone the repository
git clone https://github.com/VB-OS/vb-os-python-sdk.git
cd vb-os-python-sdk

# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install with dev dependencies
pip install -e ".[dev]"
```

## Installing CLI

```bash
# Install SDK with CLI dependencies
pip install -e ".[cli]"

# Verify
vbos --version
```

## Running Tests

```bash
# All tests (SDK + CLI)
python -m pytest tests/ -v

# SDK core tests only
python -m pytest tests/test_*.py tests/contract/ -v

# CLI tests only
python -m pytest tests/cli/ -v

# With coverage
python -m pytest tests/ --cov=vbos --cov=vbos_cli --cov-report=term-missing

# Specific test file
python -m pytest tests/test_client.py -v

# Contract tests only
python -m pytest tests/contract/ -v
```

## Linting

```bash
# Check
ruff check vbos/ vbos_cli/ tests/

# Auto-fix
ruff check --fix vbos/ vbos_cli/ tests/
```

## Newman (Postman Contract Validation)

### Standalone SDK Collection

```bash
npx newman run postman/vb-os-python-sdk.postman_collection.json
```

Note: Standalone collection runs against `api.vb-os.org` — will DNS-error if not deployed.

### Cloud API Collection (S0049 Folder)

The primary SDK contract tests live in the cloud API's Postman collection under the "SDK Contract Validation (S0049)" folder. This folder self-bootstraps auth and validates the response schema the SDK's Pydantic models expect.

```bash
cd ../vb-os-cloud-api
npx newman run postman/vb-os-cloud-api.postman_collection.json --folder "SDK Contract Validation (S0049)"
```

This runs against `localhost:8000` (local API) and tests: ASSERT full schema, DEFER failure_reasons, 400/401 error schemas, 429 Retry-After header, x-request-id header presence.

## Usage

```python
from vbos import VBOSClient

# Sync client
with VBOSClient(api_key="your-api-key") as client:
    result = client.verify(
        workload={"amount": 5000, "currency": "USD"},
        boundary_ref="B_FIN_PAYMENT",
    )
    print(result.decision)  # ASSERT or DEFER
    print(result.replay_id)
    print(result.audit_artifact.sealed)
```

```python
from vbos import AsyncVBOSClient

# Async client
async with AsyncVBOSClient(api_key="your-api-key") as client:
    result = await client.verify(
        workload={"amount": 5000, "currency": "USD"},
        boundary_ref="B_FIN_PAYMENT",
    )
    print(result.decision)
```

## Error Handling

```python
from vbos import VBOSClient
from vbos.exceptions import (
    VBOSAuthenticationError,
    VBOSRateLimitError,
    VBOSValidationError,
)

with VBOSClient(api_key="your-api-key") as client:
    try:
        result = client.verify(workload={"amount": 5000})
    except VBOSAuthenticationError:
        print("Invalid API key")
    except VBOSRateLimitError as e:
        print(f"Rate limited. Retry after: {e.retry_after}s")
    except VBOSValidationError as e:
        print(f"Validation error: {e.message}")
        print(f"Details: {e.details}")
```

## CLI Usage

### Authentication (S0031)

```bash
# Interactive login
vbos login

# API key login (CI/CD)
vbos login --token vbos_dev_<key>

# Logout
vbos logout

# Configuration
vbos config set default-project myproject
vbos config set default-environment production
vbos config list

# Shell completions
vbos completions bash >> ~/.bashrc
vbos completions zsh >> ~/.zshrc
vbos completions fish > ~/.config/fish/completions/vbos.fish

# Profiles
vbos --profile staging login
VBOS_PROFILE=staging vbos config list

# Local mode (rejects cloud-only commands)
vbos --local config list
```

### Verification (S0032)

```bash
# Submit workload for verification (exit 0=ASSERT, 1=DEFER, 2=error)
vbos verify --project myproject --environment production --workload workload.json

# Batch verification
vbos verify --project myproject --environment production --workload batch.json --batch

# Local evaluation (requires vb-os binary)
vbos --local verify --workload workload.json --boundary B_FIN_PAYMENT

# Quiet mode (verdict only)
vbos verify --project myproject --environment production --workload workload.json --quiet

# Write output to file (0600 permissions)
vbos verify --project myproject --environment production --workload workload.json --output result.json

# Idempotent submission
vbos verify --project myproject --environment production --workload workload.json --idempotency-key "req-abc-123"
```

### Boundaries

```bash
# Create boundary from DSL file
vbos boundaries create --project myproject --name "Payment Check" --ref B_PAY --source boundary.vbos

# List / get / update / archive
vbos boundaries list --project myproject
vbos boundaries get BOUNDARY_ID --project myproject
vbos boundaries update BOUNDARY_ID --project myproject --name "New Name"
vbos boundaries archive BOUNDARY_ID --project myproject

# Compile / validate (no project scope)
vbos boundaries compile --source boundary.vbos
vbos boundaries validate --source boundary.vbos --workload workload.json

# Version management
vbos boundaries versions create BOUNDARY_ID --project myproject --source v2.vbos
vbos boundaries versions list BOUNDARY_ID --project myproject
vbos boundaries versions submit BOUNDARY_ID VERSION_ID --project myproject
vbos boundaries versions approve BOUNDARY_ID VERSION_ID --project myproject

# Diff and promote
vbos boundaries diff BOUNDARY_ID --project myproject --v1 VER1 --v2 VER2
vbos boundaries promote B_PAY --version VER_ID --environment staging --project myproject
```

### Projects / Environments / Keys

```bash
# Projects
vbos projects create --name "My Project" --workspace WS_ID
vbos projects list
vbos projects get PROJECT_ID
vbos projects delete PROJECT_ID --confirm

# Environments
vbos environments create --name staging --project myproject
vbos environments list --project myproject

# API keys
vbos keys create --name "CI Key" --project myproject --environment production
vbos keys list --project myproject --environment production
vbos keys rotate KEY_ID --project myproject --environment production
vbos keys revoke KEY_ID --project myproject --environment production --confirm
```

### Evaluations / Replay

```bash
# List evaluations with filters
vbos evaluations list --project myproject --decision DEFER --since 2026-01-01

# Get evaluation detail
vbos evaluations get EVAL_ID --project myproject

# Search evaluations
vbos evaluations search --project myproject --query "amount"

# Replay
vbos replay EVAL_ID --project myproject
```

### Connectors / Webhooks / Flows / Alert Rules

```bash
# Connectors
vbos connectors create --project myproject --provider npi --name "NPI Lookup" --config config.json
vbos connectors list --project myproject

# OAuth authorization (remote mode — opens browser, polls for completion)
vbos connectors authorize CONNECTOR_ID --project myproject
vbos connectors authorize CONNECTOR_ID --project myproject --no-browser

# OAuth disconnect
vbos connectors disconnect CONNECTOR_ID --project myproject --confirm

# OAuth reconnect (re-authorize with fresh tokens)
vbos connectors reconnect CONNECTOR_ID --project myproject

# OAuth status
vbos connectors status CONNECTOR_ID --project myproject

# Webhooks (project or org scope)
vbos webhooks create --project myproject --url https://example.com/hook --events evaluation.created
vbos webhooks rotate-secret WEBHOOK_ID --project myproject

# Flows
vbos flows create --project myproject --name "Payment Flow" --source flow.json
vbos flows deploy FLOW_ID --project myproject --environment production

# Alert rules
vbos alert-rules create --project myproject --config rule.json
```

### Organization / Members / Audit

```bash
# Organization
vbos org get
vbos org update --name "New Org Name"
vbos org settings get
vbos org settings update --setting replay_enabled=true

# Members
vbos members list
vbos members invite --email user@example.com --role member
vbos members role MEMBER_ID --role admin
vbos members suspend MEMBER_ID
vbos members reactivate MEMBER_ID

# Audit log
vbos audit-log list --since 2026-01-01 --until 2026-01-31
vbos audit-log export --since 2026-01-01
vbos audit-log export-status EXPORT_ID
```

### Other Commands

```bash
# Deployments
vbos deployments list --project myproject --environment production
vbos deployments active --project myproject --environment production
vbos deployments approve DEPLOYMENT_ID --project myproject --environment production
vbos deployments reject DEPLOYMENT_ID --project myproject --environment production

# Templates
vbos templates list
vbos templates get TEMPLATE_ID
vbos templates fork TEMPLATE_ID --project myproject --name "My Boundary"

# Certifications
vbos certify --project myproject --environment production --model MODEL_ID --evidence evidence.json
vbos certifications list --project myproject
vbos certifications get RUN_ID --project myproject
vbos certifications report RUN_ID --project myproject --output report.json
vbos certification-models list --project myproject
vbos certification-models create --project myproject --name "My Model" --config config.json

# Analytics
vbos analytics assertion-rate --project myproject

# Governed Workspaces
vbos governed-workspaces provision --name "GW-1" --config config.json
vbos governed-workspaces deploy GW_ID --boundary-ref B_PAY
vbos governed-workspaces seal GW_ID --confirm
vbos governed-workspaces teardown GW_ID --confirm

# Notifications
vbos notifications list
vbos notifications read NOTIFICATION_ID
vbos notifications unread NOTIFICATION_ID

# Account
vbos account delete --confirm
vbos account delete-status
vbos account export
vbos account export-status
```

### Global Options

```bash
# Output format
vbos --format table evaluations list --project myproject

# All commands support:
#   --output FILE    Write output to file (0600 permissions)
#   -q, --quiet      Minimal output (IDs or verdicts only)
#   --help           Command help

# Paginated commands support:
#   --limit N        Max results per page
#   --cursor TOKEN   Pagination cursor
#   --all            Auto-paginate all results

# Destructive commands require:
#   --confirm        Skip confirmation prompt (required in non-interactive/CI)
```

## Distribution Testing (S0050)

### Shell Installer

```bash
# Build local sdist
python -m build --sdist

# Test installer with local package (pipx branch)
VBOS_INSTALL_SOURCE=dist/vb_os-0.1.0.tar.gz ./scripts/install.sh

# Test installer with local package (venv branch — uninstall pipx-managed first)
pipx uninstall vb-os 2>/dev/null
VBOS_INSTALL_SOURCE=dist/vb_os-0.1.0.tar.gz ./scripts/install.sh

# Shellcheck
shellcheck scripts/install.sh
```

### Homebrew Formula Generation

```bash
# Build local sdist (if not already done)
python -m build --sdist

# Generate formula from local sdist
cd ../homebrew-tap
./scripts/generate-formula.sh --version 0.1.0 --local-sdist ../vb-os-python-sdk/dist/vb_os-0.1.0.tar.gz

# Validate
brew audit --new-formula Formula/vbos.rb
brew style Formula/vbos.rb
```

## Project Structure

```
vb-os-python-sdk/
├── vbos/                    # SDK core
│   ├── __init__.py
│   ├── _transport.py        # Shared HTTP helpers
│   ├── client.py            # VBOSClient + AsyncVBOSClient (27 namespaces)
│   ├── exceptions.py
│   ├── models.py            # ~80 Pydantic models (extra="ignore")
│   ├── retry.py
│   └── resources/           # 27 resource modules (S0043)
│       ├── __init__.py
│       ├── account.py
│       ├── alert_rules.py
│       ├── analytics.py
│       ├── audit_log.py
│       ├── billing.py
│       ├── boundaries.py
│       ├── certification_models.py
│       ├── certifications.py
│       ├── connector_providers.py
│       ├── connectors.py
│       ├── deployments.py
│       ├── environments.py
│       ├── flow_templates.py
│       ├── flows.py
│       ├── governed_workspaces.py
│       ├── keys.py
│       ├── members.py
│       ├── named_sets.py
│       ├── notifications.py
│       ├── org.py
│       ├── projects.py
│       ├── service_accounts.py
│       ├── templates.py
│       ├── users.py
│       ├── webhooks.py
│       └── workspaces.py
├── vbos_cli/                # CLI
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py               # Click group + 31 commands
│   ├── client.py            # Authenticated HTTP client
│   ├── config.py            # TOML config management
│   ├── errors.py            # CLI error hierarchy
│   ├── output.py            # Output formatting + VB-OS banner
│   ├── profiles.py          # Profile resolution
│   ├── formatters.py        # S0032 shared output/pagination/error infrastructure
│   ├── local_bridge.py      # S0032 local binary bridge (--local mode)
│   ├── commands/
│   │   ├── auth.py          # S0031: login, logout, resend-verification
│   │   ├── org.py           # S0031: switch-org
│   │   ├── config_cmd.py    # S0031: config set/get/list
│   │   ├── completions.py   # S0031: shell completions
│   │   ├── verify.py        # S0032: workload verification
│   │   ├── replay.py        # S0032: evaluation replay
│   │   ├── evaluations.py   # S0032: evaluation management
│   │   ├── boundaries.py    # S0032: boundary lifecycle + versions
│   │   ├── projects.py      # S0032: project management + members
│   │   ├── environments.py  # S0032: environment management
│   │   ├── keys.py          # S0032: API key management
│   │   ├── connectors.py    # S0032: connector management
│   │   ├── webhooks.py      # S0032: webhook management
│   │   ├── flows.py         # S0032: flow management + versions/executions
│   │   ├── alert_rules.py   # S0032: alert rule management
│   │   ├── deployments.py   # S0032: deployment management
│   │   ├── templates.py     # S0032: template management
│   │   ├── named_sets.py    # S0032: named set management
│   │   ├── org_mgmt.py      # S0032: organization management
│   │   ├── members.py       # S0032: member management
│   │   ├── workspaces.py    # S0032: workspace management
│   │   ├── audit_log.py     # S0032: audit log management
│   │   ├── certify.py       # S0032: certification management
│   │   ├── analytics.py     # S0032: analytics queries
│   │   ├── governed_workspaces.py  # S0032: governed workspaces
│   │   ├── notifications.py # S0032: notifications
│   │   └── account.py       # S0032: account management
│   └── credentials/
│       ├── store.py         # Credential abstraction
│       ├── keychain.py      # OS keychain store
│       ├── file.py          # Encrypted file store
│       └── migration.py     # Store migration
├── tests/
│   ├── cli/                 # CLI tests (543)
│   ├── contract/            # SDK contract tests (verify + per-resource)
│   ├── test_endpoint_manifest.py  # 180-row ledger + parity (364 tests)
│   ├── test_cross_cutting.py      # Forward compat, secrets, errors (93 tests)
│   └── test_*.py            # SDK core tests
├── scripts/
│   └── install.sh           # S0050: Shell installer (pipx/venv isolation)
├── docs/
│   ├── cli-developer-manual.md  # Developer reference (architecture, distribution, release)
│   └── cli-operator-manual.md   # Operator guide (install, auth, config, troubleshooting)
├── postman/
├── pyproject.toml
├── MANIFEST.md
├── SETUP.md
└── README.md
```
