# VB-OS CLI — Developer Manual

## 1. Architecture

The CLI is a Click-based command-line application distributed as part of the `vb-os` Python package. It authenticates against the VB-OS Cloud API and manages local credential lifecycle.

### Module Layout

```
vbos_cli/
├── cli.py              # Click group, global flags, CLIGroup, CloudOnlyCommand
├── client.py           # AuthenticatedClient — auth injection, refresh, retry
├── config.py           # TOML config at ~/.vbos/config
├── errors.py           # Typed error hierarchy (CLIError base)
├── output.py           # JSON/table/error output + VB-OS banner
├── profiles.py         # Profile resolution (flag > env > default)
├── commands/
│   ├── auth.py         # login, logout, resend-verification
│   ├── org.py          # switch-org
│   ├── config_cmd.py   # config set/get/list
│   └── completions.py  # bash/zsh/fish completion scripts
└── credentials/
    ├── store.py        # CredentialStore abstraction, dataclasses, resolve
    ├── keychain.py     # OS keychain backend (keyring library)
    ├── file.py         # Encrypted file backend (PBKDF2 + Fernet)
    └── migration.py    # Store migration (keychain <-> file)
```

### Entry Point

`pyproject.toml` declares `vbos = "vbos_cli.cli:main"` under `[project.scripts]`. The `main()` function calls `cli(standalone_mode=False)` and converts unhandled `CLIError` to structured JSON on stderr.

### Execution Mode

Two separate `--cloud` / `--local` flags with mutual exclusion validation. `--cloud` is the default. An `ExecutionMode` enum is stored in Click's context object and passed to all subcommands.

`CloudOnlyCommand` is a Click `Command` subclass that rejects `ExecutionMode.LOCAL` before any command logic runs — no network call, no credential-store operation. Used by: `login`, `logout`, `resend-verification`, `switch-org`.

### Output Contract

- Machine-readable JSON → stdout (default `--format json`)
- Human-readable tables → stdout (`--format table`)
- Interactive prompts, warnings, progress, errors → stderr
- Structured errors → stderr as `{"error": "<code>", "message": "<text>"}`
- VB-OS banner → stderr only, guarded by `sys.stderr.isatty()`

No credential value ever appears in stdout, stderr, exception messages, or tracebacks.

## 2. Authentication Flow

### Interactive Login

```
vbos login
  → prompt email (stdin) + password (getpass, non-echo, stderr)
  → POST /v1/auth/login {email, password, client_type: "cli"}
  → response branches:
     200 + tokens          → store SessionCredential, print banner
     200 + mfa_required    → _handle_mfa (TOTP prompt loop, max 5 attempts)
     200 + tos_required    → _handle_tos (acceptance prompt, POST /accept-tos)
     400 + org_selection   → _handle_multi_org (display list, prompt, re-login with org_id)
     403 + email_not_verified → CLIError exit 2
     403 + account_pending_deletion → CLIError exit 2
     429                   → CLIError with retry_after_seconds, exit 2
     401                   → CLIError "Invalid email or password", exit 2
```

### API Key Login

```
vbos login --token <key>
  → GET /v1/users/me with Authorization: Bearer <key>
  → 200 → store APIKeyCredential
  → 401 → CLIError exit 2
```

### MFA Recovery Fallback

During MFA TOTP prompt, user can enter `r` to switch to recovery code input. Recovery code is submitted to `POST /v1/auth/mfa/verify-recovery`. On success, session tokens are stored.

### Auth Resolution Precedence (Runtime)

```
VBOS_API_KEY env var → stored profile credential → None (unauthenticated)
```

`--token` is a `vbos login` subcommand flag that persists to the credential store. It is not a runtime auth source.

## 3. Credential Store

### Backend Selection

1. Check `credential-store` config key for the active profile
2. If `"file"` → FileStore
3. If `"keychain"` or unset → validate OS keyring backend → KeychainStore
4. If no supported backend → error with instructions

### FileStore Internals

- **Location:** `~/.vbos/credentials` (single file, all profiles)
- **Key derivation:** PBKDF2-HMAC-SHA256, 600,000 iterations, 16-byte random salt
- **Encryption:** Fernet (AES-128-CBC + HMAC-SHA256)
- **File format:** `FILE_VERSION (2 bytes) || salt (16 bytes) || Fernet ciphertext`
- **Permissions:** 0600 from creation (via `os.fchmod` on temp file before data is written)
- **Atomicity:** write to temp file → `fsync` → `os.replace`. Crash at any point leaves either old valid file or new valid file. Temp file cleaned up in `finally` block.
- **Profile sections:** JSON dict with profile names as keys, encrypted as a single blob
- **Passphrase:** prompted on every invocation via `getpass`. Never cached to disk, env, or between processes.

### KeychainStore Internals

- **Service name:** `vbos-cli/{profile}`
- **Backend validation:** only macOS Keychain, Windows Credential Manager, or Linux Secret Service accepted. Plaintext/null backends rejected.

### Credential Types

Two discriminated dataclasses:

- `SessionCredential(kind="session", access_token, refresh_token)` — JWT-based, subject to refresh
- `APIKeyCredential(kind="api_key", api_key)` — bypasses JWT decode and refresh entirely

### Migration

`migrate_credentials(source, destination)`: read → write → readback verify → delete source.

- Verify failure before config switch → source preserved, migration aborted
- Delete failure after successful config switch → destination remains authoritative, security warning emitted, source retains stale copy

## 4. Token Refresh Lifecycle

### Pre-Request Refresh

`AuthenticatedClient._ensure_auth()` checks JWT `exp` claim locally (non-authoritative, for scheduling only). If expired (with 30-second leeway) or malformed/missing `exp`, calls `_refresh_session()` before transmitting the application request.

### Refresh Mechanics

```
POST /v1/auth/refresh
  Authorization: Bearer <refresh_token>
  → 200 → new SessionCredential stored, old tokens replaced
  → 401 → credentials deleted, SessionExpiredError raised
```

### Persistence Failure After Refresh

If `store.store()` fails after successful server-side rotation:
1. Attempt `store.delete()` to prevent stale-token retention
2. If delete also fails → CredentialStoreError with cleanup warning
3. If delete succeeds → CredentialStoreError with "session cleared" message
4. Credential store never retains a `kind: session` entry with a revoked refresh token

### Post-Request 401

A 401 received after request transmission does NOT trigger refresh or replay. It is surfaced as `AuthenticationError`. This prevents unauthorized request amplification.

## 5. Retry Behavior

- **GET/HEAD:** retried up to 3 times on 5xx with exponential backoff (2^attempt seconds). 429 retries with `Retry-After` header value (capped at 30s).
- **POST/PATCH/DELETE:** never retried. Single attempt, error surfaced immediately.

## 6. Error Hierarchy

```
CLIError (exit_code: int)
├── AuthenticationError (exit_code=2)
│   ├── SessionExpiredError
│   └── APIKeyInvalidError
├── CredentialStoreError (exit_code=2)
└── UnsupportedInLocalModeError (exit_code=2)
```

`CLIGroup.invoke()` catches `CLIError` and converts to structured JSON on stderr with `ctx.exit(e.exit_code)`. It also catches `httpx.ConnectError` (unreachable API) and `httpx.TimeoutException` (request timeout), converting them to structured JSON errors with exit code 2. This prevents raw tracebacks from leaking to users when the API endpoint is misconfigured or unreachable.

## 7. Backend Session Model (client_type Discriminator)

The `client_type` field on login requests determines session behavior:

| Property | `client_type: "cli"` | `client_type: "console"` |
|----------|---------------------|------------------------|
| Refresh token expiry | 30 days | 7 days |
| Refresh token delivery | Response body | HttpOnly cookie |
| Set-Cookie header | Never emitted | Always emitted |
| Refresh token source | Authorization: Bearer header | Cookie |

The discriminator is:
- Set by CLI at login time in the request body
- Embedded in MFA tokens (server-signed JWT claim)
- Carried through MFA verify and MFA recovery endpoints
- Used by `_build_session_response()` to determine delivery channel
- Stored as `NOT NULL DEFAULT 'console'` with `CHECK` constraint on the token family table

## 8. Distribution

### 8.1 Package Structure

The CLI is distributed as part of the `vb-os` Python package via the `[cli]` optional dependency group. `pip install "vb-os[cli]"` installs the SDK plus CLI dependencies (click, keyring, cryptography, tomli_w).

### 8.2 Distribution Channels

| Channel | Command | Status |
|---------|---------|--------|
| pip | `pip install "vb-os[cli]"` | Available after PyPI publication |
| Homebrew | `brew install VB-OS/tap/vbos` | Available after PyPI publication + formula generation |
| Shell installer | `curl -fsSL https://get.vb-os.org/cli \| sh` | Available after PyPI publication + hosting infrastructure |

### 8.3 Homebrew Formula Generation

Formulae are generated from published releases using `homebrew-tap/scripts/generate-formula.sh`. The generator resolves all recursive Python dependencies from the exact package being formulaized, producing a `Language::Python::Virtualenv` formula with checksummed `resource` blocks.

**Pre-publication testing (local sdist):**

```bash
cd vb-os-python-sdk
python -m build --sdist
cd ../homebrew-tap
./scripts/generate-formula.sh --version 0.1.0 --local-sdist ../vb-os-python-sdk/dist/vb_os-0.1.0.tar.gz
brew audit --new-formula Formula/vbos.rb
brew style Formula/vbos.rb
```

**Release (published package):**

```bash
./scripts/generate-formula.sh \
  --version 0.1.0 \
  --url "https://files.pythonhosted.org/packages/.../vb_os-0.1.0.tar.gz" \
  --sha256 "<sha256>"
brew audit --new-formula Formula/vbos.rb
brew style Formula/vbos.rb
brew install --build-from-source Formula/vbos.rb
brew test Formula/vbos.rb
git add Formula/vbos.rb && git commit -m "vbos 0.1.0" && git push
```

Dependencies are resolved from the sdist itself, never from a potentially stale PyPI copy. Modifying the source archive or SHA produces a deterministic generation failure.

### 8.4 Shell Installer Architecture

`scripts/install.sh` provides isolated CLI installation without requiring users to manage Python environments.

**Isolation strategy:** The installer never runs `pip install` into system or Homebrew-managed Python (PEP 668). It uses:
1. `pipx` if available (fresh install only)
2. Dedicated venv at `~/.vbos/venv` with symlink to `~/.local/bin/vbos`

**Ownership persistence:** On rerun, the installer detects the existing installation mechanism and upgrades via the same method. If pipx managed the install, pipx upgrades it. If venv managed it, venv upgrades it. The installer never silently migrates between mechanisms even if pipx becomes available after a venv install.

**Conflicting executable detection:** If an unrelated `vbos` executable exists on PATH (not managed by this installer), the installer warns and aborts rather than silently shadowing it.

**Local testing via `VBOS_INSTALL_SOURCE`:**

```bash
python -m build --sdist
VBOS_INSTALL_SOURCE=dist/vb_os-0.1.0.tar.gz ./scripts/install.sh
```

This environment variable overrides the package source for the install step. All other logic (OS detection, Python version check, pipx/venv selection, PATH verification) runs identically.

### 8.5 Release Sequence

```
1. Version bump in pyproject.toml
2. Build sdist: python -m build --sdist
3. Pre-publication formula test: generate-formula.sh --local-sdist
4. Pre-publication installer test: VBOS_INSTALL_SOURCE=dist/... install.sh
5. Publish to PyPI: twine upload dist/*
6. Generate release formula: generate-formula.sh --version --url --sha256
7. Validate: brew audit + brew style + brew install + brew test
8. Commit formula to homebrew-tap
9. Upload install.sh to hosting (when infrastructure available)
```

### 8.6 Rollback

| Failure | Recovery |
|---------|----------|
| Bad formula pushed | Revert commit in homebrew-tap, regenerate from correct version |
| Bad PyPI release | `pip install vb-os==<previous>`, regenerate formula for previous version |
| Installer script broken | Revert in vb-os-python-sdk, redeploy to hosting |
| Homebrew tap corrupted | Delete and recreate from latest known-good formula |

### 8.7 Infrastructure Dependencies

The shell installer at `get.vb-os.org` requires:
- S3 bucket for static hosting
- CloudFront distribution
- Route53 CNAME: `get.vb-os.org` → CloudFront
- ACM certificate

This infrastructure is provisioned separately from the distribution artifacts.

## 9. Test Procedure (S0031/S0032)

```bash
# CLI tests only (111 tests)
python -m pytest tests/cli/ -v

# Full SDK suite (209 tests)
python -m pytest tests/ -v

# Lint
ruff check vbos_cli/ tests/cli/

# Backend identity tests (413 tests, from vb-os-cloud-api)
python -m pytest tests/unit/identity/ -v
```

### Test Categories

- **Unit tests** (`test_cli.py`, `test_auth.py`, `test_credentials.py`, `test_client.py`, `test_output.py`, `test_profiles.py`, `test_completions.py`, `test_config.py`): isolated component behavior with mocked dependencies
- **Integration tests** (`test_integration.py`): end-to-end CLI flows with mocked HTTP, exercising the full Click → command → client → store chain
- **Backend tests** (`test_cli_session_support.py`, `test_session_service.py`): server-side client_type handling, transport invariants, MFA binding

## 9. Security Constraints

1. **No credential in output:** tokens, API keys, and passphrases never appear in stdout, stderr, exception `.args`, error JSON, or HTTP debug output.
2. **No credential in config:** `~/.vbos/config` contains only non-secret metadata (project, environment, org, credential-store type, API URL, email).
3. **Passphrase never persisted:** file store passphrase is prompted via `getpass` on every invocation. No caching between processes.
4. **Atomic writes:** both `~/.vbos/credentials` and `~/.vbos/config` use temp file → fsync → rename. Temp files get 0600 permissions before secret data is written.
5. **No post-401 replay:** prevents unauthorized request amplification after server-side token revocation.
6. **Local JWT decode for scheduling only:** no authorization, role, or identity decisions from unverified local JWT claims.
7. **Kind discriminator:** prevents API-key credentials from being JWT-decoded or triggering refresh.

## 10. Command Reference (S0032)

S0032 adds 23 command groups (~180 commands) covering every Cloud API operation.

### Module Layout (commands/)

```
commands/
├── verify.py             # vbos verify (core evaluation)
├── replay.py             # vbos replay (deterministic replay)
├── evaluations.py        # vbos evaluations list|get|search|export|share|replay-analysis
├── boundaries.py         # vbos boundaries create|list|get|update|archive|compile|validate|diff|promote + versions subgroup
├── projects.py           # vbos projects create|list|get|update|archive
├── environments.py       # vbos environments create|list|get|update|archive
├── keys.py               # vbos keys create|list|get|revoke
├── connectors.py         # vbos connectors create|list|get|update|delete|test|sync
├── webhooks.py           # vbos webhooks create|list|get|update|delete|test|rotate-secret|deliveries|retry
├── flows.py              # vbos flows create|list|get|update|delete|run|versions
├── alert-rules.py        # vbos alert-rules create|list|get|update|delete|test
├── deployments.py        # vbos deployments list|get|active|rollback|approve|reject
├── templates.py          # vbos templates list|get|fork
├── named_sets.py         # vbos named-sets create|list|get|update|delete
├── org_mgmt.py           # vbos org get|update + settings get|update
├── members.py            # vbos members list|invite|role|remove|suspend|reactivate
├── workspaces.py         # vbos workspaces list|get|create|update|archive
├── audit_log.py          # vbos audit-log list|export|export-status
├── certify.py            # vbos certify (standalone) + certifications list|get|report|revoke + certification-models create|list|get|update|delete
├── analytics.py          # vbos analytics assertion-rate
├── governed_workspaces.py # vbos governed-workspaces provision|list|get|deploy|evaluate|seal|teardown
├── notifications.py      # vbos notifications list|read|unread
└── account.py            # vbos account delete|delete-status|delete-cancel|export|export-status
```

### Cross-Cutting Patterns

All commands follow shared infrastructure from `formatters.py`:

| Pattern | Implementation |
|---------|---------------|
| Output modes | `--format json\|table`, `--quiet`, `--output <file>` via `add_output_options` |
| Pagination | `--limit`, `--cursor`, `--all` via `add_pagination_options` with cursor loop detection |
| Destructive ops | `--confirm` flag via `add_confirm_option` / `confirm_destructive()` |
| Project resolution | `--project` flag → `~/.vbos/config` default → error with hint |
| Environment resolution | `--environment` flag → `~/.vbos/config` default → error with hint |
| Client lifecycle | `make_client(ctx)` in try/finally with `client.close()` |
| Error handling | `handle_api_error()` parses structured error and exits 2 |
| File permissions | All `--output` files written with 0600 via `_atomic_write()` |
| Secret output | `format_secret()` for key/webhook secret commands |

### Exit Codes

| Code | Meaning | When |
|------|---------|------|
| 0 | ASSERT / success | Evaluation passed, or command succeeded |
| 1 | DEFER | `vbos verify` only — evaluation deferred |
| 2 | Error | Auth failure, API error, validation error, missing config |

### Semantic Verify Exit

`vbos verify` is the only command that uses exit code 1 (DEFER). All other commands use 0 (success) or 2 (error). The `--batch` flag checks all results and exits 1 if any individual result is DEFER.

### Local Bridge

`vbos verify --local` invokes the local `vb-os` binary via `local_bridge.py`. The bridge:
- Finds the binary via `VBOS_BINARY_PATH` env var or `~/.vbos/bin/vb-os`
- Constructs A-INPUT-001 bundles
- Maps binary ACCEPT/REJECT → ASSERT/DEFER
- Provides SemanticVerifyResult parity (verdict, admissibility, predicate_outcomes, prohibitions)

`--batch` and `--local` are mutually exclusive.

### Test Procedure

```bash
# S0032 CLI tests (543 tests)
python -m pytest tests/cli/ -v

# Full SDK suite
python -m pytest tests/ -v

# Lint
ruff check vbos_cli/ tests/cli/

# Command registration verification
python -m pytest tests/cli/test_command_registration.py -v
```

### Test Files

Each command module has a corresponding test file:

```
tests/cli/
├── test_command_registration.py  # All 29 commands registered
├── test_verify.py
├── test_replay.py
├── test_evaluations.py
├── test_boundaries.py
├── test_projects.py
├── test_environments.py
├── test_keys.py
├── test_connectors.py
├── test_webhooks.py
├── test_flows.py
├── test_alert_rules.py
├── test_deployments.py
├── test_templates.py
├── test_named_sets.py
├── test_org_mgmt.py
├── test_members.py
├── test_workspaces.py
├── test_audit_log.py
├── test_certify.py
├── test_analytics.py
├── test_governed_workspaces.py
├── test_notifications.py
└── test_account.py
```

### Mock Pattern

Tests mock `make_client` at the import location in each command module:

```python
from unittest.mock import patch, MagicMock

CMD_MODULE = "vbos_cli.commands.projects"

with patch(f"{CMD_MODULE}.make_client", return_value=mock_client):
    result = runner.invoke(cli, ["projects", "list"])
```

Patch at `vbos_cli.commands.<module>.make_client`, not at the source in `formatters.py`.
8. **Cloud-only gate:** authentication commands are rejected in `--local` mode before any network or credential-store operation.
