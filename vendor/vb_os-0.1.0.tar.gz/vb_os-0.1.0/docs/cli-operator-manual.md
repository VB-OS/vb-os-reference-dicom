# VB-OS CLI — Operator Manual

## 1. Installation

The VB-OS CLI is distributed as part of the `vb-os` Python package. Three installation methods are available.

**Requirements:** Python >= 3.10

### pip (Direct)

```bash
pip install "vb-os[cli]"
vbos --version
```

Installs into the active Python environment. On systems with PEP 668 externally-managed Python (modern macOS, Ubuntu 23.04+), use a virtual environment or pipx instead of global pip.

### Homebrew (macOS / Linux)

```bash
brew install VB-OS/tap/vbos
vbos --version
```

Installs into an isolated Homebrew-managed virtualenv. Dependencies are pinned and checksummed. Requires the `VB-OS/tap` Homebrew tap (added automatically by the install command).

### Shell Installer

```bash
curl -fsSL https://get.vb-os.org/cli | sh
```

Automatically detects and uses the best isolation strategy:
- If `pipx` is available: installs via pipx
- Otherwise: creates an isolated venv at `~/.vbos/venv` and symlinks `vbos` to `~/.local/bin/vbos`

The installer never runs `pip install` into system Python. It is safe to pipe to `sh`.

### From Source (Development)

```bash
git clone https://github.com/VB-OS/vb-os-python-sdk.git
cd vb-os-python-sdk
pip install -e ".[cli]"
vbos --version
```

## 2. Authentication

### Interactive Login

```bash
vbos login
```

Prompts for email and password. Password input is non-echoing (never displayed on screen).

On success, the VB-OS logo is displayed and session credentials are stored in the configured credential store.

### API Key Login (CI/CD)

```bash
vbos login --token vbos_dev_<key>
```

Validates the API key against the server and stores it locally. No interactive prompts. Suitable for CI/CD pipelines and automated scripts.

### Organization Selection

If your account belongs to multiple organizations, login displays a numbered list:

```
Multiple organizations found. Select one:
  1. Acme Corp (ADMIN)
  2. Beta Inc (MEMBER)
Selection (number): 
```

To bypass the interactive selector:

```bash
vbos login --org <org_id>
```

### Switching Organizations

```bash
vbos switch-org <org_id>
```

Creates a new session under the specified organization without re-entering credentials.

### Environment Variable Authentication

```bash
export VBOS_API_KEY=vbos_dev_<key>
vbos <any command>
```

When `VBOS_API_KEY` is set, the CLI uses it for all API requests without requiring `vbos login`. This takes precedence over any stored credentials.

### Auth Precedence

| Priority | Source | Notes |
|----------|--------|-------|
| 1 (highest) | `VBOS_API_KEY` env var | Runtime auth, no login required |
| 2 | Stored profile credential | Set by `vbos login` or `vbos login --token` |

## 3. Multi-Factor Authentication (MFA)

If MFA is enabled on your account, login prompts for a TOTP code after password:

```
TOTP code: ******
```

You have up to 5 attempts. To use a recovery code instead, enter `r` when prompted:

```
Code or 'r': r
Recovery code: <your-recovery-code>
```

## 4. Logout

```bash
vbos logout
```

Behavior depends on the active credential source:

| Credential Type | Action |
|----------------|--------|
| Session (from `vbos login`) | Server-side revocation via POST /auth/logout, then local deletion |
| API key (from `vbos login --token`) | Local deletion only (API key lifecycle is a separate admin operation) |
| `VBOS_API_KEY` env var | Prints guidance to `unset VBOS_API_KEY` |

If the server is unreachable during session logout, local credentials are still deleted. A warning is displayed about the unconfirmed server-side revocation.

## 5. Credential Storage

### OS Keychain (Default)

The CLI attempts the OS credential store first:
- **macOS:** Keychain
- **Windows:** Credential Manager
- **Linux:** Secret Service (GNOME Keyring / KDE Wallet)

Unsupported or plaintext backends are rejected.

### Encrypted File Store

If the OS keychain is unavailable or you prefer file-based storage:

```bash
vbos config set credential-store file
```

You will be prompted for a passphrase on first use (with confirmation). The passphrase is prompted on every subsequent CLI invocation that requires credentials — it is never cached to disk, environment variables, or between processes.

**Encryption:** PBKDF2-HMAC-SHA256 (600,000 iterations) key derivation + Fernet (AES-128-CBC + HMAC-SHA256) encryption.

**Location:** `~/.vbos/credentials` with 0600 permissions.

### Migrating Between Stores

Changing the `credential-store` config triggers automatic migration of existing credentials. The migration follows a safe sequence: read from old → write to new → verify readback → switch config → delete old. If verification fails, the original store is preserved.

## 6. Profiles

Profiles provide isolated credentials and configuration for different environments.

```bash
# Login to a staging profile
vbos --profile staging login

# Use staging profile for a command
vbos --profile staging config list

# Set via environment variable
export VBOS_PROFILE=staging
vbos config list
```

**Resolution order:** `--profile` flag > `VBOS_PROFILE` env var > `"default"`

Each profile has independent credentials and configuration. Deleting one profile's credentials does not affect others.

## 7. Configuration

```bash
# Set values
vbos config set default-project myproject
vbos config set default-environment production
vbos config set default-org org-abc123

# View current configuration
vbos config list

# Read a single value
vbos config get default-project
```

**Valid keys:** `default-project`, `default-environment`, `default-org`, `credential-store`, `api-url`, `email`

Configuration is stored in `~/.vbos/config` (TOML format). This file never contains credentials — only non-secret metadata.

## 8. Execution Modes

```bash
vbos --cloud <command>    # Cloud mode (default)
vbos --local <command>    # Local mode
```

- `--cloud` connects to the VB-OS Cloud API for authentication and verification.
- `--local` runs against a local SRB binary without Cloud credentials.
- `--cloud` and `--local` are mutually exclusive. Passing both exits with an error.

In `--local` mode, authentication commands (`login`, `logout`, `resend-verification`, `switch-org`) are rejected with exit code 2 because local execution does not use Cloud credentials. Configuration and completion commands work in both modes.

## 9. Output Formats

```bash
# JSON (default) — machine-readable, suitable for piping
vbos config list --format json

# Table — human-readable
vbos config list --format table
```

**Output routing:**

| Content | Destination |
|---------|-------------|
| Command results (JSON/table) | stdout |
| Prompts, warnings, progress | stderr |
| Errors | stderr (structured JSON) |
| VB-OS banner (on login) | stderr (TTY only) |

This means `vbos login 2>/dev/null` produces clean JSON on stdout without interleaved prompts or branding.

## 10. Shell Completions

```bash
# Bash
vbos completions bash >> ~/.bashrc

# Zsh
vbos completions zsh >> ~/.zshrc

# Fish
vbos completions fish > ~/.config/fish/completions/vbos.fish
```

Restart your shell or source the file to activate completions.

## 11. Email Verification

If your email is not verified:

```bash
vbos resend-verification
```

Prompts for your email and sends a verification email. You must verify before logging in.

## 12. Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error |
| 2 | Authentication failure, credential error, unsupported mode, rate limit, or usage error |

## 13. Security Guidance

### Credentials Are Never Exposed

- Passwords and TOTP codes use non-echoing input (not displayed on screen)
- No credential value (token, API key, passphrase) appears in CLI output, error messages, or log files
- The config file (`~/.vbos/config`) contains only non-secret metadata

### File Permissions

- `~/.vbos/` directory: 0700 (owner only)
- `~/.vbos/credentials`: 0600 (owner read/write only)
- `~/.vbos/config`: 0600 (owner read/write only)
- Temporary files during writes: 0600 from creation, before any data is written

### Token Refresh

The CLI automatically refreshes expired access tokens before making API requests. If the refresh token itself is expired or revoked, local credentials are deleted and you are prompted to re-authenticate. The CLI never retains a session with a known-revoked refresh token.

### API Key Best Practices

- Use `VBOS_API_KEY` for CI/CD rather than `vbos login --token` to avoid persisting keys in the credential store
- API keys are not JWT-decoded or refreshed — they are passed directly as Bearer tokens
- Rotate API keys through the VB-OS Cloud console, not through the CLI

### Account States

| Server Response | CLI Behavior |
|----------------|-------------|
| Email not verified (403) | Error with instructions to run `vbos resend-verification` |
| Account pending deletion (403) | Error with instructions to contact support |
| Account locked (429) | Error showing retry-after duration, no auto-retry |
| Terms of Service update required | Acceptance prompt before login completes |

## 14. Upgrading

### pip

```bash
pip install --upgrade "vb-os[cli]"
```

### Homebrew

```bash
brew upgrade vbos
```

### Shell Installer

Re-running the installer upgrades the existing installation via the same mechanism that was used originally. The installer detects whether the prior install used pipx or venv and upgrades in-place — it never silently switches mechanisms.

```bash
curl -fsSL https://get.vb-os.org/cli | sh
```

### Migrating Between Installation Methods

To switch from one installation method to another:

1. Uninstall via the current method:
   - pip: `pip uninstall vb-os`
   - Homebrew: `brew uninstall vbos`
   - Shell installer (pipx): `pipx uninstall vb-os`
   - Shell installer (venv): `rm -rf ~/.vbos/venv && rm ~/.local/bin/vbos`
2. Install via the new method

Do not run multiple installation methods simultaneously — this creates conflicting `vbos` executables on PATH.

## 15. PATH Troubleshooting

If `vbos` is not found after installation:

| Shell | Add to config file |
|-------|-------------------|
| zsh | `echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc` |
| bash | `echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc` |
| fish | `echo 'set -gx PATH $HOME/.local/bin $PATH' >> ~/.config/fish/config.fish` |

Restart your shell or `source` the config file after updating.

### Verifying Installation

```bash
which vbos        # Shows the executable path
vbos --version    # Shows the installed version
```

### Multiple Installations

If `which vbos` points to an unexpected location, check for conflicting installations:

```bash
which -a vbos     # Lists all vbos executables on PATH
```

Remove any unintended installations before proceeding.
