#!/usr/bin/env bash
set -euo pipefail

# VB-OS CLI installer
# Installs the vbos CLI into an isolated Python environment.
# Safe to pipe: curl -fsSL https://get.vb-os.org/cli | sh

VBOS_MIN_PYTHON="3.10"
VBOS_INSTALL_DIR="${VBOS_INSTALL_DIR:-$HOME/.vbos}"
VBOS_VENV_DIR="$VBOS_INSTALL_DIR/venv"
VBOS_BIN_DIR="${VBOS_BIN_DIR:-$HOME/.local/bin}"
VBOS_PACKAGE="${VBOS_INSTALL_SOURCE:-vb-os[cli]}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BOLD='\033[1m'
RESET='\033[0m'

info()  { printf "${GREEN}▸${RESET} %s\n" "$*"; }
warn()  { printf "${YELLOW}▸${RESET} %s\n" "$*" >&2; }
error() { printf "${RED}✗${RESET} %s\n" "$*" >&2; }
fatal() { error "$@"; exit 1; }

detect_os() {
  case "$(uname -s)" in
    Darwin) OS="macos" ;;
    Linux)  OS="linux" ;;
    *)      fatal "Unsupported operating system: $(uname -s). VB-OS CLI supports macOS and Linux." ;;
  esac
}

version_gte() {
  printf '%s\n%s' "$1" "$2" | sort -t. -k1,1n -k2,2n -k3,3n -C
}

find_python() {
  PYTHON=""
  for candidate in python3.14 python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$candidate" >/dev/null 2>&1; then
      ver=$("$candidate" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || echo "0.0")
      if version_gte "$VBOS_MIN_PYTHON" "$ver"; then
        PYTHON="$candidate"
        PYTHON_VERSION="$ver"
        return 0
      fi
    fi
  done

  if [[ -z "$PYTHON" ]]; then
    fatal "Python >= $VBOS_MIN_PYTHON is required but not found.
  Install Python:
    macOS:  brew install python@3.12
    Ubuntu: sudo apt install python3.12 python3.12-venv
    Fedora: sudo dnf install python3.12"
  fi
}

detect_existing_install() {
  INSTALL_METHOD=""

  if command -v vbos >/dev/null 2>&1; then
    EXISTING_VBOS="$(command -v vbos)"

    if command -v pipx >/dev/null 2>&1; then
      if pipx list 2>/dev/null | grep -q "vb-os\|vbos"; then
        INSTALL_METHOD="pipx"
        info "Existing pipx-managed VB-OS installation detected"
        return 0
      fi
    fi

    if [[ -L "$EXISTING_VBOS" ]]; then
      link_target="$(readlink "$EXISTING_VBOS" 2>/dev/null || true)"
      if echo "$link_target" | grep -q "$VBOS_VENV_DIR"; then
        INSTALL_METHOD="venv"
        info "Existing venv-managed VB-OS installation detected at $VBOS_VENV_DIR"
        return 0
      fi
    fi

    if [[ -d "$VBOS_VENV_DIR" ]] && "$VBOS_VENV_DIR/bin/vbos" --version >/dev/null 2>&1; then
      INSTALL_METHOD="venv"
      info "Existing venv-managed VB-OS installation detected at $VBOS_VENV_DIR"
      return 0
    fi

    fatal "A 'vbos' executable already exists at $EXISTING_VBOS but was not installed by this installer.
  Remove or rename the conflicting executable before running this installer.
  Conflicting path: $EXISTING_VBOS"
  fi

  if [[ -d "$VBOS_VENV_DIR" ]] && [[ -f "$VBOS_VENV_DIR/bin/python" ]]; then
    INSTALL_METHOD="venv"
    info "Existing venv found at $VBOS_VENV_DIR (vbos not on PATH)"
    return 0
  fi
}

install_pipx() {
  info "Installing vb-os[cli] via pipx..."
  if [[ "$VBOS_PACKAGE" == "vb-os[cli]" ]]; then
    pipx install "vb-os[cli]"
  else
    pipx install "${VBOS_PACKAGE}[cli]" 2>/dev/null || pipx install "$VBOS_PACKAGE"
  fi
}

upgrade_pipx() {
  info "Upgrading vb-os[cli] via pipx..."
  pipx upgrade vb-os 2>/dev/null || pipx install --force "vb-os[cli]"
}

install_venv() {
  info "Creating isolated environment at $VBOS_VENV_DIR..."
  mkdir -p "$VBOS_INSTALL_DIR"
  "$PYTHON" -m venv "$VBOS_VENV_DIR"
  "$VBOS_VENV_DIR/bin/pip" install --quiet --upgrade pip
  info "Installing vb-os[cli] into isolated environment..."
  if [[ "$VBOS_PACKAGE" == "vb-os[cli]" ]]; then
    "$VBOS_VENV_DIR/bin/pip" install "vb-os[cli]"
  else
    "$VBOS_VENV_DIR/bin/pip" install "${VBOS_PACKAGE}[cli]" 2>/dev/null || "$VBOS_VENV_DIR/bin/pip" install "$VBOS_PACKAGE"
  fi
}

upgrade_venv() {
  info "Upgrading vb-os[cli] in existing environment..."
  "$VBOS_VENV_DIR/bin/pip" install --quiet --upgrade pip
  if [[ "$VBOS_PACKAGE" == "vb-os[cli]" ]]; then
    "$VBOS_VENV_DIR/bin/pip" install --upgrade "vb-os[cli]"
  else
    "$VBOS_VENV_DIR/bin/pip" install --upgrade "${VBOS_PACKAGE}[cli]" 2>/dev/null || "$VBOS_VENV_DIR/bin/pip" install --upgrade "$VBOS_PACKAGE"
  fi
}

create_symlink() {
  if ! mkdir -p "$VBOS_BIN_DIR" 2>/dev/null; then
    fatal "Cannot create directory: $VBOS_BIN_DIR
  Check permissions or set VBOS_BIN_DIR to a writable location."
  fi

  ln -sf "$VBOS_VENV_DIR/bin/vbos" "$VBOS_BIN_DIR/vbos"
  info "Symlinked vbos → $VBOS_BIN_DIR/vbos"
}

check_path() {
  if ! command -v vbos >/dev/null 2>&1; then
    warn "vbos is not on your PATH."
    echo ""
    case "$SHELL" in
      */zsh)
        echo "  Add to ~/.zshrc:"
        echo "    export PATH=\"$VBOS_BIN_DIR:\$PATH\""
        ;;
      */bash)
        echo "  Add to ~/.bashrc:"
        echo "    export PATH=\"$VBOS_BIN_DIR:\$PATH\""
        ;;
      */fish)
        echo "  Add to ~/.config/fish/config.fish:"
        echo "    set -gx PATH $VBOS_BIN_DIR \$PATH"
        ;;
      *)
        echo "  Add $VBOS_BIN_DIR to your PATH."
        ;;
    esac
    echo ""
    echo "  Then restart your shell or run: source ~/.$(basename "$SHELL")rc"
    return 1
  fi
  return 0
}

verify_install() {
  local vbos_bin=""

  if command -v vbos >/dev/null 2>&1; then
    vbos_bin="vbos"
  elif [[ -f "$VBOS_BIN_DIR/vbos" ]]; then
    vbos_bin="$VBOS_BIN_DIR/vbos"
  elif [[ -f "$VBOS_VENV_DIR/bin/vbos" ]]; then
    vbos_bin="$VBOS_VENV_DIR/bin/vbos"
  fi

  if [[ -z "$vbos_bin" ]]; then
    fatal "Installation completed but vbos executable not found."
  fi

  local version_output
  version_output=$("$vbos_bin" --version 2>&1) || fatal "vbos --version failed"
  info "Installed: $version_output"
}

main() {
  echo ""
  printf '%b%s%b\n' "$BOLD" "VB-OS CLI Installer" "$RESET"
  echo ""

  detect_os
  info "Detected OS: $OS"

  find_python
  info "Using Python $PYTHON_VERSION ($PYTHON)"

  detect_existing_install

  case "$INSTALL_METHOD" in
    pipx)
      upgrade_pipx
      ;;
    venv)
      upgrade_venv
      create_symlink
      ;;
    "")
      if command -v pipx >/dev/null 2>&1; then
        install_pipx
      else
        install_venv
        create_symlink
      fi
      ;;
  esac

  echo ""
  verify_install

  if ! check_path; then
    warn "After updating PATH, verify with: vbos --version"
  fi

  echo ""
  info "Next step: vbos login"
  echo ""
}

main "$@"
