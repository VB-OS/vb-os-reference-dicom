"""Shared fixtures for CLI command tests."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import pytest
from click.testing import CliRunner

from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


def make_response(
    status_code: int = 200,
    json_body: Any = None,
) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_body if json_body is not None else {}
    resp.text = json.dumps(json_body) if json_body is not None else ""
    resp.headers = {}
    return resp


def make_mock_client(
    get_resp=None,
    post_resp=None,
    patch_resp=None,
    put_resp=None,
    delete_resp=None,
):
    client = MagicMock()
    default = make_response(200, {"id": "test-id"})
    client.get.return_value = get_resp or default
    client.post.return_value = post_resp or default
    client.patch.return_value = patch_resp or default
    client.put.return_value = put_resp or default
    client.delete.return_value = delete_resp or default
    client.close = MagicMock()
    return client


def invoke_cmd(runner, args, mock_client=None, cmd_module=None, input_text=None):
    """Invoke CLI with a mocked client.

    Patches make_client in the specified command module (e.g. 'vbos_cli.commands.projects').
    """
    mc = mock_client or make_mock_client()
    patch_target = f"{cmd_module}.make_client" if cmd_module else "vbos_cli.formatters.make_client"
    with patch(patch_target, return_value=mc):
        result = runner.invoke(cli, args, input=input_text)
    return result, mc


PAGINATED_RESPONSE = {
    "items": [{"id": f"item-{i}"} for i in range(3)],
    "cursor": None,
    "has_more": False,
}

ERROR_401 = make_response(401, {"error": "unauthorized", "message": "Invalid credentials"})
ERROR_403 = make_response(403, {"error": "forbidden", "message": "Insufficient permissions"})
ERROR_404 = make_response(404, {"error": "not_found", "message": "Resource not found"})
ERROR_422 = make_response(422, {"error": "validation_error", "message": "Invalid input"})
