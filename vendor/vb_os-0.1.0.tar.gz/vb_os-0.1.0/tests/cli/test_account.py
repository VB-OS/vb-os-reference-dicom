"""Tests for account CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.account"


@pytest.fixture
def runner():
    return CliRunner()


class TestAccountDelete:
    def test_delete_with_confirm(self, runner) -> None:
        body = {"status": "pending", "scheduled_at": "2026-09-28T00:00:00Z"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "delete", "--confirm"])
        assert result.exit_code == 0
        mc.post.assert_called_once()
        assert "/v1/auth/account/delete" in mc.post.call_args[0][0]
        mc.close.assert_called_once()

    def test_delete_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(cli, ["account", "delete"], input="n\n")
        mc.post.assert_not_called()

    def test_delete_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(409, {"error": "conflict"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "delete", "--confirm"])
        assert result.exit_code == 2


class TestAccountDeleteStatus:
    def test_delete_status_success(self, runner) -> None:
        body = {"status": "pending", "scheduled_at": "2026-09-28T00:00:00Z"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "delete-status"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        assert "/v1/auth/account/deletion-status" in mc.get.call_args[0][0]
        mc.close.assert_called_once()

    def test_delete_status_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(401, {"error": "unauthorized"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "delete-status"])
        assert result.exit_code == 2


class TestAccountDeleteCancel:
    def test_delete_cancel_success(self, runner) -> None:
        body = {"status": "cancelled"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "delete-cancel"])
        assert result.exit_code == 0
        mc.post.assert_called_once()
        assert "/v1/auth/account/delete/cancel" in mc.post.call_args[0][0]
        mc.close.assert_called_once()


class TestAccountExport:
    def test_export_success(self, runner) -> None:
        body = {"id": "export-1", "status": "processing"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "export"])
        assert result.exit_code == 0
        mc.post.assert_called_once()
        assert "/v1/auth/account/export" in mc.post.call_args[0][0]
        mc.close.assert_called_once()

    def test_export_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(429, {"error": "rate_limited"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "export"])
        assert result.exit_code == 2


class TestAccountExportStatus:
    def test_export_status_latest(self, runner) -> None:
        body = {"id": "export-1", "status": "complete", "url": "https://example.com/export.zip"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "export-status"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        assert "/v1/auth/account/export/latest" in mc.get.call_args[0][0]
        mc.close.assert_called_once()

    def test_export_status_by_id(self, runner) -> None:
        body = {"id": "export-42", "status": "complete"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["account", "export-status", "--export-id", "export-42"]
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        assert "/v1/auth/account/export/export-42" in mc.get.call_args[0][0]

    def test_export_status_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["account", "export-status"])
        assert result.exit_code == 2
