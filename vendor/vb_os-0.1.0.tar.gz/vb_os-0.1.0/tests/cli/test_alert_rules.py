"""Tests for alert-rules CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.alert_rules"


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def config_file(tmp_path):
    """Create a temporary JSON config file for alert rules."""
    path = tmp_path / "alert_config.json"
    path.write_text(
        json.dumps(
            {
                "name": "high-failure-rate",
                "condition": {"metric": "failure_rate", "threshold": 10},
                "channels": ["email"],
            }
        )
    )
    return str(path)


class TestAlertRulesCreate:
    def test_create_success(self, runner, config_file) -> None:
        resp = make_response(201, {"id": "rule-1", "name": "high-failure-rate"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "create",
                    "--project",
                    "proj-1",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/alert-rules" in call_args[0][0]
        payload = call_args[1]["json"]
        assert payload["name"] == "high-failure-rate"
        assert payload["condition"]["metric"] == "failure_rate"

    def test_create_reads_config_file(self, runner, config_file) -> None:
        resp = make_response(201, {"id": "rule-1"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "create",
                    "--project",
                    "proj-1",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        payload = mc.post.call_args[1]["json"]
        assert payload["channels"] == ["email"]

    def test_create_api_error(self, runner, config_file) -> None:
        mc = make_mock_client(post_resp=make_response(422, {"error": "validation_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "create",
                    "--project",
                    "proj-1",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 2

    def test_create_closes_client(self, runner, config_file) -> None:
        mc = make_mock_client(post_resp=make_response(201, {"id": "r1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "alert-rules",
                    "create",
                    "--project",
                    "p",
                    "--config",
                    config_file,
                ],
            )
        mc.close.assert_called_once()


class TestAlertRulesList:
    def test_list_success(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "rule-1"}, {"id": "rule-2"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/alert-rules" in mc.get.call_args[0][0]

    def test_list_with_limit(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "rule-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "list",
                    "--project",
                    "p",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("limit") == 5

    def test_list_with_cursor(self, runner) -> None:
        resp = make_response(200, {"items": []})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "list",
                    "--project",
                    "p",
                    "--cursor",
                    "next-page",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("cursor") == "next-page"

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(500, {"error": "internal"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestAlertRulesGet:
    def test_get_success(self, runner) -> None:
        resp = make_response(200, {"id": "rule-1", "name": "my-rule"})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "get",
                    "rule-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/alert-rules/rule-1" in mc.get.call_args[0][0]

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "get",
                    "bad-id",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestAlertRulesUpdate:
    def test_update_uses_put(self, runner, config_file) -> None:
        resp = make_response(200, {"id": "rule-1", "updated": True})
        mc = make_mock_client(put_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "update",
                    "rule-1",
                    "--project",
                    "proj-1",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        mc.put.assert_called_once()
        call_args = mc.put.call_args
        assert "/v1/projects/proj-1/alert-rules/rule-1" in call_args[0][0]

    def test_update_sends_config_payload(self, runner, config_file) -> None:
        resp = make_response(200, {"id": "rule-1"})
        mc = make_mock_client(put_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "update",
                    "rule-1",
                    "--project",
                    "p",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        payload = mc.put.call_args[1]["json"]
        assert payload["name"] == "high-failure-rate"
        assert payload["condition"]["threshold"] == 10

    def test_update_api_error(self, runner, config_file) -> None:
        mc = make_mock_client(put_resp=make_response(400, {"error": "bad_request"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "update",
                    "rule-1",
                    "--project",
                    "p",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 2


class TestAlertRulesDelete:
    def test_delete_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "delete",
                    "rule-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()
        assert "/v1/projects/proj-1/alert-rules/rule-1" in mc.delete.call_args[0][0]

    def test_delete_requires_confirm_in_non_interactive(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "delete",
                    "rule-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2
        assert "confirmation_required" in result.output or "--confirm" in result.output

    def test_delete_200_response(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(200, {"id": "rule-1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "delete",
                    "rule-1",
                    "--project",
                    "p",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0

    def test_delete_api_error(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(403, {"error": "forbidden"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "alert-rules",
                    "delete",
                    "rule-1",
                    "--project",
                    "p",
                    "--confirm",
                ],
            )
        assert result.exit_code == 2
