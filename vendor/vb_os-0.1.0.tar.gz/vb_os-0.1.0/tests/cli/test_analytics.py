from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.analytics"


@pytest.fixture
def runner():
    return CliRunner()


class TestAssertionRate:
    def test_success(self, runner) -> None:
        body = {"assertion_rate": 0.92, "total_evaluations": 500}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                ["analytics", "assertion-rate", "--project", "proj"],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_with_date_range(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "analytics",
                    "assertion-rate",
                    "--project",
                    "proj",
                    "--since",
                    "2025-01-01",
                    "--until",
                    "2025-01-31",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args
        assert call_kwargs[1]["params"]["since"] == "2025-01-01"
        assert call_kwargs[1]["params"]["until"] == "2025-01-31"

    def test_with_environment_filter(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "analytics",
                    "assertion-rate",
                    "--project",
                    "proj",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args
        assert call_kwargs[1]["params"]["environment"] == "production"

    def test_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(500, {"error": "server_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                ["analytics", "assertion-rate", "--project", "proj"],
            )
        assert result.exit_code != 0
        mc.close.assert_called_once()
