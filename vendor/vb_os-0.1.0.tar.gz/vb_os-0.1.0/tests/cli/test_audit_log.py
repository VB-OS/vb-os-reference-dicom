"""Tests for audit-log CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.audit_log"


@pytest.fixture
def runner():
    return CliRunner()


class TestAuditLogList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "al-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["audit-log", "list"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_list_with_filters(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {"items": []}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "audit-log",
                    "list",
                    "--since",
                    "2025-01-01T00:00:00Z",
                    "--until",
                    "2025-01-31T23:59:59Z",
                    "--actor",
                    "user-1",
                    "--action",
                    "deployment.create",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args
        params = call_kwargs[1]["params"]
        assert params["since"] == "2025-01-01T00:00:00Z"
        assert params["until"] == "2025-01-31T23:59:59Z"
        assert params["actor"] == "user-1"
        assert params["action"] == "deployment.create"

    def test_list_with_limit(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {"items": []}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["audit-log", "list", "--limit", "25"])
        assert result.exit_code == 0


class TestAuditLogExport:
    def test_export_success(self, runner) -> None:
        body = {"export_id": "exp-1", "status": "pending"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "audit-log",
                    "export",
                    "--since",
                    "2025-01-01T00:00:00Z",
                    "--until",
                    "2025-01-31T23:59:59Z",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["since"] == "2025-01-01T00:00:00Z"
        assert call_args[1]["json_body"]["until"] == "2025-01-31T23:59:59Z"

    def test_export_missing_since(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                ["audit-log", "export", "--until", "2025-01-31T23:59:59Z"],
            )
        assert result.exit_code != 0


class TestAuditLogExportStatus:
    def test_export_status_success(self, runner) -> None:
        body = {"export_id": "exp-1", "status": "complete", "url": "https://storage.example.com/exp-1.json"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["audit-log", "export-status", "exp-1"])
        assert result.exit_code == 0
        assert "exp-1" in result.output
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_export_status_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["audit-log", "export-status", "exp-999"])
        assert result.exit_code == 2
