"""Tests for login/logout/resend-verification commands."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from vbos_cli.cli import cli
from vbos_cli.credentials.store import APIKeyCredential, SessionCredential


class TestLoginAPIKey:
    def test_valid_api_key_stores_credential(self) -> None:
        runner = CliRunner()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"email": "user@test.com", "id": "uid"}
        mock_resp.headers = {}

        with patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient:
            instance = MockClient.return_value
            instance.get.return_value = mock_resp
            instance.close = MagicMock()

            with patch("vbos_cli.commands.auth.CredentialStore") as MockStore:
                store_instance = MockStore.return_value

                runner.invoke(cli, ["login", "--token", "vbos_dev_abc123"])

                store_instance.store.assert_called_once()
                stored = store_instance.store.call_args[0][0]
                assert isinstance(stored, APIKeyCredential)
                assert stored.api_key == "vbos_dev_abc123"

    def test_invalid_api_key_exits_2(self) -> None:
        runner = CliRunner()
        mock_resp = MagicMock()
        mock_resp.status_code = 401

        with patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient:
            instance = MockClient.return_value
            instance.get.return_value = mock_resp
            instance.close = MagicMock()

            result = runner.invoke(cli, ["login", "--token", "vbos_bad"])
            assert result.exit_code == 2


class TestLogoutSession:
    def test_session_logout_calls_server(self) -> None:
        runner = CliRunner()
        cred = SessionCredential(kind="session", access_token="acc", refresh_token="ref")

        mock_resp = MagicMock()
        mock_resp.status_code = 200

        with (
            patch("vbos_cli.commands.auth.resolve_credential", return_value=cred),
            patch("vbos_cli.commands.auth.CredentialStore") as MockStore,
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = mock_resp
            client_inst.close = MagicMock()
            store_inst = MockStore.return_value

            result = runner.invoke(cli, ["logout"])

            assert result.exit_code == 0
            client_inst.post.assert_called_once()
            store_inst.delete.assert_called_once()

    def test_logout_network_failure_still_clears_local(self) -> None:
        runner = CliRunner()
        cred = SessionCredential(kind="session", access_token="acc", refresh_token="ref")

        with (
            patch("vbos_cli.commands.auth.resolve_credential", return_value=cred),
            patch("vbos_cli.commands.auth.CredentialStore") as MockStore,
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
        ):
            client_inst = MockClient.return_value
            client_inst.post.side_effect = ConnectionError("no network")
            client_inst.close = MagicMock()
            store_inst = MockStore.return_value

            result = runner.invoke(cli, ["logout"])

            assert result.exit_code == 0
            store_inst.delete.assert_called_once()
            assert "could not be confirmed" in result.output


class TestLogoutAPIKey:
    def test_api_key_logout_no_server_call(self) -> None:
        runner = CliRunner()
        cred = APIKeyCredential(kind="api_key", api_key="vbos_dev_test")

        with (
            patch("vbos_cli.commands.auth.resolve_credential", return_value=cred),
            patch("vbos_cli.commands.auth.CredentialStore") as MockStore,
            patch.dict("os.environ", {}, clear=False),
        ):
            import os

            os.environ.pop("VBOS_API_KEY", None)
            store_inst = MockStore.return_value

            result = runner.invoke(cli, ["logout"])

            assert result.exit_code == 0
            store_inst.delete.assert_called_once()


class TestLogoutEnvVar:
    def test_env_var_logout_prints_guidance(self) -> None:
        runner = CliRunner()

        with patch.dict("os.environ", {"VBOS_API_KEY": "vbos_dev_env"}):
            with patch("vbos_cli.commands.auth.resolve_credential", return_value=None):
                result = runner.invoke(cli, ["logout"])
                assert result.exit_code == 0
                assert "VBOS_API_KEY" in result.output

    def test_no_credentials_at_all(self) -> None:
        runner = CliRunner()

        with patch.dict("os.environ", {}, clear=False):
            import os

            os.environ.pop("VBOS_API_KEY", None)
            with patch("vbos_cli.commands.auth.resolve_credential", return_value=None):
                result = runner.invoke(cli, ["logout"])
                assert result.exit_code == 0
                assert "No stored credentials" in result.output


class TestMFARecovery:
    """AC-18: MFA recovery code fallback."""

    def test_recovery_code_stores_session(self) -> None:
        runner = CliRunner()
        login_resp = MagicMock()
        login_resp.status_code = 200
        login_resp.json.return_value = {"mfa_required": True, "mfa_token": "mfa.tok"}
        login_resp.headers = {}

        recovery_resp = MagicMock()
        recovery_resp.status_code = 200
        recovery_resp.json.return_value = {
            "access_token": "rec.access",
            "refresh_token": "rec.refresh",
        }

        # getpass calls: password, TOTP code, "Code or 'r'" choice, recovery code
        getpass_calls = iter(["secret", "123456", "r", "RECOVERY-CODE-123"])

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", side_effect=getpass_calls),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            totp_fail = MagicMock()
            totp_fail.status_code = 403
            totp_fail.json.return_value = {"error": "invalid_code", "message": "bad"}
            totp_fail.text = "bad"

            client_inst = MockClient.return_value
            client_inst.post.side_effect = [login_resp, totp_fail, recovery_resp]
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 0

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert isinstance(stored, SessionCredential)
            assert stored.access_token == "rec.access"

            recovery_call = client_inst.post.call_args_list[2]
            assert recovery_call[0][0] == "/v1/auth/mfa/verify-recovery"
            assert recovery_call[1]["json_body"]["recovery_code"] == "RECOVERY-CODE-123"


class TestMFAMaxAttempts:
    """UT-S0031-22: 5 failed TOTP codes → exit 2, no sixth attempt, no credentials stored."""

    def test_five_failures_exits_2(self) -> None:
        runner = CliRunner()
        login_resp = MagicMock()
        login_resp.status_code = 200
        login_resp.json.return_value = {"mfa_required": True, "mfa_token": "mfa.tok"}
        login_resp.headers = {}

        totp_fail = MagicMock()
        totp_fail.status_code = 403
        totp_fail.json.return_value = {"error": "invalid_code", "message": "bad"}
        totp_fail.text = "bad"

        # password, then 5 rounds: TOTP code + (for first 4) "Code or 'r'" answer
        # Round 1: "111111" (TOTP), "222222" (not 'r' → next attempt)
        # Round 2: "333333" (TOTP), "444444" (not 'r')
        # Round 3: "555555" (TOTP), "666666" (not 'r')
        # Round 4: "777777" (TOTP), "888888" (not 'r')
        # Round 5: "999999" (TOTP) → no prompt, raises CLIError
        getpass_calls = iter(
            [
                "secret",  # password
                "111111",
                "n",  # attempt 1 + retry choice
                "222222",
                "n",  # attempt 2 + retry choice
                "333333",
                "n",  # attempt 3 + retry choice
                "444444",
                "n",  # attempt 4 + retry choice
                "555555",  # attempt 5 (no retry prompt)
            ]
        )

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", side_effect=getpass_calls),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            # login response + 5 TOTP failures (no 6th)
            client_inst.post.side_effect = [login_resp] + [totp_fail] * 5
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 2
            assert "too many failed" in result.output.lower()

            # Exactly 6 POST calls: 1 login + 5 TOTP attempts (no 6th verify)
            assert client_inst.post.call_count == 6

            # No credentials stored
            store_inst.store.assert_not_called()


class TestOrgBypass:
    """AC-20: --org bypasses interactive org selection."""

    def test_org_flag_sends_org_id_directly(self) -> None:
        runner = CliRunner()
        login_resp = MagicMock()
        login_resp.status_code = 200
        login_resp.json.return_value = {"access_token": "acc", "refresh_token": "ref"}
        login_resp.headers = {}

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = login_resp
            client_inst.close = MagicMock()
            MockCredStore.return_value

            result = runner.invoke(cli, ["login", "--org", "org-direct-123"])
            assert result.exit_code == 0

            login_call = client_inst.post.call_args_list[0]
            body = login_call[1]["json_body"]
            assert body["org_id"] == "org-direct-123"


class TestSwitchOrg:
    """AC-25: switch-org stores new session."""

    def test_switch_org_stores_new_tokens(self) -> None:
        runner = CliRunner()
        switch_resp = MagicMock()
        switch_resp.status_code = 200
        switch_resp.json.return_value = {"access_token": "new.acc", "refresh_token": "new.ref"}

        with (
            patch("vbos_cli.commands.org.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.org.CredentialStore") as MockStore,
            patch("vbos_cli.commands.org.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = switch_resp
            client_inst.close = MagicMock()
            store_inst = MockStore.return_value

            result = runner.invoke(cli, ["switch-org", "org-new-456"])
            assert result.exit_code == 0

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert isinstance(stored, SessionCredential)
            assert stored.access_token == "new.acc"


class TestSwitchOrgInteractive:
    """UT-S0031-25: switch-org without arg fetches orgs and prompts."""

    def test_interactive_org_selection(self) -> None:
        runner = CliRunner()

        org_list_resp = MagicMock()
        org_list_resp.status_code = 200
        org_list_resp.json.return_value = [
            {"org_id": "org-aaa", "org_name": "Acme Corp", "org_role": "ADMIN"},
            {"org_id": "org-bbb", "org_name": "Beta Inc", "org_role": "MEMBER"},
        ]

        switch_resp = MagicMock()
        switch_resp.status_code = 200
        switch_resp.json.return_value = {"access_token": "sw.acc", "refresh_token": "sw.ref"}

        input_calls = iter(["1"])

        with (
            patch("vbos_cli.commands.org.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.org.CredentialStore") as MockStore,
            patch("vbos_cli.commands.org.cfg") as mock_cfg,
            patch("builtins.input", side_effect=input_calls),
        ):
            mock_cfg.get_api_url.return_value = "http://localhost:8000"
            client_inst = MockClient.return_value
            client_inst.get.return_value = org_list_resp
            client_inst.post.return_value = switch_resp
            client_inst.close = MagicMock()
            store_inst = MockStore.return_value

            result = runner.invoke(cli, ["switch-org"])
            assert result.exit_code == 0

            client_inst.get.assert_called_once_with("/v1/users/me/organizations")
            client_inst.post.assert_called_once()
            switch_call = client_inst.post.call_args
            assert switch_call[1]["json_body"]["org_id"] == "org-aaa"

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert stored.access_token == "sw.acc"


class TestTOSAcceptance:
    """AC-31: TOS update required during login."""

    def test_tos_prompt_accepts_and_stores(self) -> None:
        runner = CliRunner()
        login_resp = MagicMock()
        login_resp.status_code = 200
        login_resp.json.return_value = {
            "tos_update_required": True,
            "tos_version": "2.0",
            "tos_url": "https://vb-os.org/tos",
            "access_token": "tos.acc",
            "refresh_token": "tos.ref",
        }
        login_resp.headers = {}

        tos_resp = MagicMock()
        tos_resp.status_code = 200

        input_calls = iter(["user@test.com", "y"])

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", side_effect=input_calls),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.side_effect = [login_resp, tos_resp]
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 0

            tos_call = client_inst.post.call_args_list[1]
            assert tos_call[0][0] == "/v1/auth/accept-tos"
            store_inst.store.assert_called_once()

    def test_tos_rejected_exits_2(self) -> None:
        runner = CliRunner()
        login_resp = MagicMock()
        login_resp.status_code = 200
        login_resp.json.return_value = {
            "tos_update_required": True,
            "tos_version": "2.0",
            "access_token": "a",
            "refresh_token": "r",
        }
        login_resp.headers = {}

        input_calls = iter(["user@test.com", "n"])

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore"),
            patch("builtins.input", side_effect=input_calls),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = login_resp
            client_inst.close = MagicMock()

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 2


class TestAccountLockout:
    """AC-32: 429 lockout displays retry_after and exits 2."""

    def test_lockout_shows_retry_after(self) -> None:
        runner = CliRunner()
        lockout_resp = MagicMock()
        lockout_resp.status_code = 429
        lockout_resp.json.return_value = {"retry_after_seconds": 300}
        lockout_resp.text = json.dumps({"retry_after_seconds": 300})

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore"),
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = lockout_resp
            client_inst.close = MagicMock()

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 2
            assert "300" in result.output


class TestPendingDeletion:
    """UT-S0031-32: PENDING_DELETION 403 handled gracefully."""

    def test_pending_deletion_shows_message(self) -> None:
        runner = CliRunner()
        resp = MagicMock()
        resp.status_code = 403
        resp.json.return_value = {
            "error": "account_pending_deletion",
            "message": "Account pending deletion",
        }
        resp.text = json.dumps(resp.json.return_value)

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore"),
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = resp
            client_inst.close = MagicMock()

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 2
            assert "pending deletion" in result.output.lower()


class TestResendVerification:
    """AC-33: resend-verification sends POST."""

    def test_resend_sends_request(self) -> None:
        runner = CliRunner()
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {}

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.cfg") as mock_cfg,
            patch("builtins.input", return_value="test@test.com"),
        ):
            mock_cfg.get_value.return_value = None
            client_inst = MockClient.return_value
            client_inst.post.return_value = resp
            client_inst.close = MagicMock()

            result = runner.invoke(cli, ["resend-verification"])
            assert result.exit_code == 0
            call_args = client_inst.post.call_args
            assert "/v1/auth/resend-verification" in call_args[0][0]


class TestCredentialLeakage:
    """AC-43: No credential value in exception messages or error output."""

    def test_no_token_in_401_error(self) -> None:
        runner = CliRunner()
        secret_key = "vbos_dev_SUPERSECRETKEY12345"
        resp = MagicMock()
        resp.status_code = 401

        with patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient:
            client_inst = MockClient.return_value
            client_inst.get.return_value = resp
            client_inst.close = MagicMock()

            result = runner.invoke(cli, ["login", "--token", secret_key])
            assert result.exit_code == 2
            assert secret_key not in result.output
            assert secret_key not in (result.stderr or "")

    def test_no_password_in_login_error(self) -> None:
        runner = CliRunner()
        secret_password = "MY_VERY_SECRET_PASSWORD_XYZ"
        resp = MagicMock()
        resp.status_code = 401
        resp.json.return_value = {"error": "invalid", "message": "Invalid credentials"}
        resp.text = '{"error":"invalid","message":"Invalid credentials"}'

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore"),
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value=secret_password),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = resp
            client_inst.close = MagicMock()

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 2
            assert secret_password not in result.output
            assert secret_password not in (result.stderr or "")


class TestPasswordNonEcho:
    def test_login_uses_getpass(self) -> None:
        runner = CliRunner()

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass") as mock_gp,
            patch("builtins.input", return_value="user@test.com"),
        ):
            instance = MockClient.return_value
            mock_resp = MagicMock()
            mock_resp.status_code = 401
            mock_resp.json.return_value = {"error": "invalid", "message": "bad"}
            mock_resp.text = "bad"
            instance.post.return_value = mock_resp
            instance.close = MagicMock()

            runner.invoke(cli, ["login"])
            mock_gp.assert_called()


class TestSessionToAPIKeyReplacement:
    """UT-S0031-47: session credential fully replaced by api_key login."""

    def test_api_key_replaces_session(self) -> None:
        runner = CliRunner()
        api_key = "vbos_dev_TESTKEY123"
        validate_resp = MagicMock()
        validate_resp.status_code = 200
        validate_resp.json.return_value = {"email": "user@test.com"}

        stored_creds: list = []

        def capture_store(cred):
            stored_creds.append(cred)

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.get.return_value = validate_resp
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value
            store_inst.store.side_effect = capture_store

            result = runner.invoke(cli, ["login", "--token", api_key])
            assert result.exit_code == 0

            assert len(stored_creds) == 1
            cred = stored_creds[0]
            assert cred.kind == "api_key"
            assert cred.api_key == api_key
            assert not hasattr(cred, "access_token")
            assert not hasattr(cred, "refresh_token")


class TestEnrollmentVsRuntimeAuth:
    """UT-S0031-26: --token enrollment persists even when VBOS_API_KEY is set."""

    def test_token_enrollment_ignores_env_var(self) -> None:
        runner = CliRunner()
        enrollment_key = "vbos_dev_ENROLLED"
        env_key = "vbos_dev_RUNTIME"
        validate_resp = MagicMock()
        validate_resp.status_code = 200
        validate_resp.json.return_value = {"email": "user@test.com"}

        stored_creds: list = []

        def capture_store(cred):
            stored_creds.append(cred)

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("vbos_cli.commands.auth.cfg"),
            patch.dict("os.environ", {"VBOS_API_KEY": env_key}),
        ):
            client_inst = MockClient.return_value
            client_inst.get.return_value = validate_resp
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value
            store_inst.store.side_effect = capture_store

            result = runner.invoke(cli, ["login", "--token", enrollment_key])
            assert result.exit_code == 0

            assert len(stored_creds) == 1
            cred = stored_creds[0]
            assert cred.api_key == enrollment_key
            assert cred.api_key != env_key
