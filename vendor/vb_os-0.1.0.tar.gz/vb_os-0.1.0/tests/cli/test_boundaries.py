"""Unit tests for boundaries CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


CMD_MODULE = "vbos_cli.commands.boundaries"

SAMPLE_DSL = """\
boundary_id: test-boundary
version: 1

require_evidence: npi_number

BOUNDARY {
    npi_number > 0
}
"""

SAMPLE_WORKLOAD = {"evidence": {"npi_number": 12345}}


@pytest.fixture
def dsl_file(tmp_path):
    f = tmp_path / "boundary.dsl"
    f.write_text(SAMPLE_DSL)
    return str(f)


@pytest.fixture
def workload_file(tmp_path):
    f = tmp_path / "workload.json"
    f.write_text(json.dumps(SAMPLE_WORKLOAD))
    return str(f)


class TestBoundariesCreate:
    def test_create_success(self, runner, dsl_file) -> None:
        resp_body = {"id": "bnd-001", "name": "KYC Boundary", "boundary_ref": "kyc-v1"}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "create",
                    "--project",
                    "proj-1",
                    "--name",
                    "KYC Boundary",
                    "--ref",
                    "kyc-v1",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "bnd-001"
        call_args = mc.post.call_args
        assert call_args[0][0] == "/v1/projects/proj-1/boundaries"
        body = call_args[1]["json_body"]
        assert body["name"] == "KYC Boundary"
        assert body["boundary_ref"] == "kyc-v1"
        assert body["dsl_source"] == SAMPLE_DSL
        mc.close.assert_called_once()

    def test_create_api_error(self, runner, dsl_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Parse error"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "create",
                    "--project",
                    "proj-1",
                    "--name",
                    "Bad",
                    "--ref",
                    "bad-v1",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 2

    def test_create_source_file_missing(self, runner) -> None:
        result = runner.invoke(
            cli,
            [
                "boundaries",
                "create",
                "--project",
                "proj-1",
                "--name",
                "X",
                "--ref",
                "x-v1",
                "--source",
                "/nonexistent/path.dsl",
            ],
        )
        assert result.exit_code != 0


class TestBoundariesList:
    def test_list_success(self, runner) -> None:
        resp_body = {"items": [{"id": "bnd-1"}, {"id": "bnd-2"}], "cursor": None}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["boundaries", "list", "--project", "proj-1"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["items"]) == 2
        mc.close.assert_called_once()

    def test_list_with_limit(self, runner) -> None:
        resp_body = {"items": [{"id": "bnd-1"}]}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "list",
                    "--project",
                    "proj-1",
                    "--limit",
                    "10",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once_with(
            "/v1/projects/proj-1/boundaries",
            params={"limit": 10},
        )

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(500, {"error": "internal_error", "message": "Fail"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["boundaries", "list", "--project", "proj-1"])
        assert result.exit_code == 2


class TestBoundariesGet:
    def test_get_success(self, runner) -> None:
        resp_body = {"id": "bnd-001", "name": "KYC Boundary", "dsl_source": SAMPLE_DSL}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "get",
                    "bnd-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "bnd-001"
        mc.get.assert_called_once_with("/v1/projects/proj-1/boundaries/bnd-001")
        mc.close.assert_called_once()

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "get",
                    "missing",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundariesUpdate:
    def test_update_success(self, runner) -> None:
        resp_body = {"id": "bnd-001", "name": "Renamed Boundary"}
        mc = make_mock_client(patch_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "update",
                    "bnd-001",
                    "--project",
                    "proj-1",
                    "--name",
                    "Renamed Boundary",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "Renamed Boundary"
        mc.patch.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001",
            json_body={"name": "Renamed Boundary"},
        )
        mc.close.assert_called_once()

    def test_update_api_error(self, runner) -> None:
        mc = make_mock_client(
            patch_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "update",
                    "bad-id",
                    "--project",
                    "proj-1",
                    "--name",
                    "x",
                ],
            )
        assert result.exit_code == 2


class TestBoundariesArchive:
    def test_archive_success(self, runner) -> None:
        resp_body = {"id": "bnd-001", "status": "archived"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "archive",
                    "bnd-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "archived"
        mc.post.assert_called_once_with("/v1/projects/proj-1/boundaries/bnd-001/archive")
        mc.close.assert_called_once()

    def test_archive_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Already archived"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "archive",
                    "bnd-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundariesCompile:
    def test_compile_success(self, runner, dsl_file) -> None:
        resp_body = {"compiled": True, "snapshot": {"stages": 3}}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "compile",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["compiled"] is True
        call_args = mc.post.call_args
        assert call_args[0][0] == "/v1/boundaries/compile"
        assert call_args[1]["json_body"]["dsl_source"] == SAMPLE_DSL
        mc.close.assert_called_once()

    def test_compile_api_error(self, runner, dsl_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Syntax error"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "compile",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 2


class TestBoundariesValidate:
    def test_validate_success(self, runner, dsl_file, workload_file) -> None:
        resp_body = {"result": "ASSERT", "stages_passed": 3}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "validate",
                    "--source",
                    dsl_file,
                    "--workload",
                    workload_file,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["result"] == "ASSERT"
        call_args = mc.post.call_args
        assert call_args[0][0] == "/v1/validate"
        body = call_args[1]["json_body"]
        assert body["dsl_source"] == SAMPLE_DSL
        assert body["workload"] == SAMPLE_WORKLOAD
        mc.close.assert_called_once()

    def test_validate_api_error(self, runner, dsl_file, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Bad workload"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "validate",
                    "--source",
                    dsl_file,
                    "--workload",
                    workload_file,
                ],
            )
        assert result.exit_code == 2


class TestBoundariesDiff:
    def test_diff_success(self, runner) -> None:
        resp_body = {
            "added": ["predicate: new_check: x > 1"],
            "removed": [],
            "changed": [],
        }
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "diff",
                    "bnd-001",
                    "--project",
                    "proj-1",
                    "--v1",
                    "ver-1",
                    "--v2",
                    "ver-2",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["added"] == ["predicate: new_check: x > 1"]
        mc.get.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001/diff",
            params={"v1": "ver-1", "v2": "ver-2"},
        )
        mc.close.assert_called_once()

    def test_diff_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Version not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "diff",
                    "bnd-001",
                    "--project",
                    "proj-1",
                    "--v1",
                    "ver-1",
                    "--v2",
                    "ver-bad",
                ],
            )
        assert result.exit_code == 2


class TestBoundariesPromote:
    def test_promote_success(self, runner) -> None:
        resp_body = {"id": "dep-001", "boundary_ref": "kyc-v1", "environment": "production"}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "promote",
                    "kyc-v1",
                    "--version",
                    "ver-001",
                    "--environment",
                    "production",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "dep-001"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/environments/production/deployments",
            json_body={"boundary_ref": "kyc-v1", "boundary_version_id": "ver-001"},
        )
        mc.close.assert_called_once()

    def test_promote_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Already deployed"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "promote",
                    "kyc-v1",
                    "--version",
                    "ver-001",
                    "--environment",
                    "production",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsCreate:
    def test_versions_create_success(self, runner, dsl_file) -> None:
        resp_body = {"id": "ver-001", "boundary_id": "bnd-001", "status": "draft"}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "create",
                    "bnd-001",
                    "--project",
                    "proj-1",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "ver-001"
        call_args = mc.post.call_args
        assert call_args[0][0] == "/v1/projects/proj-1/boundaries/bnd-001/versions"
        assert call_args[1]["json_body"]["dsl_source"] == SAMPLE_DSL
        mc.close.assert_called_once()

    def test_versions_create_api_error(self, runner, dsl_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Invalid DSL"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "create",
                    "bnd-001",
                    "--project",
                    "proj-1",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsList:
    def test_versions_list_success(self, runner) -> None:
        resp_body = {"items": [{"id": "ver-1"}, {"id": "ver-2"}], "cursor": None}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "list",
                    "bnd-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["items"]) == 2
        mc.close.assert_called_once()

    def test_versions_list_with_limit(self, runner) -> None:
        resp_body = {"items": [{"id": "ver-1"}]}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "list",
                    "bnd-001",
                    "--project",
                    "proj-1",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001/versions",
            params={"limit": 5},
        )

    def test_versions_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Boundary not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "list",
                    "bad-id",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsGet:
    def test_versions_get_success(self, runner) -> None:
        resp_body = {"id": "ver-001", "status": "draft", "dsl_source": SAMPLE_DSL}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "get",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "ver-001"
        mc.get.assert_called_once_with("/v1/projects/proj-1/boundaries/bnd-001/versions/ver-001")
        mc.close.assert_called_once()

    def test_versions_get_not_found(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "get",
                    "bnd-001",
                    "missing",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsUpdate:
    def test_versions_update_success(self, runner, dsl_file) -> None:
        resp_body = {"id": "ver-001", "status": "draft"}
        mc = make_mock_client(patch_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "update",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "ver-001"
        mc.patch.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001/versions/ver-001",
            json_body={"dsl_source": SAMPLE_DSL},
        )
        mc.close.assert_called_once()

    def test_versions_update_api_error(self, runner, dsl_file) -> None:
        mc = make_mock_client(
            patch_resp=make_response(409, {"error": "conflict", "message": "Not in draft"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "update",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                    "--source",
                    dsl_file,
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsSubmit:
    def test_versions_submit_success(self, runner) -> None:
        resp_body = {"id": "ver-001", "status": "submitted"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "submit",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "submitted"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001/versions/ver-001/submit",
        )
        mc.close.assert_called_once()

    def test_versions_submit_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Already submitted"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "submit",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsApprove:
    def test_versions_approve_success(self, runner) -> None:
        resp_body = {"id": "ver-001", "status": "approved"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "approve",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "approved"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001/versions/ver-001/approve",
        )
        mc.close.assert_called_once()

    def test_versions_approve_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Not submitted"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "approve",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestBoundaryVersionsReject:
    def test_versions_reject_success(self, runner) -> None:
        resp_body = {"id": "ver-001", "status": "rejected"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "reject",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "rejected"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/boundaries/bnd-001/versions/ver-001/reject",
        )
        mc.close.assert_called_once()

    def test_versions_reject_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Not submitted"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "versions",
                    "reject",
                    "bnd-001",
                    "ver-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2
