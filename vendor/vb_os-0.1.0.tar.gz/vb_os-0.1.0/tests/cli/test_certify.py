from __future__ import annotations

import json
import os
import tempfile
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.certify"


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def evidence_file():
    data = {"field_a": 100, "field_b": 200}
    fd, path = tempfile.mkstemp(suffix=".json")
    with os.fdopen(fd, "w") as f:
        json.dump(data, f)
    yield path
    os.unlink(path)


@pytest.fixture
def config_file():
    data = {"threshold": 90, "rules": ["r1", "r2"]}
    fd, path = tempfile.mkstemp(suffix=".json")
    with os.fdopen(fd, "w") as f:
        json.dump(data, f)
    yield path
    os.unlink(path)


class TestCertify:
    def test_certify_success(self, runner, evidence_file) -> None:
        body = {"id": "run-1", "status": "PENDING"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "certify",
                    "--project", "proj",
                    "--environment", "staging",
                    "--model", "model-1",
                    "--evidence", evidence_file,
                ],
            )
        assert result.exit_code == 0
        assert "run-1" in result.output
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["model_id"] == "model-1"
        assert call_args[1]["json_body"]["environment_id"] == "staging"
        assert call_args[1]["json_body"]["evidence"] == {"field_a": 100, "field_b": 200}
        mc.close.assert_called_once()

    def test_certify_missing_model(self, runner, evidence_file) -> None:
        result = runner.invoke(
            cli,
            [
                "certify",
                "--project", "proj",
                "--environment", "staging",
                "--evidence", evidence_file,
            ],
        )
        assert result.exit_code != 0

    def test_certify_missing_evidence(self, runner) -> None:
        result = runner.invoke(
            cli,
            [
                "certify",
                "--project", "proj",
                "--environment", "staging",
                "--model", "model-1",
            ],
        )
        assert result.exit_code != 0

    def test_certify_api_error(self, runner, evidence_file) -> None:
        mc = make_mock_client(post_resp=make_response(422, {"error": "validation_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "certify",
                    "--project", "proj",
                    "--environment", "staging",
                    "--model", "model-1",
                    "--evidence", evidence_file,
                ],
            )
        assert result.exit_code != 0
        mc.close.assert_called_once()


class TestCertificationsList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "run-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["certifications", "list", "--project", "proj"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()


class TestCertificationsGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "run-1", "status": "PASSED"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["certifications", "get", "run-1", "--project", "proj"]
            )
        assert result.exit_code == 0
        assert "run-1" in result.output
        mc.close.assert_called_once()


class TestCertificationsReport:
    def test_report_success(self, runner) -> None:
        body = {"id": "run-1", "report": "data"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            output_path = tmp.name
        try:
            with patch(f"{CMD_MODULE}.make_client", return_value=mc):
                result = runner.invoke(
                    cli,
                    [
                        "certifications", "report", "run-1",
                        "--project", "proj",
                        "--output", output_path,
                    ],
                )
            assert result.exit_code == 0
            assert "Report written" in result.output
            with open(output_path) as f:
                written = json.load(f)
            assert written["id"] == "run-1"
        finally:
            os.unlink(output_path)

    def test_report_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            output_path = tmp.name
        try:
            with patch(f"{CMD_MODULE}.make_client", return_value=mc):
                result = runner.invoke(
                    cli,
                    [
                        "certifications", "report", "run-1",
                        "--project", "proj",
                        "--output", output_path,
                    ],
                )
            assert result.exit_code != 0
            mc.close.assert_called_once()
        finally:
            os.unlink(output_path)


class TestCertificationsRevoke:
    def test_revoke_success(self, runner) -> None:
        body = {"id": "run-1", "status": "CANCELLED"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["certifications", "revoke", "run-1", "--project", "proj"]
            )
        assert result.exit_code == 0
        assert "run-1" in result.output
        call_path = mc.post.call_args[0][0]
        assert "/cancel" in call_path
        mc.close.assert_called_once()


class TestCertificationModelsCreate:
    def test_create_success(self, runner, config_file) -> None:
        body = {"id": "cm-1", "name": "my-model"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "certification-models", "create",
                    "--project", "proj",
                    "--name", "my-model",
                    "--config", config_file,
                ],
            )
        assert result.exit_code == 0
        assert "cm-1" in result.output
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["name"] == "my-model"
        assert call_args[1]["json_body"]["config"]["threshold"] == 90
        mc.close.assert_called_once()

    def test_create_missing_name(self, runner, config_file) -> None:
        result = runner.invoke(
            cli,
            [
                "certification-models", "create",
                "--project", "proj",
                "--config", config_file,
            ],
        )
        assert result.exit_code != 0

    def test_create_missing_config(self, runner) -> None:
        result = runner.invoke(
            cli,
            [
                "certification-models", "create",
                "--project", "proj",
                "--name", "my-model",
            ],
        )
        assert result.exit_code != 0


class TestCertificationModelsList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "cm-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["certification-models", "list", "--project", "proj"]
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()


class TestCertificationModelsGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "cm-1", "name": "my-model"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["certification-models", "get", "cm-1", "--project", "proj"]
            )
        assert result.exit_code == 0
        assert "cm-1" in result.output
        mc.close.assert_called_once()


class TestCertificationModelsUpdate:
    def test_update_success(self, runner, config_file) -> None:
        body = {"id": "cm-1", "name": "my-model"}
        mc = make_mock_client(patch_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "certification-models", "update", "cm-1",
                    "--project", "proj",
                    "--config", config_file,
                ],
            )
        assert result.exit_code == 0
        assert "cm-1" in result.output
        mc.patch.assert_called_once()
        mc.close.assert_called_once()


class TestCertificationModelsDelete:
    def test_delete_with_confirm(self, runner) -> None:
        body = {"id": "cm-1", "archived": True}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "certification-models", "delete", "cm-1",
                    "--project", "proj",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        call_path = mc.post.call_args[0][0]
        assert "/archive" in call_path
        mc.close.assert_called_once()

    def test_delete_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "certification-models", "delete", "cm-1",
                    "--project", "proj",
                ],
                input="n\n",
            )
        mc.post.assert_not_called()
