"""Tests for CLI scaffold: version, help, execution modes, output format."""

from click.testing import CliRunner

from vbos_cli.cli import cli


class TestVersion:
    def test_version_prints_and_exits_0(self) -> None:
        result = CliRunner().invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output


class TestHelp:
    def test_help_lists_commands(self) -> None:
        result = CliRunner().invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "login" in result.output
        assert "logout" in result.output
        assert "config" in result.output
        assert "switch-org" in result.output
        assert "completions" in result.output


class TestExecutionMode:
    def test_cloud_is_default(self) -> None:
        result = CliRunner().invoke(cli, ["--help"])
        assert result.exit_code == 0

    def test_cloud_and_local_mutually_exclusive(self) -> None:
        """--cloud --local must error with exit 2, not silently pick one."""
        result = CliRunner().invoke(cli, ["--cloud", "--local", "config", "list"])
        assert result.exit_code == 2
        combined = (result.output + (result.stderr or "")).lower()
        assert "mutually exclusive" in combined

    def test_local_login_rejected(self) -> None:
        result = CliRunner().invoke(cli, ["--local", "login"])
        assert result.exit_code == 2
        assert "unsupported_in_local_mode" in result.output

    def test_local_logout_rejected(self) -> None:
        result = CliRunner().invoke(cli, ["--local", "logout"])
        assert result.exit_code == 2
        assert "unsupported_in_local_mode" in result.output

    def test_local_switch_org_rejected(self) -> None:
        result = CliRunner().invoke(cli, ["--local", "switch-org", "some-id"])
        assert result.exit_code == 2
        assert "unsupported_in_local_mode" in result.output

    def test_local_resend_verification_rejected(self) -> None:
        result = CliRunner().invoke(cli, ["--local", "resend-verification"])
        assert result.exit_code == 2
        assert "unsupported_in_local_mode" in result.output

    def test_local_config_set_allowed(self) -> None:
        runner = CliRunner()
        with runner.isolated_filesystem():
            import os

            os.makedirs(os.path.expanduser("~/.vbos"), exist_ok=True)
            result = runner.invoke(cli, ["--local", "config", "list"])
            assert result.exit_code == 0


class TestOutputFormat:
    def test_json_is_default(self) -> None:
        result = CliRunner().invoke(cli, ["--help"])
        assert "json" in result.output

    def test_format_flag_accepted(self) -> None:
        result = CliRunner().invoke(cli, ["--format", "table", "--help"])
        assert result.exit_code == 0

    def test_invalid_format_rejected(self) -> None:
        result = CliRunner().invoke(cli, ["--format", "csv", "config", "list"])
        assert result.exit_code != 0


class TestNetworkErrorHandling:
    """UT-S0031-23/24: Network errors produce structured JSON, not raw tracebacks."""

    def test_connect_error_produces_structured_json(self) -> None:
        from unittest.mock import patch

        import httpx

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="secret"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.side_effect = httpx.ConnectError("nodename nor servname provided")
            client_inst.close.return_value = None

            result = CliRunner().invoke(cli, ["login"])
            assert result.exit_code == 2
            assert "connection_error" in result.output
            assert "Cannot connect" in result.output
            assert "Traceback" not in result.output

    def test_timeout_error_produces_structured_json(self) -> None:
        from unittest.mock import patch

        import httpx

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="secret"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.side_effect = httpx.ReadTimeout("timed out")
            client_inst.close.return_value = None

            result = CliRunner().invoke(cli, ["login"])
            assert result.exit_code == 2
            assert "timeout_error" in result.output
            assert "timed out" in result.output.lower()
            assert "Traceback" not in result.output
