"""Tests for HTTP client: auth injection, token refresh, retry policy."""

from __future__ import annotations

import base64
import json
import time
from unittest.mock import MagicMock, patch

import httpx
import pytest

from vbos_cli.client import (
    USER_AGENT,
    AuthenticatedClient,
    _is_expired,
    _jwt_exp,
    parse_api_error,
)
from vbos_cli.credentials.store import APIKeyCredential, SessionCredential
from vbos_cli.errors import APIKeyInvalidError, AuthenticationError, SessionExpiredError


def _make_jwt(exp: int | None = None, extra: dict | None = None) -> str:
    """Create a minimal JWT for testing (not signed)."""
    header = base64.urlsafe_b64encode(json.dumps({"alg": "RS256"}).encode()).rstrip(b"=")
    payload_data: dict = {}
    if exp is not None:
        payload_data["exp"] = exp
    if extra:
        payload_data.update(extra)
    payload = base64.urlsafe_b64encode(json.dumps(payload_data).encode()).rstrip(b"=")
    sig = base64.urlsafe_b64encode(b"fake-sig").rstrip(b"=")
    return f"{header.decode()}.{payload.decode()}.{sig.decode()}"


class TestJWTExpiration:
    def test_valid_jwt_exp_extracted(self) -> None:
        token = _make_jwt(exp=9999999999)
        assert _jwt_exp(token) == 9999999999

    def test_missing_exp_returns_none(self) -> None:
        token = _make_jwt()
        assert _jwt_exp(token) is None

    def test_malformed_jwt_returns_none(self) -> None:
        assert _jwt_exp("not-a-jwt") is None
        assert _jwt_exp("a.b") is None

    def test_expired_jwt(self) -> None:
        token = _make_jwt(exp=int(time.time()) - 100)
        assert _is_expired(token)

    def test_not_expired_jwt(self) -> None:
        token = _make_jwt(exp=int(time.time()) + 3600)
        assert not _is_expired(token)

    def test_malformed_treated_as_expired(self) -> None:
        assert _is_expired("not-a-jwt")

    def test_missing_exp_treated_as_expired(self) -> None:
        token = _make_jwt()
        assert _is_expired(token)


class TestUserAgent:
    def test_user_agent_format(self) -> None:
        assert USER_AGENT == "vbos-cli/0.1.0"


class TestAuthenticatedClient:
    def test_api_key_bypass_jwt_refresh(self) -> None:
        cred = APIKeyCredential(kind="api_key", api_key="vbos_dev_test")
        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )
        headers = client._ensure_auth()
        assert headers["Authorization"] == "Bearer vbos_dev_test"
        client.close()

    def test_session_expired_triggers_refresh(self) -> None:
        expired_jwt = _make_jwt(exp=int(time.time()) - 100)
        cred = SessionCredential(kind="session", access_token=expired_jwt, refresh_token="ref")

        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "access_token": _make_jwt(exp=int(time.time()) + 900),
            "refresh_token": "new_ref",
        }

        with (
            patch.object(client._http, "post", return_value=mock_resp),
            patch.object(client._store, "store"),
        ):
            headers = client._ensure_auth()
            assert "Bearer" in headers["Authorization"]

        client.close()

    def test_refresh_401_clears_credentials_and_raises(self) -> None:
        expired_jwt = _make_jwt(exp=int(time.time()) - 100)
        cred = SessionCredential(kind="session", access_token=expired_jwt, refresh_token="ref")

        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        mock_resp = MagicMock()
        mock_resp.status_code = 401

        with (
            patch.object(client._http, "post", return_value=mock_resp),
            patch.object(client._store, "delete") as mock_delete,
        ):
            with pytest.raises(SessionExpiredError):
                client._ensure_auth()
            mock_delete.assert_called_once()

        client.close()

    def test_api_key_401_raises_api_key_error(self) -> None:
        cred = APIKeyCredential(kind="api_key", api_key="vbos_dev_invalid")
        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 401

        with patch.object(client._http, "request", return_value=mock_resp):
            with pytest.raises(APIKeyInvalidError):
                client.get("/v1/users/me")

        client.close()

    def test_post_not_retried_on_500(self) -> None:
        cred = APIKeyCredential(kind="api_key", api_key="vbos_dev_test")
        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 500
        mock_resp.headers = {}

        with patch.object(client._http, "request", return_value=mock_resp) as mock_request:
            resp = client.post("/v1/auth/login", json={"email": "a"})
            assert resp.status_code == 500
            assert mock_request.call_count == 1

        client.close()

    def test_get_retried_on_500(self) -> None:
        cred = APIKeyCredential(kind="api_key", api_key="vbos_dev_test")
        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        fail_resp = MagicMock(spec=httpx.Response)
        fail_resp.status_code = 500
        fail_resp.headers = {}

        ok_resp = MagicMock(spec=httpx.Response)
        ok_resp.status_code = 200
        ok_resp.headers = {}

        with (
            patch.object(client._http, "request", side_effect=[fail_resp, ok_resp]) as mock_request,
            patch("vbos_cli.client.time.sleep"),
        ):
            resp = client.get("/v1/users/me")
            assert resp.status_code == 200
            assert mock_request.call_count == 2

        client.close()

    def test_refresh_store_failure_deletes_session(self) -> None:
        expired_jwt = _make_jwt(exp=int(time.time()) - 100)
        cred = SessionCredential(kind="session", access_token=expired_jwt, refresh_token="ref")

        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "access_token": _make_jwt(exp=int(time.time()) + 900),
            "refresh_token": "new_ref",
        }

        with (
            patch.object(client._http, "post", return_value=mock_resp),
            patch.object(client._store, "store", side_effect=OSError("disk full")),
            patch.object(client._store, "delete") as mock_delete,
        ):
            from vbos_cli.errors import CredentialStoreError

            with pytest.raises(CredentialStoreError, match="Local session cleared"):
                client._ensure_auth()
            mock_delete.assert_called_once()

        client.close()

    def test_post_401_after_transmission_does_not_refresh(self) -> None:
        valid_jwt = _make_jwt(exp=int(time.time()) + 3600)
        cred = SessionCredential(kind="session", access_token=valid_jwt, refresh_token="ref")

        client = AuthenticatedClient(
            base_url="http://localhost",
            credential=cred,
        )

        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 401

        with patch.object(client._http, "request", return_value=mock_resp):
            with pytest.raises(AuthenticationError, match="Request returned 401"):
                client.post("/v1/something")

        client.close()


class TestParseAPIError:
    def test_parses_structured_error(self) -> None:
        resp = MagicMock()
        resp.json.return_value = {
            "error": "not_found",
            "message": "Resource not found",
            "request_id": "req-123",
        }
        code, msg, req_id = parse_api_error(resp)
        assert code == "not_found"
        assert msg == "Resource not found"
        assert req_id == "req-123"

    def test_handles_non_json(self) -> None:
        resp = MagicMock()
        resp.json.side_effect = ValueError
        resp.text = "Internal Server Error"
        code, msg, req_id = parse_api_error(resp)
        assert code == "unknown_error"
        assert msg == "Internal Server Error"
        assert req_id is None
