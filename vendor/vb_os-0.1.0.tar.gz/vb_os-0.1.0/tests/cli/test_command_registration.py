"""Tests that all S0032 command groups are registered and accessible."""

from __future__ import annotations

import pytest
from click.testing import CliRunner

from vbos_cli.cli import cli

S0032_COMMANDS = [
    "verify",
    "replay",
    "evaluations",
    "boundaries",
    "projects",
    "environments",
    "keys",
    "connectors",
    "webhooks",
    "flows",
    "alert-rules",
    "deployments",
    "templates",
    "named-sets",
    "org",
    "members",
    "workspaces",
    "audit-log",
    "certify",
    "certifications",
    "certification-models",
    "analytics",
    "governed-workspaces",
    "notifications",
    "account",
]

S0031_COMMANDS = [
    "login",
    "logout",
    "resend-verification",
    "switch-org",
    "config",
    "completions",
]


class TestCommandRegistration:
    @pytest.mark.parametrize("cmd", S0032_COMMANDS)
    def test_s0032_command_registered(self, cmd) -> None:
        result = CliRunner().invoke(cli, ["--help"])
        assert cmd in result.output, f"Command '{cmd}' not found in CLI help"

    @pytest.mark.parametrize("cmd", S0031_COMMANDS)
    def test_s0031_command_still_registered(self, cmd) -> None:
        result = CliRunner().invoke(cli, ["--help"])
        assert cmd in result.output, f"S0031 command '{cmd}' missing from CLI help"

    @pytest.mark.parametrize("cmd", S0032_COMMANDS)
    def test_s0032_command_has_help(self, cmd) -> None:
        result = CliRunner().invoke(cli, [cmd, "--help"])
        assert result.exit_code == 0, f"'{cmd} --help' failed with exit {result.exit_code}"

    def test_total_command_count(self) -> None:
        all_commands = S0031_COMMANDS + S0032_COMMANDS
        registered = list(cli.commands.keys())
        for cmd in all_commands:
            assert cmd in registered, f"'{cmd}' not in registered commands"
