"""Tests for shell completion commands."""

from click.testing import CliRunner

from vbos_cli.cli import cli


class TestCompletions:
    def test_bash_completions(self) -> None:
        result = CliRunner().invoke(cli, ["completions", "bash"])
        assert result.exit_code == 0
        assert "_VBOS_COMPLETE=bash_source" in result.output

    def test_zsh_completions(self) -> None:
        result = CliRunner().invoke(cli, ["completions", "zsh"])
        assert result.exit_code == 0
        assert "_VBOS_COMPLETE=zsh_source" in result.output

    def test_fish_completions(self) -> None:
        result = CliRunner().invoke(cli, ["completions", "fish"])
        assert result.exit_code == 0
        assert "_VBOS_COMPLETE=fish_source" in result.output
