"""Tests for config command and config module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from vbos_cli import config as cfg


class TestConfigModule:
    def test_set_and_get_value(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            cfg.set_value("default-project", "myproj")
            assert cfg.get_value("default-project") == "myproj"

    def test_list_values(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            cfg.set_value("default-project", "proj1")
            cfg.set_value("api-url", "https://test.api")
            values = cfg.list_values()
            assert values["default-project"] == "proj1"
            assert values["api-url"] == "https://test.api"

    def test_invalid_key_rejected(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            with pytest.raises(ValueError, match="Unknown config key"):
                cfg.set_value("secret-token", "abc123")

    def test_profile_isolation(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            cfg.set_value("api-url", "https://prod.api", "default")
            cfg.set_value("api-url", "https://staging.api", "staging")
            assert cfg.get_value("api-url", "default") == "https://prod.api"
            assert cfg.get_value("api-url", "staging") == "https://staging.api"

    def test_get_nonexistent_returns_none(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            assert cfg.get_value("default-project") is None

    def test_default_api_url(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            assert cfg.get_api_url() == "https://api.vb-os.org"

    def test_config_file_never_contains_credentials(self, tmp_path: Path) -> None:
        with (
            patch.object(cfg, "VBOS_DIR", tmp_path),
            patch.object(cfg, "CONFIG_PATH", tmp_path / "config"),
        ):
            cfg.set_value("email", "user@test.com")
            cfg.set_value("default-project", "proj")
            content = (tmp_path / "config").read_text()
            assert "vbos_" not in content
            assert "eyJ" not in content
