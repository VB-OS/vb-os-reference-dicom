"""Config fallback tests: --project/--environment resolution."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestProjectFallback:
    def test_explicit_project_option_used(self, runner) -> None:
        mc = make_mock_client()
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "my-proj",
                ],
            )
        mc.get.assert_called_once()
        call_path = mc.get.call_args[0][0]
        assert "my-proj" in call_path

    def test_missing_project_exits_2(self, runner) -> None:
        mc = make_mock_client()
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            result = runner.invoke(cli, ["evaluations", "list"])
        assert result.exit_code == 2
        assert "missing_project" in result.output


class TestEnvironmentFallback:
    def test_missing_environment_exits_2(self, runner) -> None:
        mc = make_mock_client()
        with patch("vbos_cli.commands.deployments.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "list",
                    "--project",
                    "proj",
                ],
            )
        assert result.exit_code == 2
        assert "missing_environment" in result.output
