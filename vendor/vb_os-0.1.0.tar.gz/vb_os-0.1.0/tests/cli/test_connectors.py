"""Tests for connectors CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.connectors"


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def config_file(tmp_path):
    """Create a temporary JSON config file."""
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"host": "db.example.com", "port": 5432}))
    return str(path)


class TestConnectorsCreate:
    def test_create_success(self, runner, config_file) -> None:
        resp = make_response(201, {"id": "conn-1", "provider": "postgres"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "create",
                    "--project",
                    "proj-1",
                    "--provider",
                    "postgres",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        mc.post.assert_called_once()
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/connectors" in call_args[0][0]
        payload = call_args[1]["json"]
        assert payload["provider"] == "postgres"
        assert payload["config"]["host"] == "db.example.com"

    def test_create_reads_config_file(self, runner, config_file) -> None:
        resp = make_response(201, {"id": "conn-1"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "create",
                    "--project",
                    "proj-1",
                    "--provider",
                    "s3",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        payload = mc.post.call_args[1]["json"]
        assert payload["config"] == {"host": "db.example.com", "port": 5432}

    def test_create_api_error(self, runner, config_file) -> None:
        resp = make_response(422, {"error": "validation_error", "message": "Bad config"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "create",
                    "--project",
                    "proj-1",
                    "--provider",
                    "postgres",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 2

    def test_create_closes_client(self, runner, config_file) -> None:
        mc = make_mock_client(post_resp=make_response(201, {"id": "c1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "connectors",
                    "create",
                    "--project",
                    "proj-1",
                    "--provider",
                    "pg",
                    "--config",
                    config_file,
                ],
            )
        mc.close.assert_called_once()


class TestConnectorsList:
    def test_list_success(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "c-1"}, {"id": "c-2"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        assert "/v1/projects/proj-1/connectors" in mc.get.call_args[0][0]

    def test_list_with_limit(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "c-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "list",
                    "--project",
                    "proj-1",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("limit") == 5

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(500, {"error": "internal"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestConnectorsGet:
    def test_get_success(self, runner) -> None:
        resp = make_response(200, {"id": "conn-1", "provider": "postgres"})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "get",
                    "conn-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/connectors/conn-1" in mc.get.call_args[0][0]

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "get",
                    "bad-id",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestConnectorsUpdate:
    def test_update_success(self, runner, config_file) -> None:
        resp = make_response(200, {"id": "conn-1", "updated": True})
        mc = make_mock_client(patch_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "update",
                    "conn-1",
                    "--project",
                    "proj-1",
                    "--config",
                    config_file,
                ],
            )
        assert result.exit_code == 0
        call_args = mc.patch.call_args
        assert "/v1/projects/proj-1/connectors/conn-1" in call_args[0][0]
        assert call_args[1]["json"]["config"]["host"] == "db.example.com"


class TestConnectorsDelete:
    def test_delete_with_confirm(self, runner) -> None:
        resp = make_response(204, None)
        mc = make_mock_client(delete_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "delete",
                    "conn-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()
        assert "/v1/projects/proj-1/connectors/conn-1" in mc.delete.call_args[0][0]

    def test_delete_requires_confirm_in_non_interactive(self, runner) -> None:
        resp = make_response(204, None)
        mc = make_mock_client(delete_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "delete",
                    "conn-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2
        assert "confirmation_required" in result.output or "--confirm" in result.output

    def test_delete_200_response(self, runner) -> None:
        resp = make_response(200, {"id": "conn-1", "deleted": True})
        mc = make_mock_client(delete_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "delete",
                    "conn-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0


class TestConnectorsTest:
    def test_test_success(self, runner) -> None:
        resp = make_response(200, {"status": "ok", "id": "conn-1"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "test",
                    "conn-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/connectors/conn-1/test" in mc.post.call_args[0][0]

    def test_test_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(500, {"error": "fail"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "test",
                    "conn-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestConnectorsGather:
    def test_gather_success(self, runner) -> None:
        resp = make_response(202, {"id": "job-1", "status": "queued"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "gather",
                    "conn-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/connectors/conn-1/gather" in mc.post.call_args[0][0]

    def test_gather_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(400, {"error": "bad_request"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "gather",
                    "conn-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestProvidersList:
    def test_list_providers(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "postgres"}, {"id": "s3"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "providers",
                    "list",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/connector-providers" in mc.get.call_args[0][0]


class TestProvidersGet:
    def test_get_provider(self, runner) -> None:
        resp = make_response(200, {"id": "postgres", "name": "PostgreSQL"})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "providers",
                    "get",
                    "postgres",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/connector-providers/postgres" in mc.get.call_args[0][0]

    def test_get_provider_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "connectors",
                    "providers",
                    "get",
                    "nonexistent",
                ],
            )
        assert result.exit_code == 2
