"""Tests for connector OAuth CLI commands: authorize, disconnect, reconnect, status."""

from __future__ import annotations

from unittest.mock import MagicMock, call, patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.connectors"


@pytest.fixture
def runner():
    return CliRunner()


class TestConnectorsAuthorize:
    def test_authorize_success_completed(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc123",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_completed = make_response(200, {
            "status": "COMPLETED",
            "connector_id": "conn-1",
            "authorization_status": "AUTHORIZED",
            "provider_account_display": "user@example.com",
            "granted_scopes": ["read", "write"],
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_completed
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser") as mock_wb,
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 0
        assert "console.vb-os.org/connect/abc123" in result.output
        assert "Connected successfully" in result.output
        assert "user@example.com" in result.output
        assert "read, write" in result.output
        mock_wb.open.assert_called_once()
        mc.post.assert_called_once()
        post_args = mc.post.call_args
        assert "oauth/authorize" in post_args[0][0]
        assert post_args[1]["json"]["mode"] == "REMOTE"

    def test_authorize_declined_exit_1(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_declined = make_response(200, {"status": "DECLINED"})
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_declined
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 1
        assert "declined" in result.output.lower()

    def test_authorize_failed_exit_1(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_failed = make_response(200, {"status": "FAILED", "error": "provider_error"})
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_failed
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 1
        assert "failed" in result.output.lower()

    def test_authorize_expired_exit_1(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_expired = make_response(200, {"status": "EXPIRED"})
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_expired
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 1
        assert "expired" in result.output.lower()

    def test_authorize_superseded_exit_1(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_superseded = make_response(200, {"status": "SUPERSEDED"})
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_superseded
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 1
        assert "superseded" in result.output.lower()

    def test_authorize_404_during_poll(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_404 = make_response(404, {"detail": "Not found"})
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_404
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_authorize_no_browser_flag(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_completed = make_response(200, {
            "status": "COMPLETED",
            "provider_account_display": "user@test.com",
            "granted_scopes": [],
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_completed
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser") as mock_wb,
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1",
                "--project", "proj-1", "--no-browser",
            ])

        assert result.exit_code == 0
        mock_wb.open.assert_not_called()

    def test_authorize_quiet_mode(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1",
                "--project", "proj-1", "--quiet",
            ])

        assert result.exit_code == 0
        assert "aid-1" in result.output
        mc.get.assert_not_called()

    def test_authorize_api_error(self, runner) -> None:
        error_resp = make_response(400, {"error": "bad_request", "message": "Invalid connector"})
        mc = make_mock_client(post_resp=error_resp)

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code != 0

    def test_authorize_503_bounded_retry(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_503 = make_response(503, {})
        poll_completed = make_response(200, {
            "status": "COMPLETED",
            "provider_account_display": "user@test.com",
            "granted_scopes": [],
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.side_effect = [poll_503, poll_503, poll_completed]
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 0
        assert mc.get.call_count == 3


class TestConnectorsDisconnect:
    def test_disconnect_success(self, runner) -> None:
        resp = make_response(200, {"success": True, "connector_id": "conn-1"})
        mc = make_mock_client(post_resp=resp)

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "disconnect", "conn-1",
                "--project", "proj-1", "--confirm",
            ])

        assert result.exit_code == 0
        mc.post.assert_called_once()
        assert "oauth/disconnect" in mc.post.call_args[0][0]

    def test_disconnect_requires_confirmation(self, runner) -> None:
        mc = make_mock_client()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "disconnect", "conn-1", "--project", "proj-1",
            ], input="n\n")

        assert result.exit_code != 0 or mc.post.call_count == 0

    def test_disconnect_api_error(self, runner) -> None:
        resp = make_response(404, {"error": "not_found", "message": "Connector not found"})
        mc = make_mock_client(post_resp=resp)

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "disconnect", "conn-1",
                "--project", "proj-1", "--confirm",
            ])

        assert result.exit_code != 0


class TestConnectorsReconnect:
    def test_reconnect_success(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/xyz",
            "mode": "REMOTE",
            "authorization_id": "aid-2",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_completed = make_response(200, {
            "status": "COMPLETED",
            "provider_account_display": "new-user@example.com",
            "granted_scopes": ["read"],
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_completed
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "reconnect", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 0
        assert "Reauthorize at" in result.output
        assert "oauth/reconnect" in mc.post.call_args[0][0]
        assert mc.post.call_args[1]["json"]["mode"] == "REMOTE"


class TestConnectorsStatus:
    def test_status_authorized(self, runner) -> None:
        oauth_resp = make_response(200, {
            "authorization_status": "AUTHORIZED",
            "has_active_grant": True,
            "provider_account_id": "user@company.com",
            "granted_scopes": ["spreadsheets.readonly", "drive.readonly"],
            "last_refreshed_at": "2026-08-31T04:29:00Z",
        })
        connector_resp = make_response(200, {
            "id": "conn-1",
            "name": "Settlement Tracker",
            "provider": "google_sheets",
            "status": "ACTIVE",
        })
        mc = MagicMock()
        mc.get.side_effect = [oauth_resp, connector_resp]
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "status", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 0
        assert "Settlement Tracker" in result.output
        assert "google_sheets" in result.output
        assert "ACTIVE" in result.output
        assert "AUTHORIZED" in result.output
        assert "user@company.com" in result.output
        assert "spreadsheets.readonly" in result.output

    def test_status_reauthorization_required(self, runner) -> None:
        oauth_resp = make_response(200, {
            "authorization_status": "REAUTHORIZATION_REQUIRED",
            "has_active_grant": False,
        })
        connector_resp = make_response(200, {
            "id": "conn-1",
            "name": "CRM Sync",
            "provider": "salesforce",
            "status": "ACTIVE",
        })
        mc = MagicMock()
        mc.get.side_effect = [oauth_resp, connector_resp]
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "status", "conn-1", "--project", "proj-1",
            ])

        assert result.exit_code == 0
        assert "REAUTHORIZATION_REQUIRED" in result.output
        assert "ACTIVE" in result.output


class TestNoTokenLeakage:
    def test_completed_poll_output_no_tokens(self, runner) -> None:
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_completed = make_response(200, {
            "status": "COMPLETED",
            "connector_id": "conn-1",
            "authorization_status": "AUTHORIZED",
            "provider_account_display": "user@test.com",
            "granted_scopes": ["read"],
            "access_token": "SHOULD_NOT_APPEAR",
            "refresh_token": "SHOULD_NOT_APPEAR",
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_completed
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        assert "SHOULD_NOT_APPEAR" not in result.output
        assert "access_token" not in result.output
        assert "refresh_token" not in result.output

    def test_secret_containment_all_surfaces(self, runner) -> None:
        """Sentinel secret values must not leak through any CLI output surface."""
        sentinels = {
            "access_token": "SENTINEL_ACCESS_TOKEN_XYZ",
            "refresh_token": "SENTINEL_REFRESH_TOKEN_XYZ",
            "client_secret": "SENTINEL_CLIENT_SECRET_XYZ",
            "code_verifier": "SENTINEL_CODE_VERIFIER_XYZ",
            "state": "SENTINEL_STATE_XYZ",
            "authorization_code": "SENTINEL_AUTH_CODE_XYZ",
        }
        auth_resp = make_response(200, {
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-sec",
            "poll_interval": 3,
            "expires_in": 600,
        })
        poll_completed = make_response(200, {
            "status": "COMPLETED",
            "connector_id": "conn-1",
            "authorization_status": "AUTHORIZED",
            "provider_account_display": "user@test.com",
            "granted_scopes": ["read"],
            **sentinels,
        })
        mc = MagicMock()
        mc.post.return_value = auth_resp
        mc.get.return_value = poll_completed
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
            patch(f"{CMD_MODULE}.webbrowser"),
            patch(f"{CMD_MODULE}.time.sleep"),
            patch(f"{CMD_MODULE}.time.monotonic", return_value=0),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        for field, sentinel in sentinels.items():
            assert sentinel not in result.output, f"{field} sentinel leaked to CLI output"
            assert field not in result.output, f"{field} key name leaked to CLI output"

    def test_error_output_no_secrets(self, runner) -> None:
        """API error responses must not leak secret material."""
        sentinels = {
            "access_token": "SENTINEL_ACCESS_TOKEN_ERR",
            "refresh_token": "SENTINEL_REFRESH_TOKEN_ERR",
        }
        error_resp = make_response(500, {
            "error": "server_error",
            "message": "Internal error",
            **sentinels,
        })
        mc = MagicMock()
        mc.post.return_value = error_resp
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "authorize", "conn-1", "--project", "proj-1",
            ])

        for field, sentinel in sentinels.items():
            assert sentinel not in result.output, f"{field} sentinel leaked to error output"


class TestConnectorsList:
    def test_list_shows_both_status_fields(self, runner) -> None:
        """Connector list JSON must include both status and authorization_status."""
        list_resp = make_response(200, {
            "data": [
                {
                    "id": "conn-1",
                    "name": "Google Sheets",
                    "provider": "google_sheets",
                    "status": "ACTIVE",
                    "authorization_status": "AUTHORIZED",
                },
                {
                    "id": "conn-2",
                    "name": "Salesforce",
                    "provider": "salesforce",
                    "status": "ACTIVE",
                    "authorization_status": "AUTHORIZATION_REQUIRED",
                },
            ],
            "cursor": None,
        })
        mc = MagicMock()
        mc.get.return_value = list_resp
        mc.close = MagicMock()

        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"),
        ):
            result = runner.invoke(cli, [
                "connectors", "list", "--project", "proj-1",
            ])

        import json
        output = json.loads(result.output)
        assert len(output["data"]) == 2
        for conn in output["data"]:
            assert "status" in conn
            assert "authorization_status" in conn
        assert output["data"][0]["authorization_status"] == "AUTHORIZED"
        assert output["data"][1]["authorization_status"] == "AUTHORIZATION_REQUIRED"
