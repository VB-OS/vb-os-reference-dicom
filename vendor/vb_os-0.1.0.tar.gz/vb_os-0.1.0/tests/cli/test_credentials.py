"""Tests for credential store: keychain validation, file encryption, migration."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from vbos_cli.credentials.file import (
    FILE_VERSION,
    SALT_LENGTH,
    FileStore,
    _derive_key,
)
from vbos_cli.credentials.keychain import (
    KeychainStore,
    is_supported_backend,
)
from vbos_cli.credentials.store import (
    APIKeyCredential,
    CredentialStore,
    SessionCredential,
    credential_from_dict,
    credential_to_dict,
    resolve_credential,
)
from vbos_cli.errors import CredentialStoreError


class TestCredentialSerialization:
    def test_session_roundtrip(self) -> None:
        cred = SessionCredential(kind="session", access_token="acc", refresh_token="ref")
        d = credential_to_dict(cred)
        assert d == {"kind": "session", "access_token": "acc", "refresh_token": "ref"}
        restored = credential_from_dict(d)
        assert isinstance(restored, SessionCredential)
        assert restored.access_token == "acc"
        assert restored.refresh_token == "ref"

    def test_api_key_roundtrip(self) -> None:
        cred = APIKeyCredential(kind="api_key", api_key="vbos_dev_abc")
        d = credential_to_dict(cred)
        assert d == {"kind": "api_key", "api_key": "vbos_dev_abc"}
        restored = credential_from_dict(d)
        assert isinstance(restored, APIKeyCredential)
        assert restored.api_key == "vbos_dev_abc"

    def test_unknown_kind_raises(self) -> None:
        with pytest.raises(CredentialStoreError, match="Unknown credential kind"):
            credential_from_dict({"kind": "oauth"})


class TestKeychainBackendValidation:
    def test_supported_macos_keychain(self) -> None:
        mock_keyring = MagicMock()
        backend = MagicMock()
        backend.__class__.__module__ = "keyring.backends.macOS"
        backend.__class__.__qualname__ = "Keyring"
        mock_keyring.get_keyring.return_value = backend
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            with patch(
                "vbos_cli.credentials.keychain._get_backend_class_name",
                return_value="keyring.backends.macOS.Keyring",
            ):
                assert is_supported_backend()

    def test_unsupported_plaintext_backend(self) -> None:
        with patch(
            "vbos_cli.credentials.keychain._get_backend_class_name",
            return_value="keyring.backends.fail.Keyring",
        ):
            assert not is_supported_backend()

    def test_no_keyring_available(self) -> None:
        with patch(
            "vbos_cli.credentials.keychain._get_backend_class_name",
            return_value="",
        ):
            assert not is_supported_backend()


class TestKeychainStore:
    def test_write_and_read(self) -> None:
        store = KeychainStore("test-profile")
        mock_keyring = MagicMock()
        mock_keyring.get_password.return_value = '{"kind":"session"}'
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            store.write('{"kind":"session"}')
            mock_keyring.set_password.assert_called_once()

    def test_service_includes_profile(self) -> None:
        store = KeychainStore("staging")
        assert store._service == "vbos-cli/staging"


class TestFileStoreEncryption:
    def test_derive_key_deterministic(self) -> None:
        salt = b"0" * SALT_LENGTH
        k1 = _derive_key("test", salt)
        k2 = _derive_key("test", salt)
        assert k1 == k2

    def test_derive_key_different_passphrase(self) -> None:
        salt = b"0" * SALT_LENGTH
        k1 = _derive_key("pass1", salt)
        k2 = _derive_key("pass2", salt)
        assert k1 != k2

    def test_file_store_write_read_roundtrip(self, tmp_path: Path) -> None:
        cred_path = tmp_path / "credentials"
        with (
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["VBOS_DIR"]),
                "VBOS_DIR",
                tmp_path,
            ),
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["CREDENTIALS_PATH"]),
                "CREDENTIALS_PATH",
                cred_path,
            ),
            patch("vbos_cli.credentials.file._prompt_passphrase", return_value="testpass"),
        ):
            store = FileStore("default")
            data = json.dumps({"kind": "session", "access_token": "a", "refresh_token": "r"})
            store.write(data)

            assert cred_path.exists()

            raw = cred_path.read_bytes()
            assert raw[:2] == FILE_VERSION
            assert b'"access_token"' not in raw

            result = store.read()
            assert result is not None
            parsed = json.loads(result)
            assert parsed["access_token"] == "a"
            assert parsed["refresh_token"] == "r"

    def test_file_permissions_0600(self, tmp_path: Path) -> None:
        cred_path = tmp_path / "credentials"
        with (
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["VBOS_DIR"]),
                "VBOS_DIR",
                tmp_path,
            ),
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["CREDENTIALS_PATH"]),
                "CREDENTIALS_PATH",
                cred_path,
            ),
            patch("vbos_cli.credentials.file._prompt_passphrase", return_value="testpass"),
        ):
            store = FileStore("default")
            store.write('{"kind":"session","access_token":"a","refresh_token":"r"}')
            mode = os.stat(cred_path).st_mode
            assert stat.S_IMODE(mode) == 0o600

    def test_wrong_passphrase_raises(self, tmp_path: Path) -> None:
        cred_path = tmp_path / "credentials"
        call_count = 0

        def mock_passphrase(confirm: bool = False) -> str:
            nonlocal call_count
            call_count += 1
            return "correct" if call_count == 1 else "wrong"

        with (
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["VBOS_DIR"]),
                "VBOS_DIR",
                tmp_path,
            ),
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["CREDENTIALS_PATH"]),
                "CREDENTIALS_PATH",
                cred_path,
            ),
            patch("vbos_cli.credentials.file._prompt_passphrase", side_effect=mock_passphrase),
        ):
            store = FileStore("default")
            store.write('{"kind":"session","access_token":"a","refresh_token":"r"}')
            with pytest.raises(CredentialStoreError, match="Wrong passphrase"):
                store.read()

    def test_file_store_profile_sections(self, tmp_path: Path) -> None:
        cred_path = tmp_path / "credentials"
        with (
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["VBOS_DIR"]),
                "VBOS_DIR",
                tmp_path,
            ),
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["CREDENTIALS_PATH"]),
                "CREDENTIALS_PATH",
                cred_path,
            ),
            patch("vbos_cli.credentials.file._prompt_passphrase", return_value="testpass"),
        ):
            store_default = FileStore("default")
            store_staging = FileStore("staging")

            store_default.write('{"kind":"session","access_token":"d","refresh_token":"d"}')
            store_staging.write('{"kind":"api_key","api_key":"vbos_staging"}')

            result_d = store_default.read()
            result_s = store_staging.read()
            assert json.loads(result_d)["access_token"] == "d"
            assert json.loads(result_s)["api_key"] == "vbos_staging"

    def test_delete_removes_profile(self, tmp_path: Path) -> None:
        cred_path = tmp_path / "credentials"
        with (
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["VBOS_DIR"]),
                "VBOS_DIR",
                tmp_path,
            ),
            patch.object(
                __import__("vbos_cli.credentials.file", fromlist=["CREDENTIALS_PATH"]),
                "CREDENTIALS_PATH",
                cred_path,
            ),
            patch("vbos_cli.credentials.file._prompt_passphrase", return_value="testpass"),
        ):
            store = FileStore("default")
            store.write('{"kind":"session","access_token":"a","refresh_token":"r"}')
            store.delete()
            assert store.read() is None


class TestAtomicFileWrite:
    """AC-40: Crash before os.replace preserves old file."""

    def test_crash_before_replace_preserves_old(self, tmp_path: Path) -> None:
        from vbos_cli.credentials import file as file_mod

        cred_path = tmp_path / "credentials"

        with (
            patch.object(file_mod, "VBOS_DIR", tmp_path),
            patch.object(file_mod, "CREDENTIALS_PATH", cred_path),
            patch.object(file_mod, "_prompt_passphrase", return_value="testpass"),
        ):
            store = FileStore("default")
            store.write('{"kind":"session","access_token":"original","refresh_token":"orig_ref"}')
            assert cred_path.exists()

            def failing_replace(src, dst):
                os.unlink(src)
                raise OSError("disk full")

            with patch("os.replace", side_effect=failing_replace):
                try:
                    store.write('{"kind":"session","access_token":"new","refresh_token":"new_ref"}')
                except OSError:
                    pass

            result = store.read()
            assert result is not None
            parsed = json.loads(result)
            assert parsed["access_token"] == "original"

    def test_successful_replacement_leaves_no_temp(self, tmp_path: Path) -> None:
        from vbos_cli.credentials import file as file_mod

        cred_path = tmp_path / "credentials"

        with (
            patch.object(file_mod, "VBOS_DIR", tmp_path),
            patch.object(file_mod, "CREDENTIALS_PATH", cred_path),
            patch.object(file_mod, "_prompt_passphrase", return_value="testpass"),
        ):
            store = FileStore("default")
            store.write('{"kind":"session","access_token":"final","refresh_token":"final_ref"}')

            temp_files = [f for f in os.listdir(tmp_path) if f.startswith(".cred_tmp_")]
            assert len(temp_files) == 0

            result = store.read()
            parsed = json.loads(result)
            assert parsed["access_token"] == "final"


class TestCorruptedFile:
    """UT-S0031-53: Corrupted/truncated credential file fails deterministically."""

    def test_truncated_file_raises_deterministic_error(self, tmp_path: Path) -> None:
        from vbos_cli.credentials import file as file_mod

        cred_path = tmp_path / "credentials"
        cred_path.write_bytes(b"v1" + b"\x00" * 4)

        with (
            patch.object(file_mod, "VBOS_DIR", tmp_path),
            patch.object(file_mod, "CREDENTIALS_PATH", cred_path),
            patch.object(file_mod, "_prompt_passphrase", return_value="testpass"),
        ):
            store = FileStore("default")
            with pytest.raises(CredentialStoreError, match="corrupted or truncated"):
                store.read()


class TestMigration:
    """AC-36: Credential store migration read→write→verify→delete."""

    def test_successful_migration(self) -> None:
        from vbos_cli.credentials.migration import migrate_credentials

        source = MagicMock()
        source.read.return_value = '{"kind":"session","access_token":"a","refresh_token":"r"}'
        dest = MagicMock()
        dest.read.return_value = '{"kind":"session","access_token":"a","refresh_token":"r"}'

        migrate_credentials(source, dest)

        dest.write.assert_called_once_with(source.read.return_value)
        source.delete.assert_called_once()

    def test_migration_verify_failure_preserves_source(self) -> None:
        from vbos_cli.credentials.migration import migrate_credentials

        source = MagicMock()
        source.read.return_value = '{"kind":"session","access_token":"a","refresh_token":"r"}'
        dest = MagicMock()
        dest.read.return_value = '{"kind":"session","access_token":"WRONG","refresh_token":"r"}'

        with pytest.raises(CredentialStoreError, match="verification failed"):
            migrate_credentials(source, dest)

        source.delete.assert_not_called()

    def test_migration_delete_failure_warns_but_succeeds(self) -> None:
        from vbos_cli.credentials.migration import migrate_credentials

        source = MagicMock()
        source.read.return_value = '{"kind":"session","access_token":"a","refresh_token":"r"}'
        source.delete.side_effect = OSError("permission denied")
        dest = MagicMock()
        dest.read.return_value = '{"kind":"session","access_token":"a","refresh_token":"r"}'

        migrate_credentials(source, dest)

        dest.write.assert_called_once()

    def test_migration_no_credentials(self) -> None:
        from vbos_cli.credentials.migration import migrate_credentials

        source = MagicMock()
        source.read.return_value = None
        dest = MagicMock()

        migrate_credentials(source, dest)

        dest.write.assert_not_called()
        source.delete.assert_not_called()


class TestResolveCredential:
    def test_env_var_takes_precedence(self) -> None:
        with patch.dict(os.environ, {"VBOS_API_KEY": "vbos_env_key"}):
            cred = resolve_credential()
            assert isinstance(cred, APIKeyCredential)
            assert cred.api_key == "vbos_env_key"

    def test_no_env_no_store_returns_none(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("VBOS_API_KEY", None)
            with patch(
                "vbos_cli.credentials.store.CredentialStore.load",
                side_effect=CredentialStoreError("no store"),
            ):
                cred = resolve_credential()
                assert cred is None


class TestCredentialStoreNoBackend:
    def test_raises_when_no_store_available(self) -> None:
        with (
            patch("vbos_cli.credentials.store.cfg.get_credential_store_type", return_value=None),
            patch("vbos_cli.credentials.store.is_supported_backend", return_value=False),
        ):
            store = CredentialStore("default")
            with pytest.raises(CredentialStoreError, match="No credential store available"):
                store.store(SessionCredential("session", "a", "r"))
