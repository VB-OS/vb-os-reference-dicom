"""Tests for deployments CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.deployments"


@pytest.fixture
def runner():
    return CliRunner()


class TestDeploymentsList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "dep-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "list",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_list_with_limit(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {"items": []}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "list",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args
        assert call_kwargs[1]["params"]["limit"] == 5


class TestDeploymentsGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "dep-1", "status": "ACTIVE"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "get",
                    "dep-1",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        assert "dep-1" in result.output
        mc.close.assert_called_once()

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "get",
                    "bad-id",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 2


class TestDeploymentsActive:
    def test_active_success(self, runner) -> None:
        body = {"id": "dep-1", "status": "ACTIVE"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "active",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.get.call_args
        assert "/deployments/active" in call_args[0][0]
        mc.close.assert_called_once()

    def test_active_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "active",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 2


class TestDeploymentsPromote:
    def test_promote_success(self, runner) -> None:
        body = {"id": "dep-new", "status": "PENDING"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments", "promote",
                    "--project", "proj",
                    "--from", "staging",
                    "--to", "production",
                    "--version", "ver-123",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/environments/production/deployments" in call_args[0][0]
        assert call_args[1]["json_body"]["source_environment"] == "staging"
        assert call_args[1]["json_body"]["boundary_version_id"] == "ver-123"
        mc.close.assert_called_once()

    def test_promote_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                422, {"error": "validation_error", "message": "Bad version"},
            ),
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments", "promote",
                    "--project", "proj",
                    "--from", "staging",
                    "--to", "production",
                    "--version", "bad-ver",
                ],
            )
        assert result.exit_code == 2
        mc.close.assert_called_once()


class TestDeploymentsRollback:
    def test_rollback_with_confirm(self, runner) -> None:
        body = {"id": "dep-1", "status": "ROLLED_BACK"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "rollback",
                    "dep-1",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.post.assert_called_once()

    def test_rollback_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "deployments",
                    "rollback",
                    "dep-1",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
                input="n\n",
            )
        mc.post.assert_not_called()


class TestDeploymentsApprove:
    def test_approve_success(self, runner) -> None:
        body = {"id": "dep-1", "status": "APPROVED"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "approve",
                    "dep-1",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/dep-1/approve" in call_args[0][0]
        mc.close.assert_called_once()

    def test_approve_not_found(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "approve",
                    "bad-id",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 2


class TestDeploymentsReject:
    def test_reject_success(self, runner) -> None:
        body = {"id": "dep-1", "status": "REJECTED"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "reject",
                    "dep-1",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/dep-1/reject" in call_args[0][0]
        mc.close.assert_called_once()

    def test_reject_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(500, {"error": "internal_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "deployments",
                    "reject",
                    "dep-1",
                    "--project",
                    "proj",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 2
