"""Unit tests for environments CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


CMD_MODULE = "vbos_cli.commands.environments"


class TestEnvironmentsCreate:
    def test_create_success(self, runner) -> None:
        resp_body = {"id": "env-001", "name": "staging", "project_id": "proj-1"}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "create",
                    "--project",
                    "proj-1",
                    "--name",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "env-001"
        assert data["name"] == "staging"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/environments",
            json_body={"name": "staging"},
        )
        mc.close.assert_called_once()

    def test_create_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Invalid"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "create",
                    "--project",
                    "proj-1",
                    "--name",
                    "bad",
                ],
            )
        assert result.exit_code == 2

    def test_create_missing_name(self, runner) -> None:
        result = runner.invoke(cli, ["environments", "create", "--project", "proj-1"])
        assert result.exit_code != 0


class TestEnvironmentsList:
    def test_list_success(self, runner) -> None:
        resp_body = {"items": [{"id": "env-1"}, {"id": "env-2"}], "cursor": None}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["environments", "list", "--project", "proj-1"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["items"]) == 2
        mc.close.assert_called_once()

    def test_list_with_limit(self, runner) -> None:
        resp_body = {"items": [{"id": "env-1"}]}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "list",
                    "--project",
                    "proj-1",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once_with(
            "/v1/projects/proj-1/environments",
            params={"limit": 5},
        )

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(500, {"error": "internal_error", "message": "Fail"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["environments", "list", "--project", "proj-1"])
        assert result.exit_code == 2


class TestEnvironmentsGet:
    def test_get_success(self, runner) -> None:
        resp_body = {"id": "env-001", "name": "production"}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "get",
                    "env-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "env-001"
        mc.get.assert_called_once_with("/v1/projects/proj-1/environments/env-001")
        mc.close.assert_called_once()

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "get",
                    "missing",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestEnvironmentsUpdate:
    def test_update_success(self, runner) -> None:
        resp_body = {"id": "env-001", "name": "renamed-env"}
        mc = make_mock_client(patch_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "update",
                    "env-001",
                    "--project",
                    "proj-1",
                    "--name",
                    "renamed-env",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "renamed-env"
        mc.patch.assert_called_once_with(
            "/v1/projects/proj-1/environments/env-001",
            json_body={"name": "renamed-env"},
        )
        mc.close.assert_called_once()

    def test_update_api_error(self, runner) -> None:
        mc = make_mock_client(
            patch_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "update",
                    "bad-id",
                    "--project",
                    "proj-1",
                    "--name",
                    "x",
                ],
            )
        assert result.exit_code == 2


class TestEnvironmentsArchive:
    def test_archive_success(self, runner) -> None:
        resp_body = {"id": "env-001", "status": "archived"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "archive",
                    "env-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "archived"
        mc.post.assert_called_once_with("/v1/projects/proj-1/environments/env-001/archive")
        mc.close.assert_called_once()

    def test_archive_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Already archived"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "archive",
                    "env-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestEnvironmentsUnarchive:
    def test_unarchive_success(self, runner) -> None:
        resp_body = {"id": "env-001", "status": "active"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "unarchive",
                    "env-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "active"
        mc.post.assert_called_once_with("/v1/projects/proj-1/environments/env-001/unarchive")
        mc.close.assert_called_once()

    def test_unarchive_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Not archived"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "environments",
                    "unarchive",
                    "env-001",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2
