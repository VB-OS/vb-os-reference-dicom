"""Cross-cutting error handling tests: API errors, connection errors, timeouts."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestAPIErrorHandling:
    def test_401_exits_2(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                401,
                {
                    "error": "unauthorized",
                    "message": "Invalid credentials",
                },
            )
        )
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "test",
                ],
            )
        assert result.exit_code == 2

    def test_403_exits_2(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                403,
                {
                    "error": "forbidden",
                    "message": "Insufficient permissions",
                },
            )
        )
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "test",
                ],
            )
        assert result.exit_code == 2

    def test_404_exits_2(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                404,
                {
                    "error": "not_found",
                    "message": "Not found",
                },
            )
        )
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "get",
                    "nonexistent",
                    "--project",
                    "test",
                ],
            )
        assert result.exit_code == 2

    def test_500_exits_2(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Internal server error",
                },
            )
        )
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "test",
                ],
            )
        assert result.exit_code == 2


class TestClientClose:
    def test_client_closed_on_success(self, runner) -> None:
        mc = make_mock_client()
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            runner.invoke(cli, ["evaluations", "list", "--project", "test"])
        mc.close.assert_called_once()

    def test_client_closed_on_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(500, {"error": "fail"}))
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            runner.invoke(cli, ["evaluations", "list", "--project", "test"])
        mc.close.assert_called_once()
