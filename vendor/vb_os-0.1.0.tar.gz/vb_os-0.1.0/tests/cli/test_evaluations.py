"""Tests for the evaluations CLI command group."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import PAGINATED_RESPONSE, make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


CMD_MODULE = "vbos_cli.commands.evaluations"


def _patch_project():
    return patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1")


class TestEvaluationsList:
    def test_list_basic(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        call_args = mc.get.call_args
        assert "/evaluations" in call_args[0][0]

    def test_list_pagination_params(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "proj-1",
                    "--limit",
                    "10",
                    "--cursor",
                    "abc123",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args[1]
        params = call_kwargs.get("params", {})
        assert params.get("limit") == 10
        assert params.get("cursor") == "abc123"

    def test_list_all_flag_paginates(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with (
            patch(f"{CMD_MODULE}.make_client", return_value=mc),
            patch(
                f"{CMD_MODULE}.paginate_all", return_value=PAGINATED_RESPONSE["items"]
            ) as mock_pag,
            _patch_project(),
        ):
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "proj-1",
                    "--all",
                ],
            )
        assert result.exit_code == 0
        mock_pag.assert_called_once()

    def test_list_decision_filter(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "proj-1",
                    "--decision",
                    "ASSERT",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args[1]
        params = call_kwargs.get("params", {})
        assert params.get("decision") == "ASSERT"

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Server error",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2

    def test_list_client_closed(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(cli, ["evaluations", "list", "--project", "proj-1"])
        mc.close.assert_called_once()


class TestEvaluationsGet:
    def test_get_by_id(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                200,
                {
                    "id": "eval-123",
                    "decision": "ASSERT",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "get",
                    "eval-123",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.get.call_args
        assert "eval-123" in call_args[0][0]
        assert "eval-123" in result.output

    def test_get_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                404,
                {
                    "error": "not_found",
                    "message": "Evaluation not found",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "get",
                    "nonexistent",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2

    def test_get_client_closed(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {"id": "eval-123"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(cli, ["evaluations", "get", "eval-123", "--project", "proj-1"])
        mc.close.assert_called_once()


class TestEvaluationsSearch:
    def test_search_passes_query(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "search",
                    "--project",
                    "proj-1",
                    "--query",
                    "my-search-term",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args[1]
        params = call_kwargs.get("params", {})
        assert params.get("q") == "my-search-term"

    def test_search_includes_project(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, PAGINATED_RESPONSE))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "search",
                    "--project",
                    "proj-1",
                    "--query",
                    "test",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args[1]
        params = call_kwargs.get("params", {})
        assert params.get("project") == "proj-1"

    def test_search_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                422,
                {
                    "error": "validation_error",
                    "message": "Invalid query",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "search",
                    "--project",
                    "proj-1",
                    "--query",
                    "bad",
                ],
            )
        assert result.exit_code == 2


class TestEvaluationsExport:
    def test_export_post(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                202,
                {
                    "id": "export-001",
                    "status": "pending",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "export",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/export" in call_args[0][0]

    def test_export_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Export failed",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "export",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2

    def test_export_client_closed(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(202, {"id": "export-001"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(cli, ["evaluations", "export", "--project", "proj-1"])
        mc.close.assert_called_once()


class TestEvaluationsShare:
    def test_share_post_with_eval_id(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "id": "share-001",
                    "url": "https://example.com/share/share-001",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "share",
                    "eval-999",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "eval-999" in call_args[0][0]
        assert "/share" in call_args[0][0]

    def test_share_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                404,
                {
                    "error": "not_found",
                    "message": "Evaluation not found",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "share",
                    "nonexistent",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2

    def test_share_client_closed(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(200, {"id": "share-001"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(cli, ["evaluations", "share", "eval-1", "--project", "proj-1"])
        mc.close.assert_called_once()


class TestEvaluationsReplayAnalysis:
    def test_replay_analysis_post(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                202,
                {
                    "id": "ra-001",
                    "status": "pending",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "replay-analysis",
                    "bdry-ref",
                    "ver-42",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/evaluations/replay-analysis" in call_args[0][0]
        assert call_args[1]["json_body"]["boundary_ref"] == "bdry-ref"
        assert call_args[1]["json_body"]["version_id"] == "ver-42"

    def test_replay_analysis_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Replay analysis failed",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "replay-analysis",
                    "bdry-ref",
                    "ver-42",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2

    def test_replay_analysis_client_closed(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(202, {"id": "ra-001"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(
                cli,
                [
                    "evaluations",
                    "replay-analysis",
                    "bdry-ref",
                    "ver-42",
                    "--project",
                    "proj-1",
                ],
            )
        mc.close.assert_called_once()
