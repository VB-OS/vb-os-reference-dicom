"""Tests for flows CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.flows"


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def definition_file(tmp_path):
    """Create a temporary JSON definition file."""
    path = tmp_path / "definition.json"
    path.write_text(json.dumps({"steps": [{"type": "verify", "boundary": "b-1"}]}))
    return str(path)


@pytest.fixture
def evidence_file(tmp_path):
    """Create a temporary JSON evidence file."""
    path = tmp_path / "evidence.json"
    path.write_text(json.dumps({"npi_number": 1234567890}))
    return str(path)


@pytest.fixture
def import_file(tmp_path):
    """Create a temporary JSON import file."""
    path = tmp_path / "flow_export.json"
    path.write_text(json.dumps({"name": "imported-flow", "definition": {"steps": []}}))
    return str(path)


class TestFlowsCreate:
    def test_create_success(self, runner, definition_file) -> None:
        resp = make_response(201, {"id": "flow-1", "name": "my-flow"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "create",
                    "--project",
                    "proj-1",
                    "--name",
                    "my-flow",
                    "--definition",
                    definition_file,
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/flows" in call_args[0][0]
        payload = call_args[1]["json"]
        assert payload["name"] == "my-flow"
        assert payload["definition"]["steps"][0]["type"] == "verify"

    def test_create_api_error(self, runner, definition_file) -> None:
        mc = make_mock_client(post_resp=make_response(422, {"error": "validation_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "create",
                    "--project",
                    "p",
                    "--name",
                    "n",
                    "--definition",
                    definition_file,
                ],
            )
        assert result.exit_code == 2

    def test_create_closes_client(self, runner, definition_file) -> None:
        mc = make_mock_client(post_resp=make_response(201, {"id": "f1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "flows",
                    "create",
                    "--project",
                    "p",
                    "--name",
                    "n",
                    "--definition",
                    definition_file,
                ],
            )
        mc.close.assert_called_once()


class TestFlowsList:
    def test_list_success(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "f-1"}, {"id": "f-2"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["flows", "list", "--project", "proj-1"])
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows" in mc.get.call_args[0][0]

    def test_list_with_pagination(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "f-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "list",
                    "--project",
                    "p",
                    "--limit",
                    "3",
                    "--cursor",
                    "cur1",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("limit") == 3
        assert params.get("cursor") == "cur1"


class TestFlowsGet:
    def test_get_success(self, runner) -> None:
        resp = make_response(200, {"id": "flow-1", "name": "my-flow"})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "get",
                    "flow-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/flow-1" in mc.get.call_args[0][0]

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "get",
                    "bad",
                    "--project",
                    "p",
                ],
            )
        assert result.exit_code == 2


class TestFlowsUpdate:
    def test_update_name(self, runner) -> None:
        resp = make_response(200, {"id": "flow-1", "name": "renamed"})
        mc = make_mock_client(patch_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "update",
                    "flow-1",
                    "--project",
                    "proj-1",
                    "--name",
                    "renamed",
                ],
            )
        assert result.exit_code == 0
        payload = mc.patch.call_args[1]["json"]
        assert payload["name"] == "renamed"

    def test_update_api_error(self, runner) -> None:
        mc = make_mock_client(patch_resp=make_response(400, {"error": "bad"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "update",
                    "flow-1",
                    "--project",
                    "p",
                    "--name",
                    "x",
                ],
            )
        assert result.exit_code == 2


class TestFlowsDelete:
    def test_delete_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "delete",
                    "flow-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()

    def test_delete_requires_confirm_in_non_interactive(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "delete",
                    "flow-1",
                    "--project",
                    "p",
                ],
            )
        assert result.exit_code == 2
        assert "confirmation_required" in result.output or "--confirm" in result.output

    def test_delete_200_response(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(200, {"id": "flow-1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "delete",
                    "flow-1",
                    "--project",
                    "p",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0


class TestFlowsExport:
    def test_export_success(self, runner, tmp_path) -> None:
        dest = str(tmp_path / "exported.json")
        resp = make_response(200, {"id": "flow-1", "name": "my-flow", "steps": []})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "export",
                    "flow-1",
                    "--project",
                    "proj-1",
                    "--output",
                    dest,
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/flow-1" in mc.get.call_args[0][0]
        with open(dest) as f:
            exported = json.load(f)
        assert exported["id"] == "flow-1"

    def test_export_api_error(self, runner, tmp_path) -> None:
        dest = str(tmp_path / "out.json")
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "export",
                    "bad",
                    "--project",
                    "p",
                    "--output",
                    dest,
                ],
            )
        assert result.exit_code == 2


class TestFlowsImport:
    def test_import_success(self, runner, import_file) -> None:
        resp = make_response(201, {"id": "flow-new"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "import",
                    "--project",
                    "proj-1",
                    "--file",
                    import_file,
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/import" in mc.post.call_args[0][0]

    def test_import_api_error(self, runner, import_file) -> None:
        mc = make_mock_client(post_resp=make_response(400, {"error": "bad_format"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "import",
                    "--project",
                    "p",
                    "--file",
                    import_file,
                ],
            )
        assert result.exit_code == 2


class TestFlowsFromTemplate:
    def test_from_template_success(self, runner) -> None:
        resp = make_response(201, {"id": "flow-from-tmpl"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "from-template",
                    "hipaa-basic",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/flows/from-template" in call_args[0][0]
        assert call_args[1]["json"]["template"] == "hipaa-basic"


class TestFlowsDeploy:
    def test_deploy_success(self, runner) -> None:
        resp = make_response(201, {"id": "dep-1", "status": "deploying"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "deploy",
                    "flow-1",
                    "v-1",
                    "--project",
                    "proj-1",
                    "--environment",
                    "staging",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/flows/flow-1/versions/v-1/deploy" in call_args[0][0]
        assert call_args[1]["json"]["environment"] == "staging"


class TestFlowsSuspend:
    def test_suspend_success(self, runner) -> None:
        resp = make_response(200, {"id": "dep-1", "status": "suspended"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "suspend",
                    "dep-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/deployments/dep-1/suspend" in mc.post.call_args[0][0]


class TestFlowsResume:
    def test_resume_success(self, runner) -> None:
        resp = make_response(200, {"id": "dep-1", "status": "active"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "resume",
                    "dep-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/deployments/dep-1/resume" in mc.post.call_args[0][0]


class TestFlowsDryRun:
    def test_dry_run_success(self, runner, evidence_file) -> None:
        resp = make_response(200, {"id": "run-1", "result": "ASSERT"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "dry-run",
                    "flow-1",
                    "v-1",
                    "--project",
                    "proj-1",
                    "--decision",
                    "approve",
                    "--evidence",
                    evidence_file,
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/flows/flow-1/versions/v-1/dry-run" in call_args[0][0]
        payload = call_args[1]["json"]
        assert payload["decision"] == "approve"
        assert payload["evidence"]["npi_number"] == 1234567890

    def test_dry_run_api_error(self, runner, evidence_file) -> None:
        mc = make_mock_client(post_resp=make_response(422, {"error": "validation_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "dry-run",
                    "f",
                    "v",
                    "--project",
                    "p",
                    "--decision",
                    "d",
                    "--evidence",
                    evidence_file,
                ],
            )
        assert result.exit_code == 2


# --- Versions subgroup ---


class TestVersionsCreate:
    def test_create_version(self, runner, definition_file) -> None:
        resp = make_response(201, {"id": "ver-1"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "create",
                    "flow-1",
                    "--project",
                    "proj-1",
                    "--definition",
                    definition_file,
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/flows/flow-1/versions" in call_args[0][0]
        assert "definition" in call_args[1]["json"]


class TestVersionsList:
    def test_list_versions(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "v-1"}, {"id": "v-2"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "list",
                    "flow-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/flow-1/versions" in mc.get.call_args[0][0]


class TestVersionsGet:
    def test_get_version(self, runner) -> None:
        resp = make_response(200, {"id": "v-1", "status": "draft"})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "get",
                    "flow-1",
                    "v-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/flow-1/versions/v-1" in mc.get.call_args[0][0]


class TestVersionsUpdate:
    def test_update_version(self, runner, definition_file) -> None:
        resp = make_response(200, {"id": "v-1"})
        mc = make_mock_client(patch_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "update",
                    "flow-1",
                    "v-1",
                    "--project",
                    "proj-1",
                    "--definition",
                    definition_file,
                ],
            )
        assert result.exit_code == 0
        call_args = mc.patch.call_args
        assert "/v1/projects/proj-1/flows/flow-1/versions/v-1" in call_args[0][0]
        assert "definition" in call_args[1]["json"]


class TestVersionsDelete:
    def test_delete_version_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "delete",
                    "flow-1",
                    "v-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()

    def test_delete_version_200(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(200, {"id": "v-1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "delete",
                    "flow-1",
                    "v-1",
                    "--project",
                    "p",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0


class TestVersionsApprove:
    def test_approve_version(self, runner) -> None:
        resp = make_response(200, {"id": "v-1", "status": "approved"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "versions",
                    "approve",
                    "flow-1",
                    "v-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/flow-1/versions/v-1/approve" in mc.post.call_args[0][0]


# --- Executions subgroup ---


class TestExecutionsList:
    def test_list_executions(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "exec-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "executions",
                    "list",
                    "flow-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/flows/flow-1/executions" in mc.get.call_args[0][0]

    def test_list_executions_with_pagination(self, runner) -> None:
        resp = make_response(200, {"items": []})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "executions",
                    "list",
                    "flow-1",
                    "--project",
                    "p",
                    "--limit",
                    "10",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("limit") == 10


class TestExecutionsReconstruct:
    def test_reconstruct_success(self, runner) -> None:
        resp = make_response(200, {"id": "exec-1", "reconstructed": True})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "executions",
                    "reconstruct",
                    "flow-1",
                    "exec-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert (
            "/v1/projects/proj-1/flows/flow-1/executions/exec-1/reconstruct"
            in mc.get.call_args[0][0]
        )

    def test_reconstruct_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "flows",
                    "executions",
                    "reconstruct",
                    "flow-1",
                    "bad",
                    "--project",
                    "p",
                ],
            )
        assert result.exit_code == 2
