"""Tests for shared formatting infrastructure (formatters.py)."""

from __future__ import annotations

import json
import os
import stat

from vbos_cli.formatters import (
    _atomic_write,
    format_output,
    format_secret,
    paginate_all,
    quiet_id,
    quiet_id_list,
    quiet_verdict,
)


class TestAtomicWrite:
    def test_creates_file_with_0600_permissions(self, tmp_path) -> None:
        path = str(tmp_path / "test.json")
        _atomic_write(path, '{"ok": true}')
        assert os.path.exists(path)
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600

    def test_overwrites_existing_file(self, tmp_path) -> None:
        path = str(tmp_path / "test.json")
        _atomic_write(path, "first")
        _atomic_write(path, "second")
        with open(path) as f:
            assert f.read() == "second"


class TestFormatOutput:
    def test_json_format_to_stdout(self, capsys) -> None:
        data = {"id": "abc", "name": "test"}
        format_output(data, fmt="json")
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed["id"] == "abc"

    def test_quiet_mode_extracts_id(self, capsys) -> None:
        data = {"id": "abc-123"}
        format_output(data, fmt="json", quiet=True, quiet_extractor=quiet_id)
        captured = capsys.readouterr()
        assert captured.out.strip() == "abc-123"

    def test_output_to_file(self, tmp_path) -> None:
        path = str(tmp_path / "out.json")
        data = {"id": "test"}
        format_output(data, fmt="json", output_file=path)
        with open(path) as f:
            parsed = json.loads(f.read())
        assert parsed["id"] == "test"
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600


class TestFormatSecret:
    def test_secret_output_to_stdout(self, capsys) -> None:
        data = {"id": "key-1", "api_key": "vbos_secret_xxx"}
        format_secret(data, secret_key="api_key")
        captured = capsys.readouterr()
        assert "vbos_secret_xxx" in captured.out

    def test_secret_to_file(self, tmp_path) -> None:
        path = str(tmp_path / "secret.txt")
        data = {"id": "key-1", "api_key": "vbos_secret_xxx"}
        format_secret(data, secret_key="api_key", output_file=path)
        with open(path) as f:
            content = f.read()
        assert "vbos_secret_xxx" in content


class TestQuietExtractors:
    def test_quiet_id_extracts_id(self) -> None:
        assert quiet_id({"id": "abc"}) == "abc"

    def test_quiet_id_list_extracts_ids(self) -> None:
        data = {"items": [{"id": "a"}, {"id": "b"}]}
        result = quiet_id_list(data)
        assert result == "a\nb"

    def test_quiet_verdict_extracts_decision(self) -> None:
        data = {"decision": "ASSERT", "verdict": "ASSERT"}
        assert quiet_verdict(data) == "ASSERT"


class TestPaginateAll:
    def test_detects_cursor_loop(self) -> None:
        from unittest.mock import MagicMock

        client = MagicMock()
        resp1 = MagicMock()
        resp1.status_code = 200
        resp1.json.return_value = {
            "items": [{"id": "1"}],
            "cursor": "cursor-A",
            "has_more": True,
        }
        resp2 = MagicMock()
        resp2.status_code = 200
        resp2.json.return_value = {
            "items": [{"id": "2"}],
            "cursor": "cursor-A",
            "has_more": True,
        }
        client.get.side_effect = [resp1, resp2]

        result = paginate_all(client, "/test", {})
        assert len(result) == 2

    def test_collects_all_pages(self) -> None:
        from unittest.mock import MagicMock

        client = MagicMock()
        resp1 = MagicMock()
        resp1.status_code = 200
        resp1.json.return_value = {
            "items": [{"id": "1"}],
            "cursor": "cursor-B",
            "has_more": True,
        }
        resp2 = MagicMock()
        resp2.status_code = 200
        resp2.json.return_value = {
            "items": [{"id": "2"}],
            "cursor": None,
            "has_more": False,
        }
        client.get.side_effect = [resp1, resp2]

        result = paginate_all(client, "/test", {})
        assert len(result) == 2
        assert result[0]["id"] == "1"
        assert result[1]["id"] == "2"
