from __future__ import annotations

import json
import os
import tempfile
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.governed_workspaces"


@pytest.fixture
def runner():
    return CliRunner()


class TestGovernedWorkspacesProvision:
    def test_provision_success(self, runner) -> None:
        config_data = {"name": "ws-1", "policy": {"rules": []}}
        body = {"id": "ws-new", "name": "ws-1"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(config_data, f)
            config_path = f.name
        try:
            with patch(f"{CMD_MODULE}.make_client", return_value=mc):
                result = runner.invoke(
                    cli,
                    [
                        "governed-workspaces",
                        "provision",
                        "--project",
                        "proj",
                        "--config",
                        config_path,
                    ],
                )
            assert result.exit_code == 0
            call_args = mc.post.call_args
            assert call_args[1]["json_body"] == config_data
            mc.close.assert_called_once()
        finally:
            os.unlink(config_path)


class TestGovernedWorkspacesList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "ws-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["governed-workspaces", "list", "--project", "proj"]
            )
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()


class TestGovernedWorkspacesGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "ws-1", "name": "Workspace One"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                ["governed-workspaces", "get", "ws-1", "--project", "proj"],
            )
        assert result.exit_code == 0
        assert "ws-1" in result.output


class TestGovernedWorkspacesDeploy:
    def test_deploy_success(self, runner) -> None:
        body = {"id": "ws-1", "status": "deployed"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "governed-workspaces",
                    "deploy",
                    "ws-1",
                    "--project",
                    "proj",
                    "--version",
                    "v-1",
                ],
            )
        assert result.exit_code == 0
        mc.post.assert_called_once()
        call_url = mc.post.call_args[0][0]
        assert "/versions/v-1/deploy" in call_url
        mc.close.assert_called_once()


class TestGovernedWorkspacesEvaluate:
    def test_evaluate_success(self, runner) -> None:
        instance_resp = make_response(201, {"id": "inst-1"})
        submit_resp = make_response(200, {"id": "inst-1", "status": "submitted"})
        mc = make_mock_client(post_resp=instance_resp)
        mc.post.side_effect = [instance_resp, submit_resp]
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "governed-workspaces",
                    "evaluate",
                    "ws-1",
                    "--project",
                    "proj",
                ],
            )
        assert result.exit_code == 0
        assert mc.post.call_count == 2
        mc.close.assert_called_once()


class TestGovernedWorkspacesSeal:
    def test_seal_success(self, runner) -> None:
        body = {"id": "ws-1", "status": "archived"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "governed-workspaces",
                    "seal",
                    "ws-1",
                    "--project",
                    "proj",
                    "--version",
                    "v-1",
                ],
            )
        assert result.exit_code == 0
        call_url = mc.post.call_args[0][0]
        assert "/versions/v-1/archive" in call_url
        mc.close.assert_called_once()


class TestGovernedWorkspacesTeardown:
    def test_teardown_with_confirm(self, runner) -> None:
        body = {"id": "ws-1", "status": "torn_down"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "governed-workspaces",
                    "teardown",
                    "ws-1",
                    "--project",
                    "proj",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.post.assert_called_once()
        mc.close.assert_called_once()

    def test_teardown_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "governed-workspaces",
                    "teardown",
                    "ws-1",
                    "--project",
                    "proj",
                ],
                input="n\n",
            )
        mc.post.assert_not_called()
