"""Integration tests IT-S0031-01 through IT-S0031-08.

Each test exercises a full CLI flow with mocked HTTP responses.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from vbos_cli.cli import cli
from vbos_cli.credentials.store import (
    APIKeyCredential,
    SessionCredential,
)


def _mock_response(status_code: int, body: dict | None = None, headers: dict | None = None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = body or {}
    resp.headers = headers or {}
    resp.text = json.dumps(body or {})
    return resp


class TestIT01LoginConfigLogoutCycle:
    """IT-S0031-01: Full login -> config -> logout cycle."""

    def test_full_cycle(self, tmp_path: Path) -> None:
        runner = CliRunner()

        login_resp = _mock_response(
            200,
            {
                "access_token": "acc.tok.en",
                "refresh_token": "ref.tok.en",
            },
        )
        logout_resp = _mock_response(200)

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="secret"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = login_resp
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 0

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert isinstance(stored, SessionCredential)
            assert stored.access_token == "acc.tok.en"
            assert stored.refresh_token == "ref.tok.en"

        with (
            patch("vbos_cli.config.VBOS_DIR", tmp_path / ".vbos"),
            patch("vbos_cli.config.CONFIG_PATH", tmp_path / ".vbos" / "config"),
        ):
            from vbos_cli import config as cfg

            cfg.set_value("default-project", "myproject", "default")
            assert cfg.get_value("default-project", "default") == "myproject"

        cred = SessionCredential(
            kind="session",
            access_token="acc.tok.en",
            refresh_token="ref.tok.en",
        )
        with (
            patch("vbos_cli.commands.auth.resolve_credential", return_value=cred),
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore2,
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient2,
        ):
            client_inst2 = MockClient2.return_value
            client_inst2.post.return_value = logout_resp
            client_inst2.close = MagicMock()
            store_inst2 = MockCredStore2.return_value

            result = runner.invoke(cli, ["logout"])
            assert result.exit_code == 0
            store_inst2.delete.assert_called_once()
            client_inst2.post.assert_called_once()


class TestIT02TokenLoginAPICallLogout:
    """IT-S0031-02: --token login -> API call -> logout."""

    def test_api_key_flow(self) -> None:
        runner = CliRunner()

        me_resp = _mock_response(200, {"email": "ci@test.com", "id": "u2"})

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
        ):
            client_inst = MockClient.return_value
            client_inst.get.return_value = me_resp
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login", "--token", "vbos_dev_test123"])
            assert result.exit_code == 0

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert isinstance(stored, APIKeyCredential)
            assert stored.api_key == "vbos_dev_test123"

            call_args = client_inst.get.call_args
            assert call_args[0][0] == "/v1/users/me"
            auth_header = call_args[1].get("headers", {}).get("Authorization")
            assert auth_header == "Bearer vbos_dev_test123"


class TestIT03PreRequestTokenRefresh:
    """IT-S0031-03: Pre-request token refresh mid-session."""

    def test_expired_jwt_triggers_refresh(self) -> None:
        import base64 as b64

        from vbos_cli.client import AuthenticatedClient

        now = int(time.time())

        def _make_fake_jwt(payload: dict) -> str:
            header = b64.urlsafe_b64encode(b'{"alg":"RS256"}').rstrip(b"=").decode()
            body = b64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
            return f"{header}.{body}.sig"

        expired_jwt = _make_fake_jwt({"exp": now - 60})
        fresh_jwt = _make_fake_jwt({"exp": now + 3600})

        refresh_resp = _mock_response(
            200,
            {
                "access_token": fresh_jwt,
                "refresh_token": "new_refresh",
            },
        )
        api_resp = _mock_response(200, {"data": "ok"})
        cred = SessionCredential(
            kind="session",
            access_token=expired_jwt,
            refresh_token="old_refresh",
        )

        with (
            patch("vbos_cli.client.httpx") as mock_httpx,
            patch("vbos_cli.client.resolve_credential", return_value=cred),
            patch("vbos_cli.client.CredentialStore") as MockStore,
        ):
            mock_session = MagicMock()
            mock_httpx.Client.return_value = mock_session

            mock_session.post.return_value = refresh_resp
            mock_session.request.return_value = api_resp

            store_inst = MockStore.return_value

            client = AuthenticatedClient(base_url="http://localhost:8000", profile="default")

            resp = client.get("/v1/test")

            assert resp.status_code == 200
            mock_session.post.assert_called_once()
            refresh_call = mock_session.post.call_args
            assert "/v1/auth/refresh" in str(refresh_call)
            mock_session.request.assert_called_once()
            store_inst.store.assert_called_once()


class TestIT04MFALoginFlow:
    """IT-S0031-04: MFA login -> TOTP verify -> session created."""

    def test_mfa_challenge_then_totp(self) -> None:
        runner = CliRunner()

        login_resp = _mock_response(
            200,
            {
                "mfa_required": True,
                "mfa_token": "mfa.challenge.token",
            },
        )
        mfa_verify_resp = _mock_response(
            200,
            {
                "access_token": "mfa.access.token",
                "refresh_token": "mfa.refresh.token",
            },
        )

        getpass_calls = iter(["secret", "123456"])

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", side_effect=getpass_calls),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.side_effect = [login_resp, mfa_verify_resp]
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 0

            assert client_inst.post.call_count == 2

            mfa_call = client_inst.post.call_args_list[1]
            assert mfa_call[0][0] == "/v1/auth/mfa/verify"
            assert mfa_call[1]["json_body"]["mfa_token"] == "mfa.challenge.token"
            assert mfa_call[1]["json_body"]["code"] == "123456"

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert isinstance(stored, SessionCredential)
            assert stored.access_token == "mfa.access.token"


class TestIT05MultiOrgLogin:
    """IT-S0031-05: Multi-org login -> org selection -> session."""

    def test_org_selection(self) -> None:
        runner = CliRunner()

        org_list_resp = _mock_response(
            400,
            {
                "error": "org_selection_required",
                "message": "Select organization",
                "organizations": [
                    {"org_id": "org-1", "org_name": "Acme Corp", "org_role": "ADMIN"},
                    {"org_id": "org-2", "org_name": "Beta Inc", "org_role": "MEMBER"},
                    {"org_id": "org-3", "org_name": "Gamma LLC", "org_role": "VIEWER"},
                ],
            },
        )
        login_success_resp = _mock_response(
            200,
            {
                "access_token": "org2.access",
                "refresh_token": "org2.refresh",
            },
        )

        input_calls = iter(["user@test.com", "2"])

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", side_effect=input_calls),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="password"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.side_effect = [org_list_resp, login_success_resp]
            client_inst.close = MagicMock()
            store_inst = MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 0

            second_login = client_inst.post.call_args_list[1]
            assert second_login[1]["json_body"]["org_id"] == "org-2"

            store_inst.store.assert_called_once()
            stored = store_inst.store.call_args[0][0]
            assert stored.access_token == "org2.access"


class TestIT06EnvVarAuth:
    """IT-S0031-06: VBOS_API_KEY env var -> API call succeeds."""

    def test_env_var_auth_used(self) -> None:
        from vbos_cli.credentials.store import resolve_credential

        with patch.dict(os.environ, {"VBOS_API_KEY": "vbos_dev_envkey"}):
            cred = resolve_credential("default")
            assert isinstance(cred, APIKeyCredential)
            assert cred.api_key == "vbos_dev_envkey"

    def test_env_var_logout_prints_unset_guidance(self) -> None:
        runner = CliRunner()

        with patch.dict(os.environ, {"VBOS_API_KEY": "vbos_dev_envkey"}):
            with patch("vbos_cli.commands.auth.resolve_credential", return_value=None):
                result = runner.invoke(cli, ["logout"])
                assert result.exit_code == 0
                assert "VBOS_API_KEY" in result.output


class TestIT07ProfileIsolation:
    """IT-S0031-07: Two profiles have independent credentials."""

    def test_independent_profiles(self, tmp_path: Path) -> None:
        from vbos_cli.credentials import file as file_mod
        from vbos_cli.credentials.file import FileStore

        creds_path = tmp_path / "credentials"

        with (
            patch.object(file_mod, "CREDENTIALS_PATH", creds_path),
            patch.object(file_mod, "VBOS_DIR", tmp_path),
            patch.object(file_mod, "_prompt_passphrase", return_value="testpass"),
        ):
            store_default = FileStore("default")
            store_staging = FileStore("staging")

            cred_default_data = json.dumps(
                {
                    "kind": "session",
                    "access_token": "default_acc",
                    "refresh_token": "default_ref",
                }
            )
            cred_staging_data = json.dumps(
                {
                    "kind": "session",
                    "access_token": "staging_acc",
                    "refresh_token": "staging_ref",
                }
            )

            store_default.write(cred_default_data)
            store_staging.write(cred_staging_data)

            loaded_default = json.loads(store_default.read())
            loaded_staging = json.loads(store_staging.read())

            assert loaded_default["access_token"] == "default_acc"
            assert loaded_staging["access_token"] == "staging_acc"

            store_default.delete()
            assert store_default.read() is None
            assert store_staging.read() is not None


class TestIT08CLIRefresh30Day:
    """IT-S0031-08: CLI refresh uses 30-day expiry (backend contract)."""

    def test_cli_login_sends_cli_client_type(self) -> None:
        runner = CliRunner()

        login_resp = _mock_response(
            200,
            {
                "access_token": "acc",
                "refresh_token": "ref",
            },
        )

        with (
            patch("vbos_cli.commands.auth.AuthenticatedClient") as MockClient,
            patch("vbos_cli.commands.auth.CredentialStore") as MockCredStore,
            patch("builtins.input", return_value="user@test.com"),
            patch("vbos_cli.commands.auth.getpass.getpass", return_value="pass"),
            patch("vbos_cli.commands.auth.cfg"),
        ):
            client_inst = MockClient.return_value
            client_inst.post.return_value = login_resp
            client_inst.close = MagicMock()
            MockCredStore.return_value

            result = runner.invoke(cli, ["login"])
            assert result.exit_code == 0

            login_call = client_inst.post.call_args_list[0]
            body = login_call[1]["json_body"]
            assert body["client_type"] == "cli"
