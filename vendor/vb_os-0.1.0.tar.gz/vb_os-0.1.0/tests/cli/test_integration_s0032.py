"""Integration tests for S0032 CLI commands (IT-01 through IT-06).

These tests verify end-to-end workflows across multiple command groups.
"""

from __future__ import annotations

import json
import os
import stat
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestIT01VerifyEndToEnd:
    """IT-01: Verify command full lifecycle."""

    def test_assert_exit_0_json(self, runner, tmp_path) -> None:
        workload_path = str(tmp_path / "workload.json")
        with open(workload_path, "w") as f:
            json.dump({"amount": 100, "currency": "USD"}, f)

        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                    "evaluation_id": "eval-001",
                },
            )
        )
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "test-proj",
                    "--environment",
                    "prod",
                    "--workload",
                    workload_path,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["decision"] == "ASSERT"

    def test_defer_exit_1(self, runner, tmp_path) -> None:
        workload_path = str(tmp_path / "workload.json")
        with open(workload_path, "w") as f:
            json.dump({"amount": 100}, f)

        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "DEFER",
                    "evaluation_id": "eval-002",
                },
            )
        )
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "test-proj",
                    "--environment",
                    "prod",
                    "--workload",
                    workload_path,
                ],
            )
        assert result.exit_code == 1

    def test_quiet_mode_outputs_verdict_only(self, runner, tmp_path) -> None:
        workload_path = str(tmp_path / "workload.json")
        with open(workload_path, "w") as f:
            json.dump({"amount": 100}, f)

        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                    "verdict": "ASSERT",
                },
            )
        )
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "test-proj",
                    "--environment",
                    "prod",
                    "--workload",
                    workload_path,
                    "--quiet",
                ],
            )
        assert result.exit_code == 0
        assert result.output.strip() == "ASSERT"


class TestIT02BoundaryLifecycle:
    """IT-02: Boundary create -> version -> promote lifecycle."""

    def test_create_boundary(self, runner, tmp_path) -> None:
        dsl_path = str(tmp_path / "boundary.vbos")
        with open(dsl_path, "w") as f:
            f.write("BOUNDARY { amount > 0 }")

        mc = make_mock_client(
            post_resp=make_response(
                201,
                {
                    "id": "bnd-001",
                    "name": "test-boundary",
                },
            )
        )
        with patch("vbos_cli.commands.boundaries.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "boundaries",
                    "create",
                    "--project",
                    "proj",
                    "--name",
                    "Test Boundary",
                    "--ref",
                    "B_TEST",
                    "--source",
                    dsl_path,
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "bnd-001"


class TestIT03ProjectSetup:
    """IT-03: Project creation flow."""

    def test_create_project(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                201,
                {
                    "id": "proj-001",
                    "slug": "my-proj",
                },
            )
        )
        with patch("vbos_cli.commands.projects.make_client", return_value=mc):
            r = runner.invoke(
                cli,
                [
                    "projects",
                    "create",
                    "--name",
                    "My Project",
                    "--workspace",
                    "ws-001",
                ],
            )
        assert r.exit_code == 0
        data = json.loads(r.output)
        assert data["slug"] == "my-proj"

    def test_create_environment(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                201,
                {
                    "id": "env-001",
                    "name": "staging",
                },
            )
        )
        with patch("vbos_cli.commands.environments.make_client", return_value=mc):
            r = runner.invoke(
                cli,
                [
                    "environments",
                    "create",
                    "--name",
                    "staging",
                    "--project",
                    "my-proj",
                ],
            )
        assert r.exit_code == 0


class TestIT04OutputFilePermissions:
    """IT-04: All output files created with 0600 permissions."""

    def test_verify_output_file_permissions(self, runner, tmp_path) -> None:
        workload_path = str(tmp_path / "workload.json")
        output_path = str(tmp_path / "result.json")
        with open(workload_path, "w") as f:
            json.dump({"amount": 100}, f)

        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                    "evaluation_id": "eval-001",
                },
            )
        )
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "proj",
                    "--environment",
                    "prod",
                    "--workload",
                    workload_path,
                    "--output",
                    output_path,
                ],
            )
        assert result.exit_code == 0
        assert os.path.exists(output_path)
        mode = stat.S_IMODE(os.stat(output_path).st_mode)
        assert mode == 0o600

    def test_evaluations_output_file_permissions(self, runner, tmp_path) -> None:
        output_path = str(tmp_path / "evals.json")
        mc = make_mock_client(
            get_resp=make_response(
                200,
                {
                    "items": [{"id": "eval-1"}],
                    "cursor": None,
                    "has_more": False,
                },
            )
        )
        with patch("vbos_cli.commands.evaluations.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "evaluations",
                    "list",
                    "--project",
                    "proj",
                    "--output",
                    output_path,
                ],
            )
        assert result.exit_code == 0
        assert os.path.exists(output_path)
        mode = stat.S_IMODE(os.stat(output_path).st_mode)
        assert mode == 0o600


class TestIT05SemanticExitCodes:
    """IT-05: Exit code contract — 0=ASSERT, 1=DEFER, 2=error."""

    def test_verify_assert_exits_0(self, runner, tmp_path) -> None:
        wp = str(tmp_path / "w.json")
        with open(wp, "w") as f:
            json.dump({}, f)
        mc = make_mock_client(post_resp=make_response(200, {"decision": "ASSERT"}))
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            r = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "p",
                    "--environment",
                    "e",
                    "--workload",
                    wp,
                ],
            )
        assert r.exit_code == 0

    def test_verify_defer_exits_1(self, runner, tmp_path) -> None:
        wp = str(tmp_path / "w.json")
        with open(wp, "w") as f:
            json.dump({}, f)
        mc = make_mock_client(post_resp=make_response(200, {"decision": "DEFER"}))
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            r = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "p",
                    "--environment",
                    "e",
                    "--workload",
                    wp,
                ],
            )
        assert r.exit_code == 1

    def test_api_error_exits_2(self, runner, tmp_path) -> None:
        wp = str(tmp_path / "w.json")
        with open(wp, "w") as f:
            json.dump({}, f)
        mc = make_mock_client(post_resp=make_response(500, {"error": "internal"}))
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            r = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "p",
                    "--environment",
                    "e",
                    "--workload",
                    wp,
                ],
            )
        assert r.exit_code == 2

    def test_batch_any_defer_exits_1(self, runner, tmp_path) -> None:
        wp = str(tmp_path / "w.json")
        with open(wp, "w") as f:
            json.dump([{"a": 1}, {"b": 2}], f)
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "MIXED",
                    "results": [
                        {"decision": "ASSERT"},
                        {"decision": "DEFER"},
                    ],
                },
            )
        )
        with patch("vbos_cli.commands.verify.make_client", return_value=mc):
            r = runner.invoke(
                cli,
                [
                    "verify",
                    "--project",
                    "p",
                    "--environment",
                    "e",
                    "--workload",
                    wp,
                    "--batch",
                ],
            )
        assert r.exit_code == 1


class TestIT06DestructiveConfirmation:
    """IT-06: Destructive operations require --yes or confirmation."""

    def test_delete_project_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204))
        with patch("vbos_cli.commands.projects.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "projects",
                    "delete",
                    "proj-001",
                    "--confirm",
                ],
            )
        mc.delete.assert_called_once()

    def test_archive_workspace_with_confirm(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(200, {"id": "ws-1", "status": "archived"}))
        with patch("vbos_cli.commands.workspaces.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "workspaces",
                    "archive",
                    "ws-001",
                    "--confirm",
                ],
            )
        mc.post.assert_called_once()
