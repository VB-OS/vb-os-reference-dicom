"""Unit tests for keys CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


CMD_MODULE = "vbos_cli.commands.keys"


class TestKeysCreate:
    def test_create_success(self, runner) -> None:
        resp_body = {
            "id": "key-001",
            "name": "prod-key",
            "api_key": "vbos_live_abc123secret",
            "scopes": ["verify", "read"],
        }
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "create",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                    "--name",
                    "prod-key",
                    "--scopes",
                    "verify,read",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["api_key"] == "vbos_live_abc123secret"
        assert data["name"] == "prod-key"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/environments/production/api-keys",
            json_body={"name": "prod-key", "scopes": ["verify", "read"]},
        )
        mc.close.assert_called_once()

    def test_create_scopes_trimmed(self, runner) -> None:
        resp_body = {"id": "key-002", "api_key": "vbos_live_xyz", "scopes": ["verify", "read"]}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "create",
                    "--project",
                    "proj-1",
                    "--environment",
                    "staging",
                    "--name",
                    "k",
                    "--scopes",
                    " verify , read ",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["scopes"] == ["verify", "read"]

    def test_create_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Bad scopes"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "create",
                    "--project",
                    "proj-1",
                    "--environment",
                    "staging",
                    "--name",
                    "k",
                    "--scopes",
                    "invalid",
                ],
            )
        assert result.exit_code == 2


class TestKeysList:
    def test_list_success(self, runner) -> None:
        resp_body = {"items": [{"id": "key-1"}, {"id": "key-2"}], "cursor": None}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "list",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["items"]) == 2
        mc.close.assert_called_once()

    def test_list_with_limit(self, runner) -> None:
        resp_body = {"items": [{"id": "key-1"}]}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "list",
                    "--project",
                    "proj-1",
                    "--environment",
                    "staging",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        mc.get.assert_called_once_with(
            "/v1/projects/proj-1/environments/staging/api-keys",
            params={"limit": 5},
        )

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(500, {"error": "internal_error", "message": "Fail"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "list",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 2


class TestKeysGet:
    def test_get_success(self, runner) -> None:
        resp_body = {"id": "key-001", "name": "my-key", "scopes": ["verify"]}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "get",
                    "key-001",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "key-001"
        mc.get.assert_called_once_with(
            "/v1/projects/proj-1/environments/production/api-keys/key-001"
        )
        mc.close.assert_called_once()

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Key not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "get",
                    "missing",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 2


class TestKeysRotate:
    def test_rotate_success(self, runner) -> None:
        resp_body = {"id": "key-001", "api_key": "vbos_live_newrotated"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "rotate",
                    "key-001",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["api_key"] == "vbos_live_newrotated"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-1/environments/production/api-keys/key-001/rotate",
        )
        mc.close.assert_called_once()

    def test_rotate_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(404, {"error": "not_found", "message": "Key not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "rotate",
                    "missing",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 2


class TestKeysRevoke:
    def test_revoke_with_confirm_204(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "revoke",
                    "key-001",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once_with(
            "/v1/projects/proj-1/environments/production/api-keys/key-001",
        )
        mc.close.assert_called_once()

    def test_revoke_with_confirm_200(self, runner) -> None:
        resp_body = {"id": "key-001", "status": "revoked"}
        mc = make_mock_client(delete_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "revoke",
                    "key-001",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "revoked"

    def test_revoke_without_confirm(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "revoke",
                    "key-001",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                ],
            )
        assert result.exit_code == 2

    def test_revoke_api_error(self, runner) -> None:
        mc = make_mock_client(
            delete_resp=make_response(403, {"error": "forbidden", "message": "No permission"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "keys",
                    "revoke",
                    "key-001",
                    "--project",
                    "proj-1",
                    "--environment",
                    "production",
                    "--confirm",
                ],
            )
        assert result.exit_code == 2
