"""Tests for the local binary bridge (local_bridge.py)."""

from __future__ import annotations

import struct
from unittest.mock import MagicMock, patch

import pytest

from vbos_cli.local_bridge import (
    BUNDLE_MAGIC,
    CANONICAL_TOOLCHAIN_ID,
    DEFAULT_BINARY_PATH,
    DEFAULT_BOUNDARY_REF,
    ENGINE_DECISION_MAP,
    FORMAT_VERSION,
    _build_a_input_001,
    _find_binary,
    _parse_audit_parity,
    _to_binary_dsl,
    _verify_install,
)


class TestFindBinary:
    def test_finds_on_path(self) -> None:
        with patch("shutil.which", return_value="/usr/local/bin/vb-os"):
            assert _find_binary() == "/usr/local/bin/vb-os"

    def test_falls_back_to_default(self) -> None:
        with patch("shutil.which", return_value=None):
            with patch("os.path.isfile", return_value=True):
                with patch("os.access", return_value=True):
                    assert _find_binary() == DEFAULT_BINARY_PATH

    def test_raises_when_not_found(self) -> None:
        with patch("shutil.which", return_value=None):
            with patch("os.path.isfile", return_value=False):
                with pytest.raises(FileNotFoundError, match="vb-os binary not found"):
                    _find_binary()


class TestVerifyInstall:
    def test_success(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stderr=b"")
            _verify_install("/usr/bin/vb-os")

    def test_failure_raises(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1,
                stderr=b"hash mismatch",
            )
            with pytest.raises(RuntimeError, match="integrity verification failed"):
                _verify_install("/usr/bin/vb-os")


class TestBuildAInput001:
    def test_bundle_structure(self) -> None:
        workload = b'{"amount":100}'
        bundle = _build_a_input_001(workload)

        assert bundle[:8] == BUNDLE_MAGIC
        assert bundle[8] == FORMAT_VERSION
        assert bundle[9:41] == CANONICAL_TOOLCHAIN_ID
        assert bundle[41:105] == DEFAULT_BOUNDARY_REF

        payload_len = struct.unpack("<Q", bundle[105:113])[0]
        assert payload_len == len(workload)
        assert bundle[113:] == workload

    def test_custom_boundary_ref(self) -> None:
        ref = b"a" * 64
        bundle = _build_a_input_001(b"{}", ref)
        assert bundle[41:105] == ref


class TestToBinaryDSL:
    def test_strips_require_type(self) -> None:
        dsl = "require_type: amount: integer\npredicate: check: amount > 0"
        result = _to_binary_dsl(dsl)
        assert "require_type" not in result
        assert "predicate" in result

    def test_replaces_arrow_with_colon(self) -> None:
        dsl = "predicate: check => amount > 0"
        result = _to_binary_dsl(dsl)
        assert "=>" not in result
        assert ":" in result

    def test_wraps_bare_expressions(self) -> None:
        dsl = "amount > 0 AND currency == 1"
        result = _to_binary_dsl(dsl)
        assert "BOUNDARY" in result


class TestParseAuditParity:
    def test_extracts_all_fields(self) -> None:
        audit = {
            "admissibility_check": {"status": "PASS", "missing": []},
            "prohibition_check": {"status": "PASS", "detected": []},
            "predicate_results": [
                {
                    "name": "amount_check",
                    "field": "amount",
                    "op": "<=",
                    "passed": True,
                    "actual_value": 500,
                },
            ],
        }
        parity = _parse_audit_parity(audit)
        assert "admissibility" in parity
        assert "prohibitions" in parity
        assert "predicate_outcomes" in parity
        assert len(parity["predicate_outcomes"]) == 1
        assert parity["predicate_outcomes"][0]["name"] == "amount_check"

    def test_handles_missing_fields(self) -> None:
        parity = _parse_audit_parity({})
        assert "admissibility" not in parity
        assert "prohibitions" not in parity
        assert "predicate_outcomes" not in parity


class TestEngineDecisionMap:
    def test_accept_maps_to_assert(self) -> None:
        assert ENGINE_DECISION_MAP["ACCEPT"] == "ASSERT"

    def test_reject_maps_to_defer(self) -> None:
        assert ENGINE_DECISION_MAP["REJECT"] == "DEFER"
