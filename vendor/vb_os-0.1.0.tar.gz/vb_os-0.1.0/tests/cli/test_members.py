"""Tests for members CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.members"


@pytest.fixture
def runner():
    return CliRunner()


class TestMembersList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "mem-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "list"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_list_with_pagination(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {"items": []}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "list", "--limit", "10"])
        assert result.exit_code == 0


class TestMembersInvite:
    def test_invite_success(self, runner) -> None:
        body = {"id": "mem-new", "email": "new@example.com", "role": "viewer"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                ["members", "invite", "--email", "new@example.com", "--role", "viewer"],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["email"] == "new@example.com"
        assert call_args[1]["json_body"]["role"] == "viewer"

    def test_invite_missing_email(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "invite", "--role", "viewer"])
        assert result.exit_code != 0


class TestMembersRole:
    def test_role_success(self, runner) -> None:
        body = {"id": "mem-1", "role": "admin"}
        mc = make_mock_client(patch_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "role", "mem-1", "--role", "admin"])
        assert result.exit_code == 0
        call_args = mc.patch.call_args
        assert call_args[1]["json_body"]["role"] == "admin"

    def test_role_missing_role_option(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "role", "mem-1"])
        assert result.exit_code != 0


class TestMembersSuspend:
    def test_suspend_success(self, runner) -> None:
        body = {"id": "mem-1", "status": "suspended"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "suspend", "mem-1"])
        assert result.exit_code == 0
        mc.post.assert_called_once()
        mc.close.assert_called_once()

    def test_suspend_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "suspend", "mem-1"])
        assert result.exit_code == 2


class TestMembersReactivate:
    def test_reactivate_success(self, runner) -> None:
        body = {"id": "mem-1", "status": "active"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "reactivate", "mem-1"])
        assert result.exit_code == 0
        mc.post.assert_called_once()
        mc.close.assert_called_once()

    def test_reactivate_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "reactivate", "mem-1"])
        assert result.exit_code == 2


class TestMembersRemove:
    def test_remove_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["members", "remove", "mem-1", "--confirm"])
        assert result.exit_code == 0
        mc.delete.assert_called_once()

    def test_remove_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(cli, ["members", "remove", "mem-1"], input="n\n")
        mc.delete.assert_not_called()
