"""Tests for named-sets CLI commands."""

from __future__ import annotations

import json
import os
import tempfile
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.named_sets"


@pytest.fixture
def runner():
    return CliRunner()


class TestNamedSetsList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "ns-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["named-sets", "list", "--project", "proj"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()


class TestNamedSetsGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "ns-1", "name": "Test Set"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["named-sets", "get", "ns-1", "--project", "proj"])
        assert result.exit_code == 0
        assert "ns-1" in result.output


class TestNamedSetsCreate:
    def test_create_reads_items_file(self, runner) -> None:
        items_data = [{"field": "npi", "value": "1234567890"}]
        body = {"id": "ns-new", "name": "New Set"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(items_data, f)
            items_path = f.name
        try:
            with patch(f"{CMD_MODULE}.make_client", return_value=mc):
                result = runner.invoke(
                    cli,
                    [
                        "named-sets",
                        "create",
                        "--project",
                        "proj",
                        "--name",
                        "New Set",
                        "--items",
                        items_path,
                    ],
                )
            assert result.exit_code == 0
            call_args = mc.post.call_args
            assert call_args[1]["json_body"]["items"] == items_data
            assert call_args[1]["json_body"]["name"] == "New Set"
        finally:
            os.unlink(items_path)

    def test_create_missing_items(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "named-sets",
                    "create",
                    "--project",
                    "proj",
                    "--name",
                    "New Set",
                ],
            )
        assert result.exit_code != 0


class TestNamedSetsUpdate:
    def test_update_name(self, runner) -> None:
        body = {"id": "ns-1", "name": "Renamed"}
        mc = make_mock_client(patch_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "named-sets",
                    "update",
                    "ns-1",
                    "--project",
                    "proj",
                    "--name",
                    "Renamed",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.patch.call_args
        assert call_args[1]["json_body"]["name"] == "Renamed"


class TestNamedSetsDelete:
    def test_delete_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "named-sets",
                    "delete",
                    "ns-1",
                    "--project",
                    "proj",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()

    def test_delete_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "named-sets",
                    "delete",
                    "ns-1",
                    "--project",
                    "proj",
                ],
                input="n\n",
            )
        mc.delete.assert_not_called()
