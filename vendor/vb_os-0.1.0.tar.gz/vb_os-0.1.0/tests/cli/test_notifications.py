"""Tests for notifications CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.notifications"


@pytest.fixture
def runner():
    return CliRunner()


class TestNotificationsList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "notif-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(cli, ["notifications", "list", "--project", "my-proj"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_list_with_limit(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(200, {"items": []}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(
                cli, ["notifications", "list", "--project", "my-proj", "--limit", "5"]
            )
        assert result.exit_code == 0
        call_kwargs = mc.get.call_args
        assert call_kwargs[1]["params"]["limit"] == 5

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(401, {"error": "unauthorized"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(cli, ["notifications", "list", "--project", "my-proj"])
        assert result.exit_code == 2
        mc.close.assert_called_once()


class TestNotificationsRead:
    def test_read_success(self, runner) -> None:
        body = {"id": "notif-1", "read": True}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(
                cli, ["notifications", "read", "notif-1", "--project", "my-proj"]
            )
        assert result.exit_code == 0
        mc.post.assert_called_once()
        call_args = mc.post.call_args
        assert "/notifications/notif-1/read" in call_args[0][0]
        mc.close.assert_called_once()

    def test_read_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(
                cli, ["notifications", "read", "notif-1", "--project", "my-proj"]
            )
        assert result.exit_code == 2


class TestNotificationsUnread:
    def test_unread_success(self, runner) -> None:
        body = {"id": "notif-1", "read": False}
        mc = make_mock_client(delete_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(
                cli, ["notifications", "unread", "notif-1", "--project", "my-proj"]
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()
        call_args = mc.delete.call_args
        assert "/notifications/notif-1/read" in call_args[0][0]
        mc.close.assert_called_once()

    def test_unread_api_error(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), patch(
            f"{CMD_MODULE}.resolve_project", return_value="my-proj"
        ):
            result = runner.invoke(
                cli, ["notifications", "unread", "notif-1", "--project", "my-proj"]
            )
        assert result.exit_code == 2
