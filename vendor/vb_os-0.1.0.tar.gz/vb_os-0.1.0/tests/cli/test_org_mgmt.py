"""Tests for org CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.org_mgmt"


@pytest.fixture
def runner():
    return CliRunner()


class TestOrgGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "org-1", "name": "My Org"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "get"])
        assert result.exit_code == 0
        assert "org-1" in result.output
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_get_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(401, {"error": "unauthorized"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "get"])
        assert result.exit_code == 2


class TestOrgUpdate:
    def test_update_name(self, runner) -> None:
        body = {"id": "org-1", "name": "Updated Org"}
        mc = make_mock_client(patch_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "update", "--name", "Updated Org"])
        assert result.exit_code == 0
        call_args = mc.patch.call_args
        assert call_args[1]["json_body"]["name"] == "Updated Org"

    def test_update_missing_name(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "update"])
        assert result.exit_code != 0


class TestOrgSettingsGet:
    def test_settings_get_success(self, runner) -> None:
        body = {"feature_flags": {"replay": True}}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "settings", "get"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_settings_get_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(403, {"error": "forbidden"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "settings", "get"])
        assert result.exit_code == 2


class TestOrgSettingsUpdate:
    def test_settings_update_success(self, runner) -> None:
        body = {"replay_enabled": "true", "max_members": "50"}
        mc = make_mock_client(put_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "org", "settings", "update",
                    "--setting", "replay_enabled=true",
                    "--setting", "max_members=50",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.put.call_args
        assert call_args[1]["json_body"]["replay_enabled"] == "true"
        assert call_args[1]["json_body"]["max_members"] == "50"

    def test_settings_update_invalid_format(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                ["org", "settings", "update", "--setting", "bad_format"],
            )
        assert result.exit_code == 2

    def test_settings_update_missing_setting(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["org", "settings", "update"])
        assert result.exit_code != 0
