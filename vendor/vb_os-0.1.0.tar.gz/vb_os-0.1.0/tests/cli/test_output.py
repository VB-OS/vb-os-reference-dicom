"""Tests for output module."""

from __future__ import annotations

import io
import json
import sys

from vbos_cli.output import print_banner, print_error, print_json, print_result, print_table, stderr


class TestPrintJson:
    def test_outputs_valid_json(self) -> None:
        buf = io.StringIO()
        print_json({"key": "value"}, file=buf)
        parsed = json.loads(buf.getvalue())
        assert parsed == {"key": "value"}


class TestPrintTable:
    def test_table_output(self, capsys) -> None:
        rows = [{"name": "Alice", "role": "ADMIN"}, {"name": "Bob", "role": "MEMBER"}]
        print_table(rows)
        captured = capsys.readouterr()
        assert "NAME" in captured.out
        assert "ROLE" in captured.out
        assert "Alice" in captured.out
        assert "Bob" in captured.out

    def test_empty_rows(self, capsys) -> None:
        print_table([])
        captured = capsys.readouterr()
        assert captured.out == ""


class TestPrintResult:
    def test_json_format_dict(self) -> None:
        buf = io.StringIO()
        import sys

        old = sys.stdout
        sys.stdout = buf
        try:
            print_result({"a": 1}, "json")
        finally:
            sys.stdout = old
        parsed = json.loads(buf.getvalue())
        assert parsed == {"a": 1}


class TestPrintError:
    def test_error_on_stderr(self, capsys) -> None:
        print_error("auth_failed", "Bad credentials")
        captured = capsys.readouterr()
        parsed = json.loads(captured.err)
        assert parsed["error"] == "auth_failed"
        assert parsed["message"] == "Bad credentials"

    def test_error_with_request_id(self, capsys) -> None:
        print_error("not_found", "Not found", request_id="req-1")
        captured = capsys.readouterr()
        parsed = json.loads(captured.err)
        assert parsed["request_id"] == "req-1"


class TestBanner:
    def test_banner_skipped_when_not_tty(self, capsys) -> None:
        print_banner()
        captured = capsys.readouterr()
        assert captured.err == ""

    def test_banner_prints_when_tty(self, capsys, monkeypatch) -> None:
        fake = type(
            "FakeTTY",
            (),
            {
                "isatty": lambda self: True,
                "write": sys.stderr.write,
                "flush": lambda self: None,
            },
        )()
        monkeypatch.setattr("sys.stderr", fake)
        print_banner()
        captured = capsys.readouterr()
        assert "██" in captured.err
        assert "Deterministic Execution Authority" in captured.err


class TestStderr:
    def test_stderr_output(self, capsys) -> None:
        stderr("hello")
        captured = capsys.readouterr()
        assert "hello" in captured.err
