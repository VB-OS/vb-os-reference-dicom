"""Tests for profile resolution."""

from __future__ import annotations

import os
from unittest.mock import patch

from vbos_cli.profiles import DEFAULT_PROFILE, PROFILE_ENV_VAR, resolve_profile


class TestResolveProfile:
    def test_flag_takes_precedence(self) -> None:
        with patch.dict(os.environ, {PROFILE_ENV_VAR: "staging"}):
            assert resolve_profile("prod") == "prod"

    def test_env_var_used_when_no_flag(self) -> None:
        with patch.dict(os.environ, {PROFILE_ENV_VAR: "staging"}):
            assert resolve_profile(None) == "staging"

    def test_default_when_nothing_set(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop(PROFILE_ENV_VAR, None)
            assert resolve_profile(None) == DEFAULT_PROFILE

    def test_default_profile_is_default(self) -> None:
        assert DEFAULT_PROFILE == "default"
