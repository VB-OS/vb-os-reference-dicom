"""Unit tests for projects CLI commands."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


CMD_MODULE = "vbos_cli.commands.projects"


class TestProjectsCreate:
    def test_create_success(self, runner) -> None:
        resp_body = {"id": "proj-001", "name": "My Project", "workspace_id": "ws-1"}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["projects", "create", "--name", "My Project", "--workspace", "ws-1"]
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "proj-001"
        assert data["name"] == "My Project"
        mc.post.assert_called_once_with(
            "/v1/projects", json_body={"name": "My Project", "workspace_id": "ws-1"}
        )
        mc.close.assert_called_once()

    def test_create_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(422, {"error": "validation_error", "message": "Name taken"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli, ["projects", "create", "--name", "dup", "--workspace", "ws-1"]
            )
        assert result.exit_code == 2
        mc.close.assert_called_once()

    def test_create_missing_name(self, runner) -> None:
        result = runner.invoke(cli, ["projects", "create", "--workspace", "ws-1"])
        assert result.exit_code != 0
        assert (
            "Missing" in result.output
            or "required" in result.output.lower()
            or result.exit_code == 2
        )


class TestProjectsList:
    def test_list_success(self, runner) -> None:
        resp_body = {"items": [{"id": "p1"}, {"id": "p2"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "list"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["items"]) == 2
        mc.close.assert_called_once()

    def test_list_with_limit(self, runner) -> None:
        resp_body = {"items": [{"id": "p1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "list", "--limit", "10"])
        assert result.exit_code == 0
        mc.get.assert_called_once_with("/v1/projects", params={"limit": 10})

    def test_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(500, {"error": "internal_error", "message": "Server error"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "list"])
        assert result.exit_code == 2


class TestProjectsGet:
    def test_get_success(self, runner) -> None:
        resp_body = {"id": "proj-001", "name": "My Project"}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "get", "proj-001"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["id"] == "proj-001"
        mc.get.assert_called_once_with("/v1/projects/proj-001")
        mc.close.assert_called_once()

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "get", "nonexistent"])
        assert result.exit_code == 2


class TestProjectsUpdate:
    def test_update_success(self, runner) -> None:
        resp_body = {"id": "proj-001", "name": "Renamed"}
        mc = make_mock_client(patch_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "update", "proj-001", "--name", "Renamed"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "Renamed"
        mc.patch.assert_called_once_with("/v1/projects/proj-001", json_body={"name": "Renamed"})
        mc.close.assert_called_once()

    def test_update_api_error(self, runner) -> None:
        mc = make_mock_client(
            patch_resp=make_response(404, {"error": "not_found", "message": "Not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "update", "bad-id", "--name", "X"])
        assert result.exit_code == 2


class TestProjectsArchive:
    def test_archive_success(self, runner) -> None:
        resp_body = {"id": "proj-001", "status": "archived"}
        mc = make_mock_client(post_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "archive", "proj-001"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "archived"
        mc.post.assert_called_once_with("/v1/projects/proj-001/archive")
        mc.close.assert_called_once()

    def test_archive_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Already archived"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "archive", "proj-001"])
        assert result.exit_code == 2


class TestProjectsDelete:
    def test_delete_with_confirm_flag(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "delete", "proj-001", "--confirm"])
        assert result.exit_code == 0
        mc.delete.assert_called_once_with("/v1/projects/proj-001")
        mc.close.assert_called_once()

    def test_delete_returns_body(self, runner) -> None:
        resp_body = {"id": "proj-001", "deleted": True}
        mc = make_mock_client(delete_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "delete", "proj-001", "--confirm"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["deleted"] is True

    def test_delete_without_confirm_non_interactive(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "delete", "proj-001"])
        assert result.exit_code == 2

    def test_delete_api_error(self, runner) -> None:
        mc = make_mock_client(
            delete_resp=make_response(403, {"error": "forbidden", "message": "No permission"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "delete", "proj-001", "--confirm"])
        assert result.exit_code == 2


class TestProjectsMembersList:
    def test_members_list_success(self, runner) -> None:
        resp_body = {"items": [{"id": "u1", "role": "admin"}, {"id": "u2", "role": "viewer"}]}
        mc = make_mock_client(get_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "members", "list", "proj-001"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["items"]) == 2
        mc.get.assert_called_once_with(
            "/v1/projects/proj-001/members",
            params={},
        )
        mc.close.assert_called_once()

    def test_members_list_api_error(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(404, {"error": "not_found", "message": "Project not found"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["projects", "members", "list", "bad-proj"])
        assert result.exit_code == 2


class TestProjectsMembersAdd:
    def test_members_add_success(self, runner) -> None:
        resp_body = {"id": "membership-1", "user_id": "u1", "role": "editor"}
        mc = make_mock_client(post_resp=make_response(201, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "projects",
                    "members",
                    "add",
                    "proj-001",
                    "--user",
                    "u1",
                    "--role",
                    "editor",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["user_id"] == "u1"
        mc.post.assert_called_once_with(
            "/v1/projects/proj-001/members",
            json_body={"user_id": "u1", "role": "editor"},
        )
        mc.close.assert_called_once()

    def test_members_add_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(409, {"error": "conflict", "message": "Already a member"})
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "projects",
                    "members",
                    "add",
                    "proj-001",
                    "--user",
                    "u1",
                    "--role",
                    "editor",
                ],
            )
        assert result.exit_code == 2


class TestProjectsMembersRemove:
    def test_members_remove_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "projects",
                    "members",
                    "remove",
                    "proj-001",
                    "--user",
                    "u1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once_with("/v1/projects/proj-001/members/u1")
        mc.close.assert_called_once()

    def test_members_remove_returns_body(self, runner) -> None:
        resp_body = {"removed": True, "user_id": "u1"}
        mc = make_mock_client(delete_resp=make_response(200, resp_body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "projects",
                    "members",
                    "remove",
                    "proj-001",
                    "--user",
                    "u1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["removed"] is True

    def test_members_remove_without_confirm(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "projects",
                    "members",
                    "remove",
                    "proj-001",
                    "--user",
                    "u1",
                ],
            )
        assert result.exit_code == 2
