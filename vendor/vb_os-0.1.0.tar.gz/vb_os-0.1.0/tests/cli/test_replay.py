"""Tests for the replay CLI command."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


CMD_MODULE = "vbos_cli.commands.replay"


def _patch_project():
    return patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1")


class TestReplayBasic:
    def test_replay_by_evaluation_id(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                201,
                {
                    "id": "replay-001",
                    "evaluation_id": "eval-123",
                    "status": "completed",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "replay",
                    "eval-123",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "eval-123" in call_args[0][0]
        assert "/replay" in call_args[0][0]
        assert "replay-001" in result.output

    def test_replay_posts_correct_path(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "id": "replay-002",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(
                cli,
                [
                    "replay",
                    "eval-456",
                    "--project",
                    "proj-1",
                ],
            )
        expected_path = "/v1/projects/proj-1/evaluations/eval-456/replay"
        mc.post.assert_called_once_with(expected_path)


class TestReplayAPIError:
    def test_api_error_exits_2(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                404,
                {
                    "error": "not_found",
                    "message": "Evaluation not found",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "replay",
                    "nonexistent",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2

    def test_server_error_exits_2(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Server error",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            result = runner.invoke(
                cli,
                [
                    "replay",
                    "eval-123",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestReplayClientLifecycle:
    def test_client_closed_after_success(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "id": "replay-001",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(
                cli,
                [
                    "replay",
                    "eval-123",
                    "--project",
                    "proj-1",
                ],
            )
        mc.close.assert_called_once()

    def test_client_closed_after_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Server error",
                },
            )
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), _patch_project():
            runner.invoke(
                cli,
                [
                    "replay",
                    "eval-123",
                    "--project",
                    "proj-1",
                ],
            )
        mc.close.assert_called_once()
