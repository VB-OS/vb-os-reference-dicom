from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.templates"


@pytest.fixture
def runner():
    return CliRunner()


class TestTemplatesList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "tpl-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["templates", "list"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()

    def test_list_with_domain_filter(self, runner) -> None:
        body = {"items": [{"id": "tpl-2"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["templates", "list", "--domain", "healthcare"])
        assert result.exit_code == 0
        call_args = mc.get.call_args
        assert call_args[1]["params"]["domain"] == "healthcare"
        mc.close.assert_called_once()

    def test_list_client_close_on_error(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(500, {"error": "server_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(cli, ["templates", "list"])
        mc.close.assert_called_once()


class TestTemplatesGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "tpl-1", "name": "Test Template", "slug": "test-template"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["templates", "get", "test-template"])
        assert result.exit_code == 0
        assert "tpl-1" in result.output
        mc.close.assert_called_once()

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(
            get_resp=make_response(
                404, {"error": "not_found", "message": "Template not found"},
            ),
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(cli, ["templates", "get", "nonexistent"])
        mc.get.assert_called_once()
        mc.close.assert_called_once()


class TestTemplatesFork:
    def test_fork_success(self, runner) -> None:
        body = {"id": "boundary-new", "name": "My Fork"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), \
             patch(f"{CMD_MODULE}.resolve_project", return_value="my-project"):
            result = runner.invoke(
                cli,
                [
                    "templates", "fork", "test-template",
                    "--project", "my-project", "--name", "My Fork",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["project_id"] == "my-project"
        assert call_args[1]["json_body"]["name"] == "My Fork"
        mc.close.assert_called_once()

    def test_fork_api_error(self, runner) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                422, {"error": "validation_error", "message": "Invalid"},
            ),
        )
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), \
             patch(f"{CMD_MODULE}.resolve_project", return_value="my-project"):
            runner.invoke(
                cli,
                [
                    "templates", "fork", "test-template",
                    "--project", "my-project", "--name", "Bad Fork",
                ],
            )
        mc.post.assert_called_once()
        mc.close.assert_called_once()

    def test_fork_client_close_on_success(self, runner) -> None:
        body = {"id": "boundary-new"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc), \
             patch(f"{CMD_MODULE}.resolve_project", return_value="proj"):
            runner.invoke(
                cli,
                ["templates", "fork", "tpl-1", "--project", "proj", "--name", "Forked"],
            )
        mc.close.assert_called_once()
