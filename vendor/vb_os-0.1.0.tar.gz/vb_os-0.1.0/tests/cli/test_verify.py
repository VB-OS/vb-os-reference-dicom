"""Tests for the verify CLI command."""

from __future__ import annotations

import json
from contextlib import ExitStack
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def workload_file(tmp_path):
    """Create a temporary workload JSON file."""
    path = tmp_path / "workload.json"
    path.write_text(json.dumps({"field_a": 100, "field_b": 200}))
    return str(path)


@pytest.fixture
def batch_workload_file(tmp_path):
    """Create a temporary batch workload JSON file."""
    path = tmp_path / "batch_workload.json"
    path.write_text(json.dumps([{"field_a": 1}, {"field_a": 2}]))
    return str(path)


CMD_MODULE = "vbos_cli.commands.verify"


def _invoke_verify(runner, args, mc):
    """Invoke verify with make_client, resolve_project, and resolve_environment all patched."""
    with ExitStack() as stack:
        stack.enter_context(patch(f"{CMD_MODULE}.make_client", return_value=mc))
        stack.enter_context(patch(f"{CMD_MODULE}.resolve_project", return_value="proj-1"))
        stack.enter_context(patch(f"{CMD_MODULE}.resolve_environment", return_value="env-1"))
        result = runner.invoke(cli, args)
    return result


class TestVerifyAssert:
    def test_assert_exits_0(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                    "evaluation_id": "eval-001",
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                workload_file,
            ],
            mc,
        )
        assert result.exit_code == 0
        assert "ASSERT" in result.output

    def test_assert_sends_boundary_ref(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--boundary",
                "my-boundary",
                "--workload",
                workload_file,
            ],
            mc,
        )
        assert result.exit_code == 0
        call_kwargs = mc.post.call_args[1]
        body = call_kwargs.get("json_body", {})
        assert body["boundary_ref"] == "my-boundary"


class TestVerifyDefer:
    def test_defer_exits_1(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "DEFER",
                    "evaluation_id": "eval-002",
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                workload_file,
            ],
            mc,
        )
        assert result.exit_code == 1


class TestVerifyBatch:
    def test_batch_mode_posts_to_batch_endpoint(self, runner, batch_workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "results": [{"decision": "ASSERT"}, {"decision": "ASSERT"}],
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--batch",
                "--workload",
                batch_workload_file,
            ],
            mc,
        )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/verify/batch" in call_args[0][0]

    def test_batch_defer_exits_1(self, runner, batch_workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "results": [{"decision": "ASSERT"}, {"decision": "DEFER"}],
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--batch",
                "--workload",
                batch_workload_file,
            ],
            mc,
        )
        assert result.exit_code == 1

    def test_batch_local_mutually_exclusive(self, runner, batch_workload_file) -> None:
        result = runner.invoke(
            cli,
            [
                "--local",
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--batch",
                "--workload",
                batch_workload_file,
            ],
        )
        assert result.exit_code == 2
        stderr = result.stderr if result.stderr else ""
        assert "mutually exclusive" in stderr.lower() or result.exit_code == 2


class TestVerifyIdempotencyKey:
    def test_idempotency_key_header_sent(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--idempotency-key",
                "idem-abc-123",
                "--workload",
                workload_file,
            ],
            mc,
        )
        assert result.exit_code == 0
        call_kwargs = mc.post.call_args[1]
        headers = call_kwargs.get("headers", {})
        assert headers is not None
        assert headers.get("X-Idempotency-Key") == "idem-abc-123"


class TestVerifyWorkloadFile:
    def test_reads_workload_from_file(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                workload_file,
            ],
            mc,
        )
        assert result.exit_code == 0
        call_kwargs = mc.post.call_args[1]
        body = call_kwargs.get("json_body", {})
        assert body["workload"]["field_a"] == 100
        assert body["workload"]["field_b"] == 200

    def test_missing_workload_file_errors(self, runner) -> None:
        result = runner.invoke(
            cli,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                "/nonexistent/path/workload.json",
            ],
        )
        assert result.exit_code != 0


class TestVerifyAPIError:
    def test_api_error_exits_2(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                422,
                {
                    "error": "validation_error",
                    "message": "Invalid workload",
                },
            )
        )
        result = _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                workload_file,
            ],
            mc,
        )
        assert result.exit_code == 2

    def test_client_closed_after_call(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                200,
                {
                    "decision": "ASSERT",
                },
            )
        )
        _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                workload_file,
            ],
            mc,
        )
        mc.close.assert_called_once()

    def test_client_closed_on_api_error(self, runner, workload_file) -> None:
        mc = make_mock_client(
            post_resp=make_response(
                500,
                {
                    "error": "internal_error",
                    "message": "Server error",
                },
            )
        )
        _invoke_verify(
            runner,
            [
                "verify",
                "--project",
                "proj-1",
                "--environment",
                "env-1",
                "--workload",
                workload_file,
            ],
            mc,
        )
        mc.close.assert_called_once()
