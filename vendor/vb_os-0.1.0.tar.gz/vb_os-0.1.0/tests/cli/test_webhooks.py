"""Tests for webhooks CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.webhooks"


@pytest.fixture
def runner():
    return CliRunner()


class TestWebhooksCreate:
    def test_create_project_scoped(self, runner) -> None:
        resp = make_response(201, {"id": "wh-1", "url": "https://example.com/hook"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "create",
                    "--project",
                    "proj-1",
                    "--url",
                    "https://example.com/hook",
                    "--events",
                    "evaluation.completed,boundary.deployed",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/projects/proj-1/webhooks" in call_args[0][0]
        payload = call_args[1]["json"]
        assert payload["url"] == "https://example.com/hook"
        assert payload["events"] == ["evaluation.completed", "boundary.deployed"]

    def test_create_org_scoped(self, runner) -> None:
        resp = make_response(201, {"id": "wh-org-1"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "create",
                    "--org",
                    "--url",
                    "https://example.com/org-hook",
                    "--events",
                    "project.created",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert "/v1/org/webhooks" in call_args[0][0]

    def test_create_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(422, {"error": "validation_error"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "create",
                    "--project",
                    "proj-1",
                    "--url",
                    "bad",
                    "--events",
                    "x",
                ],
            )
        assert result.exit_code == 2

    def test_create_closes_client(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(201, {"id": "wh-1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(
                cli,
                [
                    "webhooks",
                    "create",
                    "--project",
                    "p",
                    "--url",
                    "https://x.com",
                    "--events",
                    "e",
                ],
            )
        mc.close.assert_called_once()


class TestWebhooksList:
    def test_list_project_scoped(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "wh-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "list",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/webhooks" in mc.get.call_args[0][0]

    def test_list_org_scoped(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "wh-org-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "list",
                    "--org",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/org/webhooks" in mc.get.call_args[0][0]

    def test_list_with_pagination(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "wh-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "list",
                    "--project",
                    "p",
                    "--limit",
                    "10",
                    "--cursor",
                    "abc",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("limit") == 10
        assert params.get("cursor") == "abc"


class TestWebhooksGet:
    def test_get_success(self, runner) -> None:
        resp = make_response(200, {"id": "wh-1", "url": "https://x.com"})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "get",
                    "wh-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/webhooks/wh-1" in mc.get.call_args[0][0]

    def test_get_not_found(self, runner) -> None:
        mc = make_mock_client(get_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "get",
                    "bad",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestWebhooksUpdate:
    def test_update_url(self, runner) -> None:
        resp = make_response(200, {"id": "wh-1", "url": "https://new.com"})
        mc = make_mock_client(patch_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "update",
                    "wh-1",
                    "--project",
                    "proj-1",
                    "--url",
                    "https://new.com",
                ],
            )
        assert result.exit_code == 0
        payload = mc.patch.call_args[1]["json"]
        assert payload["url"] == "https://new.com"

    def test_update_events(self, runner) -> None:
        resp = make_response(200, {"id": "wh-1"})
        mc = make_mock_client(patch_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "update",
                    "wh-1",
                    "--project",
                    "proj-1",
                    "--events",
                    "a.b, c.d",
                ],
            )
        assert result.exit_code == 0
        payload = mc.patch.call_args[1]["json"]
        assert payload["events"] == ["a.b", "c.d"]

    def test_update_api_error(self, runner) -> None:
        mc = make_mock_client(patch_resp=make_response(400, {"error": "bad"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "update",
                    "wh-1",
                    "--project",
                    "p",
                    "--url",
                    "x",
                ],
            )
        assert result.exit_code == 2


class TestWebhooksDelete:
    def test_delete_with_confirm(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "delete",
                    "wh-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.delete.assert_called_once()

    def test_delete_requires_confirm_in_non_interactive(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(204, None))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "delete",
                    "wh-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2
        assert "confirmation_required" in result.output or "--confirm" in result.output

    def test_delete_200_response(self, runner) -> None:
        mc = make_mock_client(delete_resp=make_response(200, {"id": "wh-1"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "delete",
                    "wh-1",
                    "--project",
                    "proj-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0


class TestWebhooksTestCmd:
    def test_send_test_event(self, runner) -> None:
        resp = make_response(200, {"id": "wh-1", "status": "delivered"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "test",
                    "wh-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/webhooks/wh-1/test" in mc.post.call_args[0][0]


class TestWebhooksRotateSecret:
    def test_rotate_secret_success(self, runner) -> None:
        resp = make_response(200, {"id": "wh-1", "signing_secret": "whsec_newkey123"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "rotate-secret",
                    "wh-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/webhooks/wh-1/rotate-secret" in mc.post.call_args[0][0]

    def test_rotate_secret_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(403, {"error": "forbidden"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "rotate-secret",
                    "wh-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2


class TestWebhooksDeliveries:
    def test_list_deliveries(self, runner) -> None:
        resp = make_response(200, {"items": [{"id": "del-1"}]})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "deliveries",
                    "wh-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/webhooks/wh-1/deliveries" in mc.get.call_args[0][0]

    def test_list_deliveries_with_limit(self, runner) -> None:
        resp = make_response(200, {"items": []})
        mc = make_mock_client(get_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "deliveries",
                    "wh-1",
                    "--project",
                    "proj-1",
                    "--limit",
                    "5",
                ],
            )
        assert result.exit_code == 0
        params = mc.get.call_args[1].get("params", {})
        assert params.get("limit") == 5


class TestWebhooksRetry:
    def test_retry_delivery(self, runner) -> None:
        resp = make_response(202, {"id": "del-1", "status": "retrying"})
        mc = make_mock_client(post_resp=resp)
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "retry",
                    "wh-1",
                    "del-1",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 0
        assert "/v1/projects/proj-1/webhooks/wh-1/deliveries/del-1/retry" in mc.post.call_args[0][0]

    def test_retry_api_error(self, runner) -> None:
        mc = make_mock_client(post_resp=make_response(404, {"error": "not_found"}))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "webhooks",
                    "retry",
                    "wh-1",
                    "del-bad",
                    "--project",
                    "proj-1",
                ],
            )
        assert result.exit_code == 2
