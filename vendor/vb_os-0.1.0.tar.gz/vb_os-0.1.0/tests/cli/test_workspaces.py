"""Tests for workspaces CLI commands."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.cli.conftest import make_mock_client, make_response
from vbos_cli.cli import cli

CMD_MODULE = "vbos_cli.commands.workspaces"


@pytest.fixture
def runner():
    return CliRunner()


class TestWorkspacesList:
    def test_list_success(self, runner) -> None:
        body = {"items": [{"id": "ws-1"}], "cursor": None, "has_more": False}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["workspaces", "list"])
        assert result.exit_code == 0
        mc.get.assert_called_once()
        mc.close.assert_called_once()


class TestWorkspacesGet:
    def test_get_success(self, runner) -> None:
        body = {"id": "ws-1", "name": "Dev Workspace"}
        mc = make_mock_client(get_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(cli, ["workspaces", "get", "ws-1"])
        assert result.exit_code == 0
        assert "ws-1" in result.output


class TestWorkspacesCreate:
    def test_create_success(self, runner) -> None:
        body = {"id": "ws-new", "name": "New Workspace"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "workspaces",
                    "create",
                    "--name",
                    "New Workspace",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["name"] == "New Workspace"

    def test_create_with_description(self, runner) -> None:
        body = {"id": "ws-new", "name": "WS", "description": "A workspace"}
        mc = make_mock_client(post_resp=make_response(201, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "workspaces",
                    "create",
                    "--name",
                    "WS",
                    "--description",
                    "A workspace",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.post.call_args
        assert call_args[1]["json_body"]["description"] == "A workspace"


class TestWorkspacesUpdate:
    def test_update_name(self, runner) -> None:
        body = {"id": "ws-1", "name": "Renamed"}
        mc = make_mock_client(patch_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "workspaces",
                    "update",
                    "ws-1",
                    "--name",
                    "Renamed",
                ],
            )
        assert result.exit_code == 0
        call_args = mc.patch.call_args
        assert call_args[1]["json_body"]["name"] == "Renamed"


class TestWorkspacesArchive:
    def test_archive_with_confirm(self, runner) -> None:
        body = {"id": "ws-1", "status": "archived"}
        mc = make_mock_client(post_resp=make_response(200, body))
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            result = runner.invoke(
                cli,
                [
                    "workspaces",
                    "archive",
                    "ws-1",
                    "--confirm",
                ],
            )
        assert result.exit_code == 0
        mc.post.assert_called_once()

    def test_archive_aborted(self, runner) -> None:
        mc = make_mock_client()
        with patch(f"{CMD_MODULE}.make_client", return_value=mc):
            runner.invoke(cli, ["workspaces", "archive", "ws-1"], input="n\n")
        mc.post.assert_not_called()
