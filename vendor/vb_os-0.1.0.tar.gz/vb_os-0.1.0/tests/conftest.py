"""Shared test fixtures for VB-OS SDK tests."""


MOCK_VERIFY_RESPONSE = {
    "decision": "ASSERT",
    "replay_id": "abc123def456",
    "evaluation_id": "019062a1-4c7e-7f3a-8b2c-1a2b3c4d5e6f",
    "timestamp": "2026-06-20T12:00:00Z",
    "latency_ms": 42,
    "project": "payment-auth",
    "environment": "production",
    "boundary_ref": "B_FIN_PAYMENT",
    "boundary_version": 3,
    "deployment_id": "019062a1-0000-7000-8000-000000000001",
    "boundary_version_id": "019062a1-0000-7000-8000-000000000002",
    "binary_version": "1.0.0",
    "binary_sha256": "d" * 64,
    "admissibility": {
        "status": "PASS",
        "required": ["amount", "currency"],
        "present": ["amount", "currency"],
        "missing": [],
    },
    "prohibitions": {
        "status": "PASS",
        "prohibited": ["internal_score"],
        "detected": [],
    },
    "predicate_results": {
        "amount_under_limit": {
            "passed": True,
            "expression": "amount <= 10000",
            "actual": 5000,
        },
    },
    "failure_reasons": [],
    "audit_artifact": {
        "sealed": True,
        "artifact_hash": "a" * 64,
        "boundary_snapshot_hash": "b" * 64,
        "workload_hash": "c" * 64,
    },
    "metadata": {},
}

MOCK_DEFER_RESPONSE = {
    **MOCK_VERIFY_RESPONSE,
    "decision": "DEFER",
    "admissibility": {
        "status": "FAIL",
        "required": ["amount", "currency"],
        "present": ["amount"],
        "missing": ["currency"],
    },
    "failure_reasons": [
        {
            "type": "ADMISSIBILITY",
            "field": "currency",
            "reason": "Required evidence missing",
        },
    ],
}

MOCK_ERROR_RESPONSE = {
    "error": "validation_error",
    "message": "Workload is empty",
    "details": {"field": "workload", "constraint": "non_empty"},
}

MOCK_API_KEY = "vbos_test_key_abc123"
MOCK_BASE_URL = "https://api.vb-os.org"
