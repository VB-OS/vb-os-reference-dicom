"""Contract tests — verify SDK methods send correct HTTP method/path
and parse responses (CC-01 through CC-23)."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL, MOCK_VERIFY_RESPONSE
from vbos.client import VBOSClient


@pytest.fixture
def client() -> VBOSClient:
    c = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
    yield c
    c.close()


class TestVerificationContract:
    """CC-01: verify, verify_batch, validate."""

    @respx.mock
    def test_verify_sends_post(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/verify").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE),
        )
        client.verify({"amount": 5000})
        assert route.called

    @respx.mock
    def test_verify_batch_sends_post(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/verify/batch").mock(
            return_value=httpx.Response(200, json={"results": []}),
        )
        client.verify_batch([{"amount": 5000}])
        assert route.called

    @respx.mock
    def test_validate_sends_post(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json={"valid": True}),
        )
        client.validate({"amount": 5000})
        assert route.called


class TestBoundaryContract:
    """CC-02: Boundary operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/boundaries").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.boundaries.list("p1")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/boundaries").mock(
            return_value=httpx.Response(
                201,
                json={"id": "b-1", "project_id": "p1", "boundary_ref": "B_TEST"},
            ),
        )
        client.boundaries.create("p1", boundary_ref="B_TEST", display_name="Test")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/boundaries/B_TEST").mock(
            return_value=httpx.Response(
                200,
                json={"id": "b-1", "project_id": "p1", "boundary_ref": "B_TEST"},
            ),
        )
        client.boundaries.get("p1", "B_TEST")
        assert route.called

    @respx.mock
    def test_update_draft(self, client: VBOSClient) -> None:
        route = respx.patch(f"{MOCK_BASE_URL}/v1/projects/p1/boundaries/B_TEST/draft").mock(
            return_value=httpx.Response(
                200,
                json={"id": "b-1", "project_id": "p1", "boundary_ref": "B_TEST"},
            ),
        )
        client.boundaries.update_draft("p1", "B_TEST", dsl_source="require_evidence: amount")
        assert route.called

    @respx.mock
    def test_approve(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/boundaries/B_TEST/versions/v1/approve",
        ).mock(
            return_value=httpx.Response(200, json={"status": "APPROVED"}),
        )
        client.boundaries.approve("p1", "B_TEST", "v1")
        assert route.called

    @respx.mock
    def test_reject(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/boundaries/B_TEST/versions/v1/reject",
        ).mock(
            return_value=httpx.Response(200, json={"status": "REJECTED"}),
        )
        client.boundaries.reject("p1", "B_TEST", "v1")
        assert route.called

    @respx.mock
    def test_diff(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/boundaries/B_TEST/diff").mock(
            return_value=httpx.Response(
                200, json={"boundary_ref": "B_TEST", "diff": "..."},
            ),
        )
        client.boundaries.diff("p1", "B_TEST")
        assert route.called

    @respx.mock
    def test_submit(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/boundaries/B_TEST/submit"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "SUBMITTED"},
            ),
        )
        client.boundaries.submit("p1", "B_TEST")
        assert route.called

    @respx.mock
    def test_versions(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/boundaries/B_TEST/versions"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.boundaries.versions("p1", "B_TEST")
        assert route.called

    @respx.mock
    def test_get_version(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/boundaries/B_TEST/versions/v1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "bv-1"},
            ),
        )
        client.boundaries.get_version("p1", "B_TEST", "v1")
        assert route.called


class TestDeploymentContract:
    """CC-03: Deployment operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/staging/deployments",
        ).mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.deployments.list("p1", "staging")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/staging/deployments",
        ).mock(
            return_value=httpx.Response(201, json={"id": "dep-1", "status": "PENDING"}),
        )
        client.deployments.create("p1", "staging", boundary_version_id="bv-1")
        assert route.called

    @respx.mock
    def test_active(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/staging/deployments/active",
        ).mock(
            return_value=httpx.Response(200, json={"id": "dep-1", "status": "ACTIVE"}),
        )
        client.deployments.active("p1", "staging")
        assert route.called

    @respx.mock
    def test_approve(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments"
            "/staging/deployments/dep-1/approve"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "APPROVED"},
            ),
        )
        client.deployments.approve(
            "p1", "staging", "dep-1",
        )
        assert route.called

    @respx.mock
    def test_reject(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments"
            "/staging/deployments/dep-1/reject"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "REJECTED"},
            ),
        )
        client.deployments.reject(
            "p1", "staging", "dep-1",
        )
        assert route.called

    @respx.mock
    def test_promote(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments"
            "/staging/promote"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "PROMOTED"},
            ),
        )
        client.deployments.promote(
            "p1",
            "staging",
            source_environment="dev",
            boundary_version_id="bv-1",
        )
        assert route.called

    @respx.mock
    def test_rollback(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments"
            "/staging/rollback"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "ROLLED_BACK"},
            ),
        )
        client.deployments.rollback("p1", "staging")
        assert route.called


class TestEvaluationContract:
    """CC-04: Evaluation operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/evaluations").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.evaluations.list("p1")
        assert route.called

    @respx.mock
    def test_export(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/evaluations/export").mock(
            return_value=httpx.Response(202, json={"export_id": "exp-1"}),
        )
        client.evaluations.export("p1")
        assert route.called

    @respx.mock
    def test_share(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/evaluations/eval-1/share",
        ).mock(
            return_value=httpx.Response(200, json={"token": "abc123"}),
        )
        client.evaluations.share("p1", "eval-1")
        assert route.called

    @respx.mock
    def test_get_shared(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/shared/evaluations/abc123").mock(
            return_value=httpx.Response(200, json={"decision": "ASSERT"}),
        )
        client.evaluations.get_shared("abc123")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/evaluations/eval-1"
        )
        record = {
            "id": "eval-1",
            "environment_id": "env-1",
            "org_id": "o-1",
            "boundary_version_id": "bv-1",
            "boundary_ref": "B_TEST",
            "boundary_version_number": 1,
            "boundary_snapshot_hash": "abc",
            "decision": "ASSERT",
            "replay_id": "r-1",
            "latency_ms": 10,
            "binary_version": "1.0.0",
            "binary_sha256": "deadbeef",
            "deployment_id": "dep-1",
            "api_key_id": "k-1",
            "created_at": "2025-01-01T00:00:00Z",
            "predicate_summary": [],
            "admissibility_satisfied": True,
            "admissibility_summary": {},
        }
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200,
                json={
                    "record": record,
                    "artifact_available": True,
                },
            ),
        )
        client.evaluations.get("p1", "eval-1")
        assert route.called

    @respx.mock
    def test_replay(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/evaluations/eval-1/replay"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200,
                json={
                    "replay_execution_id": "re-1",
                    "evaluation_id": "eval-1",
                    "initiated_by": "u-1",
                    "replay_type": "STANDARD",
                    "decision": "ASSERT",
                    "result_match": True,
                    "replay_id_match": True,
                    "binary_version": "1.0.0",
                    "binary_sha256": "deadbeef",
                    "binary_version_match": True,
                    "latency_ms": 10,
                    "created_at": "2025-01-01T00:00:00Z",
                },
            ),
        )
        client.evaluations.replay("p1", "eval-1")
        assert route.called


class TestCertificationContract:
    """CC-05: Certification operations."""

    @respx.mock
    def test_certify(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/certify").mock(
            return_value=httpx.Response(201, json={"id": "run-1", "status": "RUNNING"}),
        )
        client.certify("p1")
        assert route.called

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.certifications.list("p1")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run-1").mock(
            return_value=httpx.Response(
                200, json={"id": "run-1", "project_id": "p1", "status": "COMPLETED"},
            ),
        )
        client.certifications.get("p1", "run-1")
        assert route.called

    @respx.mock
    def test_get_report(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run-1/report",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "rpt-1", "certification_run_id": "run-1"},
            ),
        )
        client.certifications.get_report("p1", "run-1")
        assert route.called


class TestCertificationModelContract:
    """CC-05b: Certification Model operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/certification-models"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200,
                json={"items": [], "cursor": None},
            ),
        )
        client.certification_models.list("p1")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/certification-models"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "cm-1"},
            ),
        )
        client.certification_models.create(
            "p1", name="Model A",
        )
        assert route.called

    @respx.mock
    def test_create_version(
        self, client: VBOSClient,
    ) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1"
            "/certification-models/cm-1/versions"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "cmv-1"},
            ),
        )
        client.certification_models.create_version(
            "p1", "cm-1",
        )
        assert route.called


class TestProjectContract:
    """CC-06: Project operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.projects.list()
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects").mock(
            return_value=httpx.Response(
                201, json={"id": "p-1", "org_id": "o-1", "name": "Test"},
            ),
        )
        client.projects.create(name="Test")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1").mock(
            return_value=httpx.Response(
                200, json={"id": "p1", "org_id": "o-1", "name": "Test"},
            ),
        )
        client.projects.get("p1")
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        route = respx.patch(f"{MOCK_BASE_URL}/v1/projects/p1").mock(
            return_value=httpx.Response(
                200, json={"id": "p1", "org_id": "o-1", "name": "Updated"},
            ),
        )
        client.projects.update("p1", name="Updated")
        assert route.called

    @respx.mock
    def test_archive(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/archive").mock(
            return_value=httpx.Response(200, json={"status": "archived"}),
        )
        client.projects.archive("p1")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        route = respx.delete(f"{MOCK_BASE_URL}/v1/projects/p1").mock(
            return_value=httpx.Response(204, json={}),
        )
        client.projects.delete("p1")
        assert route.called


class TestTemplateContract:
    """CC-07: Template operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/templates").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.templates.list()
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/templates/healthcare").mock(
            return_value=httpx.Response(
                200, json={"slug": "healthcare", "name": "Healthcare"},
            ),
        )
        client.templates.get("healthcare")
        assert route.called

    @respx.mock
    def test_fork(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/templates/healthcare/fork").mock(
            return_value=httpx.Response(
                201, json={"project_id": "p-new", "boundary_ref": "B_HC"},
            ),
        )
        client.templates.fork("healthcare")
        assert route.called


class TestOrgMemberContract:
    """CC-08: Org & Member operations."""

    @respx.mock
    def test_org_get(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org").mock(
            return_value=httpx.Response(200, json={"id": "o-1", "name": "TestOrg"}),
        )
        client.org.get()
        assert route.called

    @respx.mock
    def test_members_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/members").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.members.list()
        assert route.called

    @respx.mock
    def test_members_invite(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/org/members").mock(
            return_value=httpx.Response(
                201,
                json={"id": "m-1", "user_id": "u-1", "org_id": "o-1", "role": "member"},
            ),
        )
        client.members.invite(email="test@example.com", role="member")
        assert route.called

    @respx.mock
    def test_set_role(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/members/m1/role",
        ).mock(
            return_value=httpx.Response(200, json={"ok": True}),
        )
        client.members.set_role("m1", role="admin")
        assert route.called

    @respx.mock
    def test_remove(self, client: VBOSClient) -> None:
        route = respx.delete(
            f"{MOCK_BASE_URL}/v1/org/members/m1",
        ).mock(
            return_value=httpx.Response(200, json={"ok": True}),
        )
        client.members.remove("m1")
        assert route.called

    @respx.mock
    def test_suspend(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/members/m1/suspend",
        ).mock(
            return_value=httpx.Response(200, json={"ok": True}),
        )
        client.members.suspend("m1")
        assert route.called

    @respx.mock
    def test_reactivate(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/members/m1/reactivate",
        ).mock(
            return_value=httpx.Response(200, json={"ok": True}),
        )
        client.members.reactivate("m1")
        assert route.called

    @respx.mock
    def test_revoke_invitation(self, client: VBOSClient) -> None:
        route = respx.delete(
            f"{MOCK_BASE_URL}/v1/org/members/invitations/inv-1",
        ).mock(
            return_value=httpx.Response(200, json={"ok": True}),
        )
        client.members.revoke_invitation("inv-1")
        assert route.called

    @respx.mock
    def test_org_update(self, client: VBOSClient) -> None:
        route = respx.patch(f"{MOCK_BASE_URL}/v1/org").mock(
            return_value=httpx.Response(
                200, json={"id": "org-1"},
            ),
        )
        client.org.update(display_name="X")
        assert route.called

    @respx.mock
    def test_org_get_settings(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/org/settings",
        ).mock(
            return_value=httpx.Response(
                200, json={"settings": {}},
            ),
        )
        client.org.get_settings()
        assert route.called

    @respx.mock
    def test_org_update_settings(self, client: VBOSClient) -> None:
        route = respx.put(
            f"{MOCK_BASE_URL}/v1/org/settings",
        ).mock(
            return_value=httpx.Response(
                200, json={"settings": {}},
            ),
        )
        client.org.update_settings(default_project="p1")
        assert route.called

    @respx.mock
    def test_org_get_ai_policy(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/org/ai-policy",
        ).mock(
            return_value=httpx.Response(
                200, json={"policy": {}},
            ),
        )
        client.org.get_ai_policy()
        assert route.called

    @respx.mock
    def test_org_update_ai_policy(self, client: VBOSClient) -> None:
        route = respx.patch(
            f"{MOCK_BASE_URL}/v1/org/ai-policy",
        ).mock(
            return_value=httpx.Response(
                200, json={"policy": {}},
            ),
        )
        client.org.update_ai_policy(allowed_models=["gpt-4"])
        assert route.called

    @respx.mock
    def test_org_transfer_ownership(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/ownership-transfer",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "t-1"},
            ),
        )
        client.org.transfer_ownership(new_owner_id="u1")
        assert route.called

    @respx.mock
    def test_org_accept_transfer(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/org/ownership-transfer/t-1/accept"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.org.accept_transfer("t-1")
        assert route.called

    @respx.mock
    def test_org_cancel_transfer(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/org/ownership-transfer/t-1/cancel"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.org.cancel_transfer("t-1")
        assert route.called

    @respx.mock
    def test_org_get_transfer(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/org/ownership-transfer",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "t-1"},
            ),
        )
        client.org.get_transfer()
        assert route.called


class TestKeyContract:
    """CC-09: API Key operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/staging/keys",
        ).mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.keys.list("p1", "staging")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/staging/keys",
        ).mock(
            return_value=httpx.Response(
                201,
                json={"id": "k-1", "key": "vbos_live_abc", "name": "Test Key"},
            ),
        )
        result = client.keys.create("p1", "staging", name="Test Key")
        assert route.called
        assert "key" in result

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments/e1/keys/k1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "k1", "name": "Key"},
            ),
        )
        client.keys.get("p1", "e1", "k1")
        assert route.called

    @respx.mock
    def test_rotate(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments/e1/keys/k1/rotate"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"id": "k1", "key": "new_key"},
            ),
        )
        client.keys.rotate("p1", "e1", "k1")
        assert route.called

    @respx.mock
    def test_revoke(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments/e1/keys/k1/revoke"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.keys.revoke("p1", "e1", "k1")
        assert route.called

    @respx.mock
    def test_disable(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments/e1/keys/k1/disable"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.keys.disable("p1", "e1", "k1")
        assert route.called

    @respx.mock
    def test_enable(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/environments/e1/keys/k1/enable"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.keys.enable("p1", "e1", "k1")
        assert route.called


class TestServiceAccountContract:
    """CC-10: Service Account operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/service-accounts").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.service_accounts.list()
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/service-accounts",
        ).mock(
            return_value=httpx.Response(
                201, json={"id": "sa-1"},
            ),
        )
        client.service_accounts.create(name="bot")
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        route = respx.patch(
            f"{MOCK_BASE_URL}/v1/org/service-accounts/sa-1",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "sa-1"},
            ),
        )
        client.service_accounts.update("sa-1", name="v2")
        assert route.called

    @respx.mock
    def test_disable(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/service-accounts/sa-1/disable",
        ).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.service_accounts.disable("sa-1")
        assert route.called

    @respx.mock
    def test_enable(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/service-accounts/sa-1/enable",
        ).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.service_accounts.enable("sa-1")
        assert route.called


class TestWebhookContract:
    """CC-11: Webhook operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/webhooks").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.webhooks.list("p1")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/webhooks").mock(
            return_value=httpx.Response(
                201,
                json={"id": "wh-1", "url": "https://example.com", "secret": "sec_abc"},
            ),
        )
        result = client.webhooks.create("p1", url="https://example.com")
        assert route.called
        assert "secret" in result

    @respx.mock
    def test_rotate_secret(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/webhooks/wh-1/rotate-secret",
        ).mock(
            return_value=httpx.Response(200, json={"secret": "sec_new"}),
        )
        client.webhooks.rotate_secret("p1", "wh-1")
        assert route.called

    @respx.mock
    def test_list_org(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/webhooks").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.webhooks.list_org()
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        route = respx.patch(
            f"{MOCK_BASE_URL}/v1/projects/p1/webhooks/wh-1",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "wh-1"},
            ),
        )
        client.webhooks.update("p1", "wh-1", url="https://new")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        route = respx.delete(
            f"{MOCK_BASE_URL}/v1/projects/p1/webhooks/wh-1",
        ).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.webhooks.delete("p1", "wh-1")
        assert route.called

    @respx.mock
    def test_deliveries(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/webhooks/wh-1/deliveries"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": []},
            ),
        )
        client.webhooks.deliveries("p1", "wh-1")
        assert route.called

    @respx.mock
    def test_create_org(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/org/webhooks",
        ).mock(
            return_value=httpx.Response(
                201, json={"id": "wh-2", "secret": "sec"},
            ),
        )
        client.webhooks.create_org(url="https://org")
        assert route.called


class TestAnalyticsContract:
    """CC-12: Analytics operations."""

    @respx.mock
    def test_assertion_rate(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/analytics/assertion-rate",
        ).mock(
            return_value=httpx.Response(200, json={"rate": 0.95, "total": 100}),
        )
        client.analytics.assertion_rate("p1")
        assert route.called

    @respx.mock
    def test_latency(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/analytics/latency",
        ).mock(
            return_value=httpx.Response(200, json={"p50": 12.5, "p99": 45.0}),
        )
        client.analytics.latency("p1")
        assert route.called


class TestAuditContract:
    """CC-13: Audit Trail operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/audit-log").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.audit_log.list()
        assert route.called

    @respx.mock
    def test_export(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/org/audit-log/export").mock(
            return_value=httpx.Response(202, json={"id": "exp-1", "status": "pending"}),
        )
        client.audit_log.export()
        assert route.called

    @respx.mock
    def test_export_status(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/audit-log/export/exp-1").mock(
            return_value=httpx.Response(
                200, json={"id": "exp-1", "org_id": "o-1", "status": "completed"},
            ),
        )
        client.audit_log.export_status("exp-1")
        assert route.called


class TestBillingContract:
    """CC-14: Billing operations."""

    @respx.mock
    def test_usage(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/usage").mock(
            return_value=httpx.Response(200, json={"total_evaluations": 1000}),
        )
        client.billing.usage()
        assert route.called

    @respx.mock
    def test_subscription(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/subscription").mock(
            return_value=httpx.Response(200, json={"plan": "enterprise"}),
        )
        client.billing.subscription()
        assert route.called

    @respx.mock
    def test_invoices(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/invoices").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.billing.invoices()
        assert route.called


class TestEnvironmentContract:
    """CC-15: Environment operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/environments").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.environments.list("p1")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/environments").mock(
            return_value=httpx.Response(
                201, json={"id": "env-1", "project_id": "p1", "name": "staging"},
            ),
        )
        client.environments.create("p1", name="staging")
        assert route.called


class TestFlowContract:
    """CC-16: Flow operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/flows").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.flows.list("p1")
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/flows").mock(
            return_value=httpx.Response(
                201, json={"id": "f-1", "project_id": "p1", "name": "TestFlow"},
            ),
        )
        client.flows.create("p1", name="TestFlow")
        assert route.called

    @respx.mock
    def test_import_flow(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/projects/p1/flows/import").mock(
            return_value=httpx.Response(
                201, json={"id": "f-2", "project_id": "p1", "name": "Imported"},
            ),
        )
        client.flows.import_flow("p1", definition={"steps": []})
        assert route.called


class TestAlertRuleContract:
    """CC-17: Alert Rule operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/alert-rules").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.alert_rules.list("p1")
        assert route.called

    @respx.mock
    def test_update_uses_put(self, client: VBOSClient) -> None:
        route = respx.put(f"{MOCK_BASE_URL}/v1/projects/p1/alert-rules/r1").mock(
            return_value=httpx.Response(
                200,
                json={"id": "r1", "project_id": "p1", "name": "Updated"},
            ),
        )
        client.alert_rules.update("p1", "r1", name="Updated")
        assert route.called


class TestConnectorContract:
    """CC-18: Connector operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/connectors").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.connectors.list("p1")
        assert route.called

    @respx.mock
    def test_test_connection(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/connectors/c1/test",
        ).mock(
            return_value=httpx.Response(200, json={"success": True}),
        )
        client.connectors.test("p1", "c1")
        assert route.called


class TestNamedSetContract:
    """CC-19: Named Set operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/named-sets").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.named_sets.list("p1")
        assert route.called

    @respx.mock
    def test_usage(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/named-sets/ns1/usage").mock(
            return_value=httpx.Response(
                200, json={"named_set_id": "ns1", "usage_count": 3},
            ),
        )
        client.named_sets.usage("p1", "ns1")
        assert route.called


class TestGovernedWorkspaceContract:
    """CC-20: Governed Workspace operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/governed-workspaces",
        ).mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.governed_workspaces.list("p1")
        assert route.called


class TestNotificationContract:
    """CC-21: Notification operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/notifications").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.notifications.list()
        assert route.called

    @respx.mock
    def test_read(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/notifications/n1/read").mock(
            return_value=httpx.Response(200, json={"id": "n1", "read": True}),
        )
        client.notifications.read("n1")
        assert route.called

    @respx.mock
    def test_unread(self, client: VBOSClient) -> None:
        route = respx.delete(f"{MOCK_BASE_URL}/v1/notifications/n1/read").mock(
            return_value=httpx.Response(200, json={"id": "n1", "read": False}),
        )
        client.notifications.unread("n1")
        assert route.called


class TestAccountContract:
    """CC-22: Account operations."""

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/auth/account/delete").mock(
            return_value=httpx.Response(200, json={"status": "scheduled"}),
        )
        client.account.delete()
        assert route.called

    @respx.mock
    def test_deletion_status(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/auth/account/deletion-status").mock(
            return_value=httpx.Response(200, json={"status": "none"}),
        )
        client.account.deletion_status()
        assert route.called

    @respx.mock
    def test_export(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/auth/account/export").mock(
            return_value=httpx.Response(202, json={"id": "exp-1", "status": "pending"}),
        )
        client.account.export()
        assert route.called


class TestOrgWorkspaceContract:
    """CC-23: Org Workspace operations."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/workspaces").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.workspaces.list()
        assert route.called

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(f"{MOCK_BASE_URL}/v1/org/workspaces").mock(
            return_value=httpx.Response(
                201, json={"id": "ws-1", "org_id": "o-1", "name": "Dev"},
            ),
        )
        client.workspaces.create(name="Dev")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/workspaces/ws-1").mock(
            return_value=httpx.Response(
                200, json={"id": "ws-1", "org_id": "o-1", "name": "Dev"},
            ),
        )
        client.workspaces.get("ws-1")
        assert route.called

    @respx.mock
    def test_list_members(self, client: VBOSClient) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/org/workspaces/ws-1/members").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client.workspaces.list_members("ws-1")
        assert route.called


class TestGovernedWorkspaceContractExtended:
    """Governed Workspace extended operations."""

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/projects/p1/governed-workspaces"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "gw-1"},
            ),
        )
        client.governed_workspaces.create(
            "p1", name="GW",
        )
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces/gw-1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "gw-1"},
            ),
        )
        client.governed_workspaces.get("p1", "gw-1")
        assert route.called

    @respx.mock
    def test_create_version(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/versions"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "v1"},
            ),
        )
        client.governed_workspaces.create_version(
            "p1", "gw-1",
        )
        assert route.called

    @respx.mock
    def test_get_version(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/versions/v1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "v1"},
            ),
        )
        client.governed_workspaces.get_version(
            "p1", "gw-1", "v1",
        )
        assert route.called

    @respx.mock
    def test_submit(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/versions/v1/submit"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "SUBMITTED"},
            ),
        )
        client.governed_workspaces.submit(
            "p1", "gw-1", "v1",
        )
        assert route.called

    @respx.mock
    def test_approve(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/versions/v1/approve"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "APPROVED"},
            ),
        )
        client.governed_workspaces.approve(
            "p1", "gw-1", "v1",
        )
        assert route.called

    @respx.mock
    def test_deploy(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/versions/v1/deploy"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "DEPLOYED"},
            ),
        )
        client.governed_workspaces.deploy(
            "p1", "gw-1", "v1",
        )
        assert route.called

    @respx.mock
    def test_archive(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/versions/v1/archive"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "ARCHIVED"},
            ),
        )
        client.governed_workspaces.archive(
            "p1", "gw-1", "v1",
        )
        assert route.called

    @respx.mock
    def test_create_instance(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/instances"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "i1"},
            ),
        )
        client.governed_workspaces.create_instance(
            "p1", "gw-1",
        )
        assert route.called

    @respx.mock
    def test_submit_instance(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/instances/i1/submit"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "SUBMITTED"},
            ),
        )
        client.governed_workspaces.submit_instance(
            "p1", "gw-1", "i1",
        )
        assert route.called

    @respx.mock
    def test_get_instance(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/governed-workspaces"
            "/gw-1/instances/i1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "i1"},
            ),
        )
        client.governed_workspaces.get_instance(
            "p1", "gw-1", "i1",
        )
        assert route.called


class TestAccountContractExtended:
    """Account extended operations."""

    @respx.mock
    def test_cancel_delete(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/auth/account/delete/cancel"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "cancelled"},
            ),
        )
        client.account.cancel_delete()
        assert route.called

    @respx.mock
    def test_export_latest(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/auth/account/export/latest"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "exp-1"},
            ),
        )
        client.account.export_latest()
        assert route.called

    @respx.mock
    def test_export_status(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/auth/account/export/exp-1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200,
                json={"id": "exp-1", "status": "completed"},
            ),
        )
        client.account.export_status("exp-1")
        assert route.called

    @respx.mock
    def test_export_download(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/auth/account/export/exp-1/download"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"url": "https://dl.example.com"},
            ),
        )
        client.account.export_download("exp-1")
        assert route.called


class TestWorkspaceContractExtended:
    """Workspace extended operations."""

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/org/workspaces/ws-1"
        route = respx.patch(url).mock(
            return_value=httpx.Response(
                200, json={"id": "ws-1", "name": "Updated"},
            ),
        )
        client.workspaces.update("ws-1", name="Updated")
        assert route.called

    @respx.mock
    def test_archive(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/org/workspaces/ws-1/archive"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"status": "archived"},
            ),
        )
        client.workspaces.archive("ws-1")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/org/workspaces/ws-1"
        route = respx.delete(url).mock(
            return_value=httpx.Response(204, json={}),
        )
        client.workspaces.delete("ws-1")
        assert route.called

    @respx.mock
    def test_add_member(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/org/workspaces/ws-1/members"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "a1"},
            ),
        )
        client.workspaces.add_member(
            "ws-1", user_id="u1",
        )
        assert route.called

    @respx.mock
    def test_remove_member(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/org/workspaces/ws-1/members/u1"
        )
        route = respx.delete(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.workspaces.remove_member("ws-1", "u1")
        assert route.called


class TestUserContract:
    """User operations."""

    @respx.mock
    def test_me(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/users/me",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "u-1", "email": "a@b.com"},
            ),
        )
        client.users.me()
        assert route.called

    @respx.mock
    def test_organizations(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/users/me/organizations"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": []},
            ),
        )
        client.users.organizations()
        assert route.called


class TestProjectContractExtended:
    """Project extended operations."""

    @respx.mock
    def test_list_members(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/members"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.projects.list_members("p1")
        assert route.called

    @respx.mock
    def test_add_member(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/members"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "a1"},
            ),
        )
        client.projects.add_member(
            "p1", user_id="u1", role="member",
        )
        assert route.called

    @respx.mock
    def test_remove_member(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/members/u1"
        )
        route = respx.delete(url).mock(
            return_value=httpx.Response(
                200, json={"ok": True},
            ),
        )
        client.projects.remove_member("p1", "u1")
        assert route.called

    @respx.mock
    def test_update_member(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/members/u1"
        )
        route = respx.patch(url).mock(
            return_value=httpx.Response(
                200, json={"id": "u1", "role": "admin"},
            ),
        )
        client.projects.update_member(
            "p1", "u1", role="admin",
        )
        assert route.called


class TestConnectorContractExtended:
    """Extended connector contract tests."""

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/projects/p1/connectors"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201, json={"id": "c1", "project_id": "p1"},
            ),
        )
        client.connectors.create("p1", provider="npi")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/projects/p1/connectors/c1"
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"id": "c1", "project_id": "p1"},
            ),
        )
        client.connectors.get("p1", "c1")
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/projects/p1/connectors/c1"
        route = respx.patch(url).mock(
            return_value=httpx.Response(
                200, json={"id": "c1", "project_id": "p1"},
            ),
        )
        client.connectors.update("p1", "c1", name="Updated")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/projects/p1/connectors/c1"
        route = respx.delete(url).mock(
            return_value=httpx.Response(204, json={}),
        )
        client.connectors.delete("p1", "c1")
        assert route.called

    @respx.mock
    def test_gather(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/c1/gather"
        )
        route = respx.post(url).mock(
            return_value=httpx.Response(
                202, json={"id": "g1", "status": "pending"},
            ),
        )
        client.connectors.gather("p1", "c1")
        assert route.called

    @respx.mock
    def test_analytics(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/analytics"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"total": 5},
            ),
        )
        client.connectors.analytics("p1")
        assert route.called

    @respx.mock
    def test_resources(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/c1/resources"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.connectors.resources("p1", "c1")
        assert route.called

    @respx.mock
    def test_schema(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/c1/schema"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"fields": []},
            ),
        )
        client.connectors.schema("p1", "c1")
        assert route.called

    @respx.mock
    def test_get_schedule(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/c1/schedule"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"cron": "0 * * * *"},
            ),
        )
        client.connectors.get_schedule("p1", "c1")
        assert route.called

    @respx.mock
    def test_set_schedule(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/c1/schedule"
        )
        route = respx.put(url).mock(
            return_value=httpx.Response(
                200, json={"cron": "0 6 * * *"},
            ),
        )
        client.connectors.set_schedule(
            "p1", "c1", cron="0 6 * * *",
        )
        assert route.called

    @respx.mock
    def test_list_gathers(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/connectors/c1/gathers"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.connectors.list_gathers("p1", "c1")
        assert route.called


class TestConnectorProviderContract:
    """Connector provider contract tests."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/connectors/providers"
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.connector_providers.list()
        assert route.called

    @respx.mock
    def test_schema(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/connectors/providers/npi/schema"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200, json={"fields": []},
            ),
        )
        client.connector_providers.schema("npi")
        assert route.called


class TestNamedSetContractExtended:
    """Extended named set contract tests."""

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        url = f"{MOCK_BASE_URL}/v1/projects/p1/named-sets"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                201,
                json={"id": "ns-1", "project_id": "p1"},
            ),
        )
        client.named_sets.create("p1", name="TestSet")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/named-sets/ns-1"
        )
        route = respx.get(url).mock(
            return_value=httpx.Response(
                200,
                json={"id": "ns-1", "project_id": "p1"},
            ),
        )
        client.named_sets.get("p1", "ns-1")
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/named-sets/ns-1"
        )
        route = respx.put(url).mock(
            return_value=httpx.Response(
                200,
                json={"id": "ns-1", "project_id": "p1"},
            ),
        )
        client.named_sets.update("p1", "ns-1", name="Updated")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        url = (
            f"{MOCK_BASE_URL}"
            "/v1/projects/p1/named-sets/ns-1"
        )
        route = respx.delete(url).mock(
            return_value=httpx.Response(204, json={}),
        )
        client.named_sets.delete("p1", "ns-1")
        assert route.called


class TestEnvironmentContractExtended:
    """Extended environment contract tests."""

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/e1",
        ).mock(
            return_value=httpx.Response(
                200,
                json={"id": "e1", "project_id": "p1", "name": "staging"},
            ),
        )
        client.environments.get("p1", "e1")
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        route = respx.patch(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/e1",
        ).mock(
            return_value=httpx.Response(
                200,
                json={"id": "e1", "project_id": "p1", "name": "prod"},
            ),
        )
        client.environments.update("p1", "e1", name="prod")
        assert route.called

    @respx.mock
    def test_deactivate(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/e1/deactivate",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "e1", "status": "INACTIVE"},
            ),
        )
        client.environments.deactivate("p1", "e1")
        assert route.called

    @respx.mock
    def test_reactivate(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/environments/e1/reactivate",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "e1", "status": "ACTIVE"},
            ),
        )
        client.environments.reactivate("p1", "e1")
        assert route.called


class TestAnalyticsContractExtended:
    """Extended analytics contract tests."""

    @respx.mock
    def test_deferral_rate(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/analytics/deferral-rate",
        ).mock(
            return_value=httpx.Response(
                200, json={"rate": 0.05, "total": 100},
            ),
        )
        client.analytics.deferral_rate("p1")
        assert route.called

    @respx.mock
    def test_evaluations(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/analytics/evaluations",
        ).mock(
            return_value=httpx.Response(
                200, json={"total": 500, "asserted": 475},
            ),
        )
        client.analytics.evaluations("p1")
        assert route.called

    @respx.mock
    def test_failure_reasons(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/analytics/failure-reasons",
        ).mock(
            return_value=httpx.Response(
                200, json={"items": []},
            ),
        )
        client.analytics.failure_reasons("p1")
        assert route.called


class TestFlowContractExtended:
    """Extended flow contract tests."""

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1",
        ).mock(
            return_value=httpx.Response(
                200,
                json={"id": "f1", "project_id": "p1", "name": "Flow1"},
            ),
        )
        client.flows.get("p1", "f1")
        assert route.called

    @respx.mock
    def test_update(self, client: VBOSClient) -> None:
        route = respx.patch(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1",
        ).mock(
            return_value=httpx.Response(
                200,
                json={"id": "f1", "project_id": "p1", "name": "Updated"},
            ),
        )
        client.flows.update("p1", "f1", name="Updated")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        route = respx.delete(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1",
        ).mock(
            return_value=httpx.Response(204, json={}),
        )
        client.flows.delete("p1", "f1")
        assert route.called

    @respx.mock
    def test_export(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/export",
        ).mock(
            return_value=httpx.Response(
                200, json={"definition": {}, "format": "json"},
            ),
        )
        client.flows.export("p1", "f1")
        assert route.called

    @respx.mock
    def test_from_template(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/from-template",
        ).mock(
            return_value=httpx.Response(
                201,
                json={"id": "f-2", "project_id": "p1", "name": "FromTpl"},
            ),
        )
        client.flows.from_template("p1", template_slug="basic")
        assert route.called

    @respx.mock
    def test_create_version(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions",
        ).mock(
            return_value=httpx.Response(
                201, json={"id": "v1", "flow_id": "f1"},
            ),
        )
        client.flows.create_version("p1", "f1", label="v1")
        assert route.called

    @respx.mock
    def test_list_versions(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions",
        ).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.flows.list_versions("p1", "f1")
        assert route.called

    @respx.mock
    def test_get_version(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions/v1",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "v1", "flow_id": "f1"},
            ),
        )
        client.flows.get_version("p1", "f1", "v1")
        assert route.called

    @respx.mock
    def test_update_version(self, client: VBOSClient) -> None:
        route = respx.patch(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions/v1",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "v1", "flow_id": "f1"},
            ),
        )
        client.flows.update_version("p1", "f1", "v1", label="v1.1")
        assert route.called

    @respx.mock
    def test_delete_version(self, client: VBOSClient) -> None:
        route = respx.delete(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions/v1",
        ).mock(
            return_value=httpx.Response(204, json={}),
        )
        client.flows.delete_version("p1", "f1", "v1")
        assert route.called

    @respx.mock
    def test_approve_version(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions/v1/approve",
        ).mock(
            return_value=httpx.Response(
                200, json={"status": "APPROVED"},
            ),
        )
        client.flows.approve_version("p1", "f1", "v1")
        assert route.called

    @respx.mock
    def test_deploy(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions/v1/deploy",
        ).mock(
            return_value=httpx.Response(
                201, json={"id": "d1", "status": "DEPLOYING"},
            ),
        )
        client.flows.deploy("p1", "f1", "v1")
        assert route.called

    @respx.mock
    def test_suspend(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/deployments/d1/suspend",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "d1", "status": "SUSPENDED"},
            ),
        )
        client.flows.suspend("p1", "f1", "d1")
        assert route.called

    @respx.mock
    def test_dry_run(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/versions/v1/dry-run",
        ).mock(
            return_value=httpx.Response(
                200, json={"result": "PASS"},
            ),
        )
        client.flows.dry_run("p1", "f1", "v1")
        assert route.called

    @respx.mock
    def test_list_executions(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/executions",
        ).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.flows.list_executions("p1", "f1")
        assert route.called

    @respx.mock
    def test_reconstruct_execution(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/flows/f1/executions/ex1/reconstruct",
        ).mock(
            return_value=httpx.Response(
                200, json={"id": "ex1", "status": "RECONSTRUCTED"},
            ),
        )
        client.flows.reconstruct_execution("p1", "f1", "ex1")
        assert route.called


class TestFlowTemplateContract:
    """Flow template contract tests."""

    @respx.mock
    def test_list(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/flow-templates",
        ).mock(
            return_value=httpx.Response(
                200, json={"items": [], "cursor": None},
            ),
        )
        client.flow_templates.list()
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/flow-templates/ft-1",
        ).mock(
            return_value=httpx.Response(
                200,
                json={"slug": "ft-1", "name": "Basic Template"},
            ),
        )
        client.flow_templates.get("ft-1")
        assert route.called


class TestAlertRuleContractExtended:
    """Extended alert rule contract tests."""

    @respx.mock
    def test_create(self, client: VBOSClient) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/p1/alert-rules",
        ).mock(
            return_value=httpx.Response(
                201,
                json={"id": "r1", "project_id": "p1", "name": "NewRule"},
            ),
        )
        client.alert_rules.create("p1", name="NewRule")
        assert route.called

    @respx.mock
    def test_get(self, client: VBOSClient) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/p1/alert-rules/r1",
        ).mock(
            return_value=httpx.Response(
                200,
                json={"id": "r1", "project_id": "p1", "name": "Rule1"},
            ),
        )
        client.alert_rules.get("p1", "r1")
        assert route.called

    @respx.mock
    def test_delete(self, client: VBOSClient) -> None:
        route = respx.delete(
            f"{MOCK_BASE_URL}/v1/projects/p1/alert-rules/r1",
        ).mock(
            return_value=httpx.Response(204, json={}),
        )
        client.alert_rules.delete("p1", "r1")
        assert route.called
