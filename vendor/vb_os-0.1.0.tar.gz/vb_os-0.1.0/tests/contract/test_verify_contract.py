"""Contract tests — verify SDK ↔ API contract using mock server (respx).

These tests validate that the SDK constructs correct requests and correctly
parses responses matching the cloud API's documented schema.
"""

import json

import httpx
import pytest
import respx

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL, MOCK_VERIFY_RESPONSE
from vbos.client import _VERIFY_PATH, AsyncVBOSClient, VBOSClient
from vbos.exceptions import VBOSRateLimitError, VBOSServerError, VBOSValidationError
from vbos.models import EvaluationResult


class TestSyncVerifyContract:
    """Contract: sync client sends well-formed POST /v1/verify and parses responses."""

    @respx.mock
    def test_request_has_authorization_bearer(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            client.verify(workload={"amount": 5000})

        auth = route.calls[0].request.headers["authorization"]
        assert auth == f"Bearer {MOCK_API_KEY}"

    @respx.mock
    def test_request_body_contains_workload(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            client.verify(workload={"amount": 5000, "currency": "USD"})

        body = json.loads(route.calls[0].request.content)
        assert body["workload"] == {"amount": 5000, "currency": "USD"}

    @respx.mock
    def test_request_includes_boundary_ref_when_provided(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            client.verify(workload={"x": 1}, boundary_ref="B_TEST")

        body = json.loads(route.calls[0].request.content)
        assert body["boundary_ref"] == "B_TEST"

    @respx.mock
    def test_response_parses_all_evaluation_fields(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.verify(workload={"amount": 5000})

        assert isinstance(result, EvaluationResult)
        assert result.decision in ("ASSERT", "DEFER")
        assert isinstance(result.replay_id, str)
        assert isinstance(result.evaluation_id, str)
        assert result.timestamp is not None
        assert isinstance(result.latency_ms, int)
        assert isinstance(result.boundary_ref, str)
        assert isinstance(result.boundary_version, int)
        assert result.admissibility is not None
        assert result.prohibitions is not None
        assert isinstance(result.predicate_results, dict)
        assert isinstance(result.failure_reasons, list)
        assert result.audit_artifact is not None
        assert result.audit_artifact.sealed is True

    @respx.mock
    def test_429_exposes_retry_after(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                429,
                json={"error": "rate_limited", "message": "Slow down"},
                headers={"x-request-id": "req-rl", "retry-after": "30"},
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSRateLimitError) as exc_info:
                client.verify(workload={"amount": 5000})
            assert exc_info.value.retry_after == 30.0
            assert exc_info.value.status_code == 429

    @respx.mock
    def test_validation_error_carries_details(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                400,
                json={
                    "error": "validation_error",
                    "message": "Workload is empty",
                    "details": {"field": "workload", "constraint": "non_empty"},
                },
                headers={"x-request-id": "req-val"},
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSValidationError) as exc_info:
                client.verify(workload={})
            assert exc_info.value.details["field"] == "workload"

    @respx.mock
    def test_server_error_after_retries_exhausted(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                503,
                json={"error": "service_unavailable", "message": "Try later"},
                headers={"x-request-id": "req-503"},
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSServerError):
                client.verify(workload={"amount": 5000})


class TestAsyncVerifyContract:
    """Contract: async client sends well-formed POST /v1/verify and parses responses."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_request_has_authorization_bearer(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            await client.verify(workload={"amount": 5000})

        auth = route.calls[0].request.headers["authorization"]
        assert auth == f"Bearer {MOCK_API_KEY}"

    @pytest.mark.asyncio
    @respx.mock
    async def test_response_parses_all_evaluation_fields(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.verify(workload={"amount": 5000})

        assert isinstance(result, EvaluationResult)
        assert result.decision == "ASSERT"
        assert result.audit_artifact.sealed is True

    @pytest.mark.asyncio
    @respx.mock
    async def test_429_exposes_retry_after(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                429,
                json={"error": "rate_limited", "message": "Slow down"},
                headers={"x-request-id": "req-rl", "retry-after": "15"},
            )
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            with pytest.raises(VBOSRateLimitError) as exc_info:
                await client.verify(workload={"amount": 5000})
            assert exc_info.value.retry_after == 15.0
