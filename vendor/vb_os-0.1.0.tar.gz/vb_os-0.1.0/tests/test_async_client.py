"""Unit tests for vbos.client — AsyncVBOSClient."""

import httpx
import pytest
import respx

from tests.conftest import (
    MOCK_API_KEY,
    MOCK_BASE_URL,
    MOCK_DEFER_RESPONSE,
    MOCK_ERROR_RESPONSE,
    MOCK_VERIFY_RESPONSE,
)
from vbos.client import _USER_AGENT, _VERIFY_PATH, AsyncVBOSClient
from vbos.exceptions import (
    VBOSAuthenticationError,
    VBOSRateLimitError,
    VBOSServerError,
    VBOSValidationError,
)
from vbos.models import EvaluationResult


class TestAsyncVBOSClientInit:
    def test_authorization_header_set(self) -> None:
        client = AsyncVBOSClient(api_key=MOCK_API_KEY)
        assert client._client.headers["authorization"] == f"Bearer {MOCK_API_KEY}"

    def test_user_agent_header_set(self) -> None:
        client = AsyncVBOSClient(api_key=MOCK_API_KEY)
        assert client._client.headers["user-agent"] == _USER_AGENT

    def test_custom_base_url(self) -> None:
        client = AsyncVBOSClient(api_key=MOCK_API_KEY, base_url="https://custom.api.com/")
        assert client._base_url == "https://custom.api.com"


class TestAsyncVBOSClientVerify:
    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_assert_returns_evaluation_result(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.verify(workload={"amount": 5000, "currency": "USD"})

        assert isinstance(result, EvaluationResult)
        assert result.decision == "ASSERT"

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_with_boundary_ref(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            await client.verify(
                workload={"amount": 5000},
                boundary_ref="B_FIN_PAYMENT",
            )

        import json
        body = json.loads(route.calls[0].request.content)
        assert body["boundary_ref"] == "B_FIN_PAYMENT"

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_with_metadata(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            await client.verify(
                workload={"amount": 5000},
                metadata={"trace_id": "t-123"},
            )

        import json
        body = json.loads(route.calls[0].request.content)
        assert body["metadata"] == {"trace_id": "t-123"}

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_401_raises_authentication_error(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                401,
                json={"error": "unauthenticated", "message": "Invalid API key"},
                headers={"x-request-id": "req-401"},
            )
        )
        async with AsyncVBOSClient(
            api_key="bad_key", base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            with pytest.raises(VBOSAuthenticationError):
                await client.verify(workload={"amount": 5000})

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_400_raises_validation_error(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                400,
                json=MOCK_ERROR_RESPONSE,
                headers={"x-request-id": "req-400"},
            )
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            with pytest.raises(VBOSValidationError) as exc_info:
                await client.verify(workload={})
            assert exc_info.value.details == {"field": "workload", "constraint": "non_empty"}

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_429_raises_rate_limit_with_retry_after(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                429,
                json={"error": "rate_limited", "message": "Slow down"},
                headers={"x-request-id": "req-429", "retry-after": "5"},
            )
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            with pytest.raises(VBOSRateLimitError) as exc_info:
                await client.verify(workload={"amount": 5000})
            assert exc_info.value.retry_after == 5.0

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_500_raises_server_error(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                500,
                json={"error": "internal", "message": "Server error"},
                headers={"x-request-id": "req-500"},
            )
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            with pytest.raises(VBOSServerError):
                await client.verify(workload={"amount": 5000})

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_defer_response(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_DEFER_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.verify(workload={"amount": 5000})

        assert result.decision == "DEFER"
        assert len(result.failure_reasons) > 0

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_no_optional_fields_omits_from_payload(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            await client.verify(workload={"amount": 5000})

        import json
        body = json.loads(route.calls[0].request.content)
        assert "boundary_ref" not in body
        assert "metadata" not in body

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AsyncVBOSClient(api_key=MOCK_API_KEY) as client:
            assert isinstance(client, AsyncVBOSClient)
