"""Unit tests for async evaluations sub-client — replay, list, get."""

import httpx
import pytest
import respx

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL
from tests.test_evaluations import (
    EVAL_ID,
    MOCK_DETAIL_RESPONSE,
    MOCK_PAGINATED_RESPONSE,
    MOCK_REPLAY_RESPONSE,
    PROJECT_ID,
)
from vbos.client import _EVALUATIONS_PATH, AsyncVBOSClient
from vbos.exceptions import VBOSAuthenticationError, VBOSNotFoundError
from vbos.models import (
    EvaluationDetailResult,
    PaginatedEvaluationResult,
    ReplayResult,
)


class TestAsyncEvaluationsReplay:
    @respx.mock
    @pytest.mark.asyncio
    async def test_replay_returns_replay_result(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}/replay"
        route = respx.post(path).mock(
            return_value=httpx.Response(200, json=MOCK_REPLAY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            result = await client.evaluations.replay(PROJECT_ID, EVAL_ID)

        assert isinstance(result, ReplayResult)
        assert result.decision == "ASSERT"
        assert result.result_match is True
        assert route.called

    @respx.mock
    @pytest.mark.asyncio
    async def test_replay_deprecated_alias_delegates(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}/replay"
        respx.post(path).mock(
            return_value=httpx.Response(200, json=MOCK_REPLAY_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            result = await client.replay(PROJECT_ID, EVAL_ID)

        assert isinstance(result, ReplayResult)
        assert result.evaluation_id == EVAL_ID

    @respx.mock
    @pytest.mark.asyncio
    async def test_replay_401_raises_auth_error(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}/replay"
        respx.post(path).mock(
            return_value=httpx.Response(
                401, json={"error": "unauthenticated", "message": "Invalid API key"}
            )
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            with pytest.raises(VBOSAuthenticationError):
                await client.evaluations.replay(PROJECT_ID, EVAL_ID)


class TestAsyncEvaluationsList:
    @respx.mock
    @pytest.mark.asyncio
    async def test_list_returns_paginated_result(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}"
        route = respx.get(path).mock(
            return_value=httpx.Response(200, json=MOCK_PAGINATED_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            result = await client.evaluations.list(PROJECT_ID)

        assert isinstance(result, PaginatedEvaluationResult)
        assert len(result.items) == 1
        assert result.cursor is not None
        assert route.called

    @respx.mock
    @pytest.mark.asyncio
    async def test_list_with_cursor(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}"
        respx.get(path).mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None})
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            result = await client.evaluations.list(
                PROJECT_ID, limit=10, cursor="xyz"
            )

        assert isinstance(result, PaginatedEvaluationResult)
        assert result.items == []


class TestAsyncEvaluationsGet:
    @respx.mock
    @pytest.mark.asyncio
    async def test_get_returns_detail_result(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}"
        route = respx.get(path).mock(
            return_value=httpx.Response(200, json=MOCK_DETAIL_RESPONSE)
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            result = await client.evaluations.get(PROJECT_ID, EVAL_ID)

        assert isinstance(result, EvaluationDetailResult)
        assert result.record.id == EVAL_ID
        assert result.artifact_available is True
        assert route.called

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_404_raises_not_found(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}"
        respx.get(path).mock(
            return_value=httpx.Response(
                404, json={"error": "not_found", "message": "Evaluation not found"}
            )
        )
        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY,
            base_url=MOCK_BASE_URL,
            max_retries=0,
        ) as client:
            with pytest.raises(VBOSNotFoundError):
                await client.evaluations.get(PROJECT_ID, EVAL_ID)
