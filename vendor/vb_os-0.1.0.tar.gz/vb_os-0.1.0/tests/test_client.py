"""Unit tests for vbos.client — VBOSClient (sync)."""

import httpx
import pytest
import respx

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL, MOCK_ERROR_RESPONSE, MOCK_VERIFY_RESPONSE
from vbos.client import _DEFAULT_BASE_URL, _USER_AGENT, _VERIFY_PATH, VBOSClient
from vbos.exceptions import (
    VBOSAuthenticationError,
    VBOSRateLimitError,
    VBOSServerError,
    VBOSValidationError,
)
from vbos.models import EvaluationResult


class TestVBOSClientInit:
    def test_default_base_url(self) -> None:
        client = VBOSClient(api_key=MOCK_API_KEY)
        assert client._base_url == _DEFAULT_BASE_URL
        client.close()

    def test_custom_base_url_strips_trailing_slash(self) -> None:
        client = VBOSClient(api_key=MOCK_API_KEY, base_url="https://custom.api.com/")
        assert client._base_url == "https://custom.api.com"
        client.close()

    def test_authorization_header_set(self) -> None:
        client = VBOSClient(api_key=MOCK_API_KEY)
        assert client._client.headers["authorization"] == f"Bearer {MOCK_API_KEY}"
        client.close()

    def test_user_agent_header_set(self) -> None:
        client = VBOSClient(api_key=MOCK_API_KEY)
        assert client._client.headers["user-agent"] == _USER_AGENT
        client.close()

    def test_context_manager(self) -> None:
        with VBOSClient(api_key=MOCK_API_KEY) as client:
            assert isinstance(client, VBOSClient)


class TestVBOSClientVerify:
    @respx.mock
    def test_verify_assert_returns_evaluation_result(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.verify(workload={"amount": 5000, "currency": "USD"})

        assert isinstance(result, EvaluationResult)
        assert result.decision == "ASSERT"
        assert route.called

    @respx.mock
    def test_verify_with_boundary_ref(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.verify(
                workload={"amount": 5000},
                boundary_ref="B_FIN_PAYMENT",
            )

        assert result.decision == "ASSERT"
        request_body = route.calls[0].request.content
        import json
        body = json.loads(request_body)
        assert body["boundary_ref"] == "B_FIN_PAYMENT"

    @respx.mock
    def test_verify_with_metadata(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            client.verify(
                workload={"amount": 5000},
                metadata={"trace_id": "t-123"},
            )

        import json
        body = json.loads(route.calls[0].request.content)
        assert body["metadata"] == {"trace_id": "t-123"}

    @respx.mock
    def test_verify_401_raises_authentication_error(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                401,
                json={"error": "unauthenticated", "message": "Invalid API key"},
                headers={"x-request-id": "req-401"},
            )
        )
        with VBOSClient(api_key="bad_key", base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSAuthenticationError) as exc_info:
                client.verify(workload={"amount": 5000})
            assert exc_info.value.status_code == 401

    @respx.mock
    def test_verify_400_raises_validation_error(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                400,
                json=MOCK_ERROR_RESPONSE,
                headers={"x-request-id": "req-400"},
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSValidationError) as exc_info:
                client.verify(workload={})
            assert exc_info.value.details == {"field": "workload", "constraint": "non_empty"}

    @respx.mock
    def test_verify_429_raises_rate_limit_error_with_retry_after(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                429,
                json={"error": "rate_limited", "message": "Slow down"},
                headers={"x-request-id": "req-429", "retry-after": "10"},
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSRateLimitError) as exc_info:
                client.verify(workload={"amount": 5000})
            assert exc_info.value.retry_after == 10.0

    @respx.mock
    def test_verify_500_raises_server_error_after_retries(self) -> None:
        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(
                500,
                json={"error": "internal", "message": "Server error"},
                headers={"x-request-id": "req-500"},
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSServerError):
                client.verify(workload={"amount": 5000})

    @respx.mock
    def test_verify_sends_correct_content_type(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            client.verify(workload={"amount": 5000})

        assert "application/json" in route.calls[0].request.headers["content-type"]

    @respx.mock
    def test_verify_no_boundary_ref_omits_from_payload(self) -> None:
        route = respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_VERIFY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            client.verify(workload={"amount": 5000})

        import json
        body = json.loads(route.calls[0].request.content)
        assert "boundary_ref" not in body
        assert "metadata" not in body

    @respx.mock
    def test_verify_defer_response_parsed(self) -> None:
        from tests.conftest import MOCK_DEFER_RESPONSE

        respx.post(f"{MOCK_BASE_URL}{_VERIFY_PATH}").mock(
            return_value=httpx.Response(200, json=MOCK_DEFER_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.verify(workload={"amount": 5000})

        assert result.decision == "DEFER"
        assert len(result.failure_reasons) > 0
