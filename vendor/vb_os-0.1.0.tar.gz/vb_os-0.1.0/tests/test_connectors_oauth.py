"""Tests for connector OAuth SDK methods (sync and async)."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL
from vbos.client import VBOSClient
from vbos.resources.connectors import _TERMINAL_STATUSES

_PROJECT = "proj-test-1"
_CONNECTOR = "conn-test-1"


class TestSyncConnectorsOAuth:
    @respx.mock
    def test_authorize_sends_remote_mode(self) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/authorize"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.authorize(_PROJECT, _CONNECTOR)

        assert route.called
        assert result["mode"] == "REMOTE"
        assert result["authorization_id"] == "aid-1"
        assert result["poll_interval"] == 3
        assert result["expires_in"] == 600

        req = route.calls[0].request
        import json
        body = json.loads(req.content)
        assert body["mode"] == "REMOTE"

    @respx.mock
    def test_authorize_custom_mode(self) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/authorize"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_url": "https://example.com/auth",
            "mode": "BROWSER",
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.authorize(_PROJECT, _CONNECTOR, mode="BROWSER")

        assert route.called
        import json
        body = json.loads(route.calls[0].request.content)
        assert body["mode"] == "BROWSER"

    @respx.mock
    def test_disconnect_calls_endpoint(self) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/disconnect"
        ).mock(return_value=httpx.Response(200, json={
            "success": True,
            "connector_id": _CONNECTOR,
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.disconnect(_PROJECT, _CONNECTOR)

        assert route.called
        assert result["success"] is True

    @respx.mock
    def test_reconnect_sends_remote_mode(self) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/reconnect"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_url": "https://console.vb-os.org/connect/xyz",
            "mode": "REMOTE",
            "authorization_id": "aid-2",
            "poll_interval": 3,
            "expires_in": 600,
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.reconnect(_PROJECT, _CONNECTOR)

        assert route.called
        assert result["mode"] == "REMOTE"
        import json
        body = json.loads(route.calls[0].request.content)
        assert body["mode"] == "REMOTE"

    @respx.mock
    def test_oauth_status(self) -> None:
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/status"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_status": "AUTHORIZED",
            "has_active_grant": True,
            "provider_account_id": "user@test.com",
            "granted_scopes": ["read", "write"],
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.oauth_status(_PROJECT, _CONNECTOR)

        assert route.called
        assert result["authorization_status"] == "AUTHORIZED"

    @respx.mock
    def test_wait_for_authorization_completed(self) -> None:
        aid = "test-auth-id"
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/{aid}/status"
        ).mock(side_effect=[
            httpx.Response(200, json={"status": "PENDING"}),
            httpx.Response(200, json={
                "status": "COMPLETED",
                "connector_id": "conn-1",
                "authorization_status": "AUTHORIZED",
            }),
        ])

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.wait_for_authorization(
                aid, timeout=60, poll_interval=0,
            )

        assert result["status"] == "COMPLETED"
        assert route.call_count == 2

    @respx.mock
    def test_wait_for_authorization_404(self) -> None:
        aid = "nonexistent-id"
        respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/{aid}/status"
        ).mock(return_value=httpx.Response(404, json={"detail": "Not found"}))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.wait_for_authorization(aid, timeout=5)

        assert result["status"] == "NOT_FOUND"

    @respx.mock
    def test_wait_for_authorization_timeout(self) -> None:
        aid = "timeout-id"
        respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/{aid}/status"
        ).mock(return_value=httpx.Response(200, json={"status": "PENDING"}))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.wait_for_authorization(
                aid, timeout=0, poll_interval=0,
            )

        assert result["status"] == "TIMEOUT"


class TestSyncWaitTerminalStatuses:
    @respx.mock
    @pytest.mark.parametrize("terminal_status", list(_TERMINAL_STATUSES))
    def test_terminal_status_stops_polling(self, terminal_status: str) -> None:
        aid = "term-id"
        respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/{aid}/status"
        ).mock(return_value=httpx.Response(200, json={"status": terminal_status}))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.wait_for_authorization(
                aid, timeout=60, poll_interval=0,
            )

        assert result["status"] == terminal_status


class TestAsyncConnectorsOAuth:
    @respx.mock
    @pytest.mark.asyncio
    async def test_authorize_sends_remote_mode(self) -> None:
        from vbos.client import AsyncVBOSClient

        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/authorize"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        }))

        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.connectors.authorize(_PROJECT, _CONNECTOR)

        assert route.called
        assert result["mode"] == "REMOTE"

    @respx.mock
    @pytest.mark.asyncio
    async def test_disconnect_calls_endpoint(self) -> None:
        from vbos.client import AsyncVBOSClient

        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/disconnect"
        ).mock(return_value=httpx.Response(200, json={
            "success": True,
            "connector_id": _CONNECTOR,
        }))

        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.connectors.disconnect(_PROJECT, _CONNECTOR)

        assert route.called
        assert result["success"] is True

    @respx.mock
    @pytest.mark.asyncio
    async def test_wait_for_authorization_completed(self) -> None:
        from vbos.client import AsyncVBOSClient

        aid = "async-auth-id"
        route = respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/{aid}/status"
        ).mock(side_effect=[
            httpx.Response(200, json={"status": "PENDING"}),
            httpx.Response(200, json={
                "status": "COMPLETED",
                "authorization_status": "AUTHORIZED",
            }),
        ])

        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.connectors.wait_for_authorization(
                aid, timeout=60, poll_interval=0,
            )

        assert result["status"] == "COMPLETED"
        assert route.call_count == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_wait_for_authorization_timeout(self) -> None:
        from vbos.client import AsyncVBOSClient

        aid = "async-timeout-id"
        respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/{aid}/status"
        ).mock(return_value=httpx.Response(200, json={"status": "PENDING"}))

        async with AsyncVBOSClient(
            api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0,
        ) as client:
            result = await client.connectors.wait_for_authorization(
                aid, timeout=0, poll_interval=0,
            )

        assert result["status"] == "TIMEOUT"


class TestResponseNoSecrets:
    @respx.mock
    def test_authorize_response_no_token_fields(self) -> None:
        route = respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/authorize"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_url": "https://console.vb-os.org/connect/abc",
            "mode": "REMOTE",
            "authorization_id": "aid-1",
            "poll_interval": 3,
            "expires_in": 600,
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.authorize(_PROJECT, _CONNECTOR)

        for key in result:
            assert "token" not in key.lower() or key in ("ui_transaction_id",)
            assert "secret" not in key.lower()
            assert "password" not in key.lower()

    @respx.mock
    def test_authorize_response_no_secret_keys(self) -> None:
        """Authorize response must not contain token/secret/password field names."""
        respx.post(
            f"{MOCK_BASE_URL}/v1/projects/{_PROJECT}/connectors/{_CONNECTOR}/oauth/authorize"
        ).mock(return_value=httpx.Response(200, json={
            "authorization_url": "https://example.com",
            "mode": "REMOTE",
            "authorization_id": "aid-sec",
            "poll_interval": 3,
            "expires_in": 600,
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.authorize(_PROJECT, _CONNECTOR)

        for key in result:
            assert "secret" not in key.lower(), f"secret-like key '{key}' in authorize response"
            assert "password" not in key.lower(), f"password-like key '{key}' in authorize response"
            assert key not in ("access_token", "refresh_token", "client_secret",
                               "code_verifier", "authorization_code")

    @respx.mock
    def test_wait_response_no_secret_keys(self) -> None:
        """Poll/wait response must not contain token/secret/password field names."""
        respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/aid-wait/status"
        ).mock(return_value=httpx.Response(200, json={
            "status": "COMPLETED",
            "connector_id": "conn-1",
            "authorization_status": "AUTHORIZED",
            "provider_account_display": "user@test.com",
            "granted_scopes": ["read"],
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.wait_for_authorization("aid-wait")

        for key in result:
            assert key not in ("access_token", "refresh_token", "client_secret",
                               "code_verifier", "authorization_code")

    @respx.mock
    def test_exception_no_secret_material(self) -> None:
        """SDK exceptions must not contain secret material in string representation."""
        from vbos.exceptions import VBOSNotFoundError
        respx.get(
            f"{MOCK_BASE_URL}/v1/connectors/oauth/authorizations/aid-err/status"
        ).mock(return_value=httpx.Response(404, json={
            "error": "not_found",
            "message": "Not found",
        }))

        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.connectors.wait_for_authorization("aid-err")

        assert result["status"] == "NOT_FOUND"
