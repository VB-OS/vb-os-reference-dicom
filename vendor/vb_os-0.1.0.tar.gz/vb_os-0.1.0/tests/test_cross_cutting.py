"""Cross-cutting tests for SDK invariants (XC-02 through XC-14)."""

from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest
import respx
from pydantic import ValidationError

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL
from vbos.client import VBOSClient
from vbos.exceptions import VBOSError, VBOSServerError
from vbos.models import (
    APIKeyCreated,
    Boundary,
    BoundaryList,
    EvaluationResult,
    Project,
    WebhookCreated,
)


class TestForwardCompatibility:
    """XC-02/XC-03: Models with extra="ignore" handle unknown fields gracefully."""

    def test_unknown_fields_ignored(self) -> None:
        data = {
            "id": "proj-1",
            "org_id": "org-1",
            "name": "Test",
            "slug": "test",
            "totally_new_field": "should be ignored",
            "another_future_field": 42,
        }
        project = Project.model_validate(data)
        assert project.id == "proj-1"
        assert project.name == "Test"
        assert not hasattr(project, "totally_new_field")

    def test_unknown_fields_ignored_boundary(self) -> None:
        data = {
            "id": "b-1",
            "project_id": "p-1",
            "boundary_ref": "B_TEST",
            "new_v2_field": True,
        }
        boundary = Boundary.model_validate(data)
        assert boundary.boundary_ref == "B_TEST"

    def test_unknown_fields_ignored_list(self) -> None:
        data = {
            "items": [{"id": "b-1", "project_id": "p-1", "boundary_ref": "B_TEST"}],
            "cursor": None,
            "total_count": 999,
        }
        result = BoundaryList.model_validate(data)
        assert len(result.items) == 1

    def test_missing_required_fields_fails(self) -> None:
        with pytest.raises(ValidationError):
            Project.model_validate({"slug": "test"})

    def test_missing_required_nested_fails(self) -> None:
        with pytest.raises(ValidationError):
            EvaluationResult.model_validate({"decision": "ASSERT"})

    def test_unknown_on_webhook_created(self) -> None:
        data = {
            "id": "wh-1",
            "url": "https://example.com",
            "secret": "sec_abc",
            "future_field": True,
        }
        wh = WebhookCreated.model_validate(data)
        assert wh.secret == "sec_abc"

    def test_unknown_on_api_key_created(self) -> None:
        data = {
            "id": "key-1",
            "key": "vbos_live_abc123",
            "future_rotation_count": 5,
        }
        key = APIKeyCreated.model_validate(data)
        assert key.key == "vbos_live_abc123"


class TestSecretLeakage:
    """XC-04: Secret values never in exception __str__/__repr__."""

    def test_api_key_not_in_error_str(self) -> None:
        err = VBOSError(
            status_code=401,
            error_code="unauthorized",
            message="Invalid API key",
            request_id="req-1",
        )
        assert "vbos_live_" not in str(err)
        assert "vbos_live_" not in repr(err)

    def test_webhook_secret_not_in_error_repr(self) -> None:
        err = VBOSError(
            status_code=500,
            error_code="internal",
            message="Webhook delivery failed",
            details={"webhook_id": "wh-1"},
            request_id="req-2",
        )
        assert "sec_" not in str(err)
        assert "sec_" not in repr(err)

    def test_server_error_no_secrets(self) -> None:
        err = VBOSServerError(
            status_code=500,
            error_code="internal_error",
            message="Server error",
            request_id="req-3",
        )
        assert "vbos_" not in repr(err)


class TestQueryParameterHandling:
    """XC-06: None values omitted from query params."""

    @respx.mock
    def test_none_params_omitted(self) -> None:
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            client.projects.list()
            request = route.calls[0].request
            assert b"None" not in request.url.query
        finally:
            client.close()


class TestRequestBodyImmutability:
    """XC-07: Request bodies don't mutate caller-provided dicts."""

    @respx.mock
    def test_verify_does_not_mutate_workload(self) -> None:
        respx.post(f"{MOCK_BASE_URL}/v1/verify").mock(
            return_value=httpx.Response(200, json=_mock_eval_response()),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            workload = {"amount": 5000}
            original = workload.copy()
            client.verify(workload)
            assert workload == original
        finally:
            client.close()


class TestErrorParity:
    """XC-08/XC-13: Error mapping parity across status codes."""

    @respx.mock
    def test_401_raises_authentication_error(self) -> None:
        from vbos.exceptions import VBOSAuthenticationError
        respx.get(f"{MOCK_BASE_URL}/v1/projects").mock(
            return_value=httpx.Response(
                401, json={"error": "unauthorized", "message": "Bad key"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with pytest.raises(VBOSAuthenticationError):
                client.projects.list()
        finally:
            client.close()

    @respx.mock
    def test_403_raises_authorization_error(self) -> None:
        from vbos.exceptions import VBOSAuthorizationError
        respx.get(f"{MOCK_BASE_URL}/v1/org").mock(
            return_value=httpx.Response(
                403, json={"error": "forbidden", "message": "No access"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with pytest.raises(VBOSAuthorizationError):
                client.org.get()
        finally:
            client.close()

    @respx.mock
    def test_404_raises_not_found_error(self) -> None:
        from vbos.exceptions import VBOSNotFoundError
        respx.get(f"{MOCK_BASE_URL}/v1/projects/bad-id").mock(
            return_value=httpx.Response(
                404, json={"error": "not_found", "message": "Not found"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with pytest.raises(VBOSNotFoundError):
                client.projects.get("bad-id")
        finally:
            client.close()

    @respx.mock
    def test_429_raises_rate_limit_error(self) -> None:
        from vbos.exceptions import VBOSRateLimitError
        respx.get(f"{MOCK_BASE_URL}/v1/org/members").mock(
            return_value=httpx.Response(
                429,
                json={"error": "rate_limited", "message": "Slow down"},
                headers={"retry-after": "30"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with pytest.raises(VBOSRateLimitError) as exc_info:
                client.members.list()
            assert exc_info.value.retry_after == 30.0
        finally:
            client.close()

    @respx.mock
    def test_500_raises_server_error(self) -> None:
        respx.get(f"{MOCK_BASE_URL}/v1/org/usage").mock(
            return_value=httpx.Response(
                500, json={"error": "internal", "message": "Server error"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0)
        try:
            with pytest.raises(VBOSServerError):
                client.billing.usage()
        finally:
            client.close()


class TestCertificationsWait:
    """XC-09/XC-10/XC-11: certifications.wait() behavior."""

    @respx.mock
    def test_wait_stops_on_completed(self) -> None:
        respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run1").mock(
            return_value=httpx.Response(
                200, json={"id": "run1", "project_id": "p1", "status": "COMPLETED"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with patch("time.sleep"):
                result = client.certifications.wait("p1", "run1")
            assert result["status"] == "COMPLETED"
        finally:
            client.close()

    @respx.mock
    def test_wait_stops_on_failed(self) -> None:
        respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run1").mock(
            return_value=httpx.Response(
                200, json={"id": "run1", "project_id": "p1", "status": "FAILED"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with patch("time.sleep"):
                result = client.certifications.wait("p1", "run1")
            assert result["status"] == "FAILED"
        finally:
            client.close()

    @respx.mock
    def test_wait_raises_on_max_attempts(self) -> None:
        respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run1").mock(
            return_value=httpx.Response(
                200, json={"id": "run1", "project_id": "p1", "status": "RUNNING"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with patch("time.sleep"):
                with pytest.raises(VBOSError, match="max attempts"):
                    client.certifications.wait("p1", "run1", max_attempts=3)
        finally:
            client.close()

    @respx.mock
    def test_wait_propagates_api_errors(self) -> None:
        respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run1").mock(
            return_value=httpx.Response(
                404, json={"error": "not_found", "message": "Not found"},
            ),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            from vbos.exceptions import VBOSNotFoundError
            with patch("time.sleep"):
                with pytest.raises(VBOSNotFoundError):
                    client.certifications.wait("p1", "run1")
        finally:
            client.close()

    @respx.mock
    def test_wait_no_real_sleep(self) -> None:
        call_count = 0
        responses = [
            httpx.Response(200, json={"id": "run1", "project_id": "p1", "status": "RUNNING"}),
            httpx.Response(200, json={"id": "run1", "project_id": "p1", "status": "COMPLETED"}),
        ]

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            resp = responses[min(call_count, len(responses) - 1)]
            call_count += 1
            return resp

        respx.get(f"{MOCK_BASE_URL}/v1/projects/p1/certifications/run1").mock(
            side_effect=side_effect,
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            with patch("time.sleep") as mock_sleep:
                client.certifications.wait("p1", "run1")
                mock_sleep.assert_called()
        finally:
            client.close()


class TestPaginationCursors:
    """XC-14: Explicit cursors transmitted unchanged."""

    @respx.mock
    def test_cursor_passed_unchanged(self) -> None:
        cursor_value = "eyJhZnRlciI6ICIyMDI2LTAxLTAxIn0="
        route = respx.get(f"{MOCK_BASE_URL}/v1/projects").mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None}),
        )
        client = VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL)
        try:
            client.projects.list(cursor=cursor_value)
            request = route.calls[0].request
            from urllib.parse import unquote
            assert cursor_value in unquote(str(request.url))
        finally:
            client.close()


def _mock_eval_response() -> dict:
    from tests.conftest import MOCK_VERIFY_RESPONSE
    return MOCK_VERIFY_RESPONSE
