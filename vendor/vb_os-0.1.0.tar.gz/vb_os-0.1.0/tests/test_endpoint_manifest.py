"""Endpoint manifest test — proves every §5.1 ledger row maps to exactly one
sync method, one async method, and the declared HTTP verb/path (AC-31/XC-15)."""

from __future__ import annotations

import inspect

import pytest

from vbos.client import AsyncVBOSClient, VBOSClient

ENDPOINT_LEDGER: list[tuple[str, str, str, str]] = [
    # (http_method, path_template, namespace_or_toplevel, method_name)
    # B2 Part 7 — Verification
    ("POST", "/v1/verify", "", "verify"),
    ("POST", "/v1/verify/batch", "", "verify_batch"),
    ("POST", "/v1/validate", "", "validate"),
    # B2 Part 8 — Boundaries
    ("GET", "/v1/projects/{}/boundaries", "boundaries", "list"),
    ("POST", "/v1/projects/{}/boundaries", "boundaries", "create"),
    ("GET", "/v1/projects/{}/boundaries/{}", "boundaries", "get"),
    ("PATCH", "/v1/projects/{}/boundaries/{}/draft", "boundaries", "update_draft"),
    ("POST", "/v1/projects/{}/boundaries/{}/submit", "boundaries", "submit"),
    ("GET", "/v1/projects/{}/boundaries/{}/versions", "boundaries", "versions"),
    ("GET", "/v1/projects/{}/boundaries/{}/versions/{}", "boundaries", "get_version"),
    ("POST", "/v1/projects/{}/boundaries/{}/versions/{}/approve", "boundaries", "approve"),
    ("POST", "/v1/projects/{}/boundaries/{}/versions/{}/reject", "boundaries", "reject"),
    ("GET", "/v1/projects/{}/boundaries/{}/diff", "boundaries", "diff"),
    # B2 Part 9 — Deployments
    ("GET", "/v1/projects/{}/environments/{}/deployments", "deployments", "list"),
    ("POST", "/v1/projects/{}/environments/{}/deployments", "deployments", "create"),
    ("GET", "/v1/projects/{}/environments/{}/deployments/active", "deployments", "active"),
    ("POST", "/v1/projects/{}/environments/{}/deployments/{}/approve", "deployments", "approve"),
    ("POST", "/v1/projects/{}/environments/{}/deployments/{}/reject", "deployments", "reject"),
    ("POST", "/v1/projects/{}/environments/{}/promote", "deployments", "promote"),
    ("POST", "/v1/projects/{}/environments/{}/rollback", "deployments", "rollback"),
    # B2 Part 10 — Evaluations
    ("GET", "/v1/projects/{}/evaluations", "evaluations", "list"),
    ("GET", "/v1/projects/{}/evaluations/{}", "evaluations", "get"),
    ("POST", "/v1/projects/{}/evaluations/{}/replay", "evaluations", "replay"),
    ("POST", "/v1/projects/{}/evaluations/export", "evaluations", "export"),
    # B2 Part 11 — Certifications
    ("POST", "/v1/projects/{}/certify", "", "certify"),
    ("GET", "/v1/projects/{}/certifications", "certifications", "list"),
    ("GET", "/v1/projects/{}/certifications/{}", "certifications", "get"),
    ("GET", "/v1/projects/{}/certifications/{}/report", "certifications", "get_report"),
    ("GET", "/v1/projects/{}/certification-models", "certification_models", "list"),
    ("POST", "/v1/projects/{}/certification-models", "certification_models", "create"),
    (
        "POST", "/v1/projects/{}/certification-models/{}/versions",
        "certification_models", "create_version",
    ),
    # B2 Part 12 — Projects & Environments
    ("GET", "/v1/projects", "projects", "list"),
    ("POST", "/v1/projects", "projects", "create"),
    ("GET", "/v1/projects/{}", "projects", "get"),
    ("PATCH", "/v1/projects/{}", "projects", "update"),
    ("GET", "/v1/projects/{}/environments", "environments", "list"),
    # B2 Part 13 — Templates
    ("GET", "/v1/templates", "templates", "list"),
    ("GET", "/v1/templates/{}", "templates", "get"),
    ("POST", "/v1/templates/{}/fork", "templates", "fork"),
    # B2 Part 14 — Org & Members
    ("GET", "/v1/org", "org", "get"),
    ("GET", "/v1/org/workspaces", "workspaces", "list"),
    ("POST", "/v1/org/workspaces", "workspaces", "create"),
    ("GET", "/v1/org/members", "members", "list"),
    ("POST", "/v1/org/members", "members", "invite"),
    ("POST", "/v1/org/members/{}/role", "members", "set_role"),
    ("DELETE", "/v1/org/members/{}", "members", "remove"),
    ("POST", "/v1/org/ownership-transfer", "org", "transfer_ownership"),
    ("POST", "/v1/org/ownership-transfer/{}/accept", "org", "accept_transfer"),
    ("POST", "/v1/org/ownership-transfer/{}/cancel", "org", "cancel_transfer"),
    # B2 Part 15 — API Keys
    ("GET", "/v1/projects/{}/environments/{}/keys", "keys", "list"),
    ("POST", "/v1/projects/{}/environments/{}/keys", "keys", "create"),
    ("POST", "/v1/projects/{}/environments/{}/keys/{}/rotate", "keys", "rotate"),
    ("POST", "/v1/projects/{}/environments/{}/keys/{}/revoke", "keys", "revoke"),
    # B2 Part 16 — Service Accounts
    ("GET", "/v1/org/service-accounts", "service_accounts", "list"),
    ("POST", "/v1/org/service-accounts", "service_accounts", "create"),
    ("PATCH", "/v1/org/service-accounts/{}", "service_accounts", "update"),
    ("POST", "/v1/org/service-accounts/{}/disable", "service_accounts", "disable"),
    ("POST", "/v1/org/service-accounts/{}/enable", "service_accounts", "enable"),
    # B2 Part 17 — Webhooks
    ("GET", "/v1/projects/{}/webhooks", "webhooks", "list"),
    ("POST", "/v1/projects/{}/webhooks", "webhooks", "create"),
    ("PATCH", "/v1/projects/{}/webhooks/{}", "webhooks", "update"),
    ("DELETE", "/v1/projects/{}/webhooks/{}", "webhooks", "delete"),
    ("POST", "/v1/projects/{}/webhooks/{}/rotate-secret", "webhooks", "rotate_secret"),
    ("GET", "/v1/projects/{}/webhooks/{}/deliveries", "webhooks", "deliveries"),
    ("GET", "/v1/org/webhooks", "webhooks", "list_org"),
    ("POST", "/v1/org/webhooks", "webhooks", "create_org"),
    # B2 Part 18 — Analytics
    ("GET", "/v1/projects/{}/analytics/assertion-rate", "analytics", "assertion_rate"),
    ("GET", "/v1/projects/{}/analytics/deferral-rate", "analytics", "deferral_rate"),
    ("GET", "/v1/projects/{}/analytics/evaluations", "analytics", "evaluations"),
    ("GET", "/v1/projects/{}/analytics/failure-reasons", "analytics", "failure_reasons"),
    ("GET", "/v1/projects/{}/analytics/latency", "analytics", "latency"),
    # B2 Part 19 — Audit Trail
    ("GET", "/v1/org/audit-log", "audit_log", "list"),
    ("POST", "/v1/org/audit-log/export", "audit_log", "export"),
    # B2 Part 20 — Billing
    ("GET", "/v1/org/usage", "billing", "usage"),
    ("GET", "/v1/org/subscription", "billing", "subscription"),
    ("GET", "/v1/org/invoices", "billing", "invoices"),
    # Beyond B2 — Environments
    ("GET", "/v1/projects/{}/environments/{}", "environments", "get"),
    ("POST", "/v1/projects/{}/environments", "environments", "create"),
    ("PATCH", "/v1/projects/{}/environments/{}", "environments", "update"),
    ("POST", "/v1/projects/{}/environments/{}/deactivate", "environments", "deactivate"),
    ("POST", "/v1/projects/{}/environments/{}/reactivate", "environments", "reactivate"),
    # Beyond B2 — Flows
    ("POST", "/v1/projects/{}/flows", "flows", "create"),
    ("GET", "/v1/projects/{}/flows", "flows", "list"),
    ("GET", "/v1/projects/{}/flows/{}", "flows", "get"),
    ("PATCH", "/v1/projects/{}/flows/{}", "flows", "update"),
    ("DELETE", "/v1/projects/{}/flows/{}", "flows", "delete"),
    ("GET", "/v1/projects/{}/flows/{}/export", "flows", "export"),
    ("POST", "/v1/projects/{}/flows/import", "flows", "import_flow"),
    ("POST", "/v1/projects/{}/flows/from-template", "flows", "from_template"),
    ("POST", "/v1/projects/{}/flows/{}/versions", "flows", "create_version"),
    ("GET", "/v1/projects/{}/flows/{}/versions", "flows", "list_versions"),
    ("GET", "/v1/projects/{}/flows/{}/versions/{}", "flows", "get_version"),
    ("PATCH", "/v1/projects/{}/flows/{}/versions/{}", "flows", "update_version"),
    ("DELETE", "/v1/projects/{}/flows/{}/versions/{}", "flows", "delete_version"),
    ("POST", "/v1/projects/{}/flows/{}/versions/{}/approve", "flows", "approve_version"),
    ("POST", "/v1/projects/{}/flows/{}/versions/{}/deploy", "flows", "deploy"),
    ("POST", "/v1/projects/{}/flows/{}/deployments/{}/suspend", "flows", "suspend"),
    ("POST", "/v1/projects/{}/flows/{}/versions/{}/dry-run", "flows", "dry_run"),
    ("GET", "/v1/projects/{}/flows/{}/executions", "flows", "list_executions"),
    (
        "POST", "/v1/projects/{}/flows/{}/executions/{}/reconstruct",
        "flows", "reconstruct_execution",
    ),
    ("GET", "/v1/flow-templates", "flow_templates", "list"),
    ("GET", "/v1/flow-templates/{}", "flow_templates", "get"),
    # Beyond B2 — Alert Rules
    ("POST", "/v1/projects/{}/alert-rules", "alert_rules", "create"),
    ("GET", "/v1/projects/{}/alert-rules", "alert_rules", "list"),
    ("GET", "/v1/projects/{}/alert-rules/{}", "alert_rules", "get"),
    ("PUT", "/v1/projects/{}/alert-rules/{}", "alert_rules", "update"),
    ("DELETE", "/v1/projects/{}/alert-rules/{}", "alert_rules", "delete"),
    # Beyond B2 — Connectors
    ("POST", "/v1/projects/{}/connectors", "connectors", "create"),
    ("GET", "/v1/projects/{}/connectors", "connectors", "list"),
    ("GET", "/v1/projects/{}/connectors/{}", "connectors", "get"),
    ("PATCH", "/v1/projects/{}/connectors/{}", "connectors", "update"),
    ("DELETE", "/v1/projects/{}/connectors/{}", "connectors", "delete"),
    ("POST", "/v1/projects/{}/connectors/{}/test", "connectors", "test"),
    ("POST", "/v1/projects/{}/connectors/{}/gather", "connectors", "gather"),
    ("GET", "/v1/projects/{}/connectors/analytics", "connectors", "analytics"),
    ("GET", "/v1/projects/{}/connectors/{}/resources", "connectors", "resources"),
    ("GET", "/v1/projects/{}/connectors/{}/schema", "connectors", "schema"),
    ("GET", "/v1/projects/{}/connectors/{}/schedule", "connectors", "get_schedule"),
    ("PUT", "/v1/projects/{}/connectors/{}/schedule", "connectors", "set_schedule"),
    ("GET", "/v1/projects/{}/connectors/{}/gathers", "connectors", "list_gathers"),
    ("GET", "/v1/connectors/providers", "connector_providers", "list"),
    ("GET", "/v1/connectors/providers/{}/schema", "connector_providers", "schema"),
    # Beyond B2 — Named Sets
    ("POST", "/v1/projects/{}/named-sets", "named_sets", "create"),
    ("GET", "/v1/projects/{}/named-sets", "named_sets", "list"),
    ("GET", "/v1/projects/{}/named-sets/{}", "named_sets", "get"),
    ("PUT", "/v1/projects/{}/named-sets/{}", "named_sets", "update"),
    ("DELETE", "/v1/projects/{}/named-sets/{}", "named_sets", "delete"),
    ("GET", "/v1/projects/{}/named-sets/{}/usage", "named_sets", "usage"),
    # Beyond B2 — Governed Workspaces
    ("POST", "/v1/projects/{}/governed-workspaces", "governed_workspaces", "create"),
    ("GET", "/v1/projects/{}/governed-workspaces", "governed_workspaces", "list"),
    ("GET", "/v1/projects/{}/governed-workspaces/{}", "governed_workspaces", "get"),
    (
        "POST", "/v1/projects/{}/governed-workspaces/{}/versions",
        "governed_workspaces", "create_version",
    ),
    (
        "GET", "/v1/projects/{}/governed-workspaces/{}/versions/{}",
        "governed_workspaces", "get_version",
    ),
    (
        "POST",
        "/v1/projects/{}/governed-workspaces/{}/versions/{}/submit",
        "governed_workspaces", "submit",
    ),
    (
        "POST",
        "/v1/projects/{}/governed-workspaces/{}/versions/{}/approve",
        "governed_workspaces", "approve",
    ),
    (
        "POST",
        "/v1/projects/{}/governed-workspaces/{}/versions/{}/deploy",
        "governed_workspaces", "deploy",
    ),
    (
        "POST",
        "/v1/projects/{}/governed-workspaces/{}/versions/{}/archive",
        "governed_workspaces", "archive",
    ),
    (
        "POST",
        "/v1/projects/{}/governed-workspaces/{}/instances",
        "governed_workspaces", "create_instance",
    ),
    (
        "POST",
        "/v1/projects/{}/governed-workspaces/{}/instances/{}/submit",
        "governed_workspaces", "submit_instance",
    ),
    (
        "GET",
        "/v1/projects/{}/governed-workspaces/{}/instances/{}",
        "governed_workspaces", "get_instance",
    ),
    # Beyond B2 — Notifications
    ("GET", "/v1/notifications", "notifications", "list"),
    ("POST", "/v1/notifications/{}/read", "notifications", "read"),
    ("DELETE", "/v1/notifications/{}/read", "notifications", "unread"),
    # Beyond B2 — Account
    ("POST", "/v1/auth/account/delete", "account", "delete"),
    ("POST", "/v1/auth/account/delete/cancel", "account", "cancel_delete"),
    ("GET", "/v1/auth/account/deletion-status", "account", "deletion_status"),
    ("POST", "/v1/auth/account/export", "account", "export"),
    ("GET", "/v1/auth/account/export/latest", "account", "export_latest"),
    ("GET", "/v1/auth/account/export/{}", "account", "export_status"),
    ("GET", "/v1/auth/account/export/{}/download", "account", "export_download"),
    # Beyond B2 — Org Workspaces
    ("GET", "/v1/org/workspaces/{}", "workspaces", "get"),
    ("PATCH", "/v1/org/workspaces/{}", "workspaces", "update"),
    ("POST", "/v1/org/workspaces/{}/archive", "workspaces", "archive"),
    ("DELETE", "/v1/org/workspaces/{}", "workspaces", "delete"),
    ("GET", "/v1/org/workspaces/{}/members", "workspaces", "list_members"),
    ("POST", "/v1/org/workspaces/{}/members", "workspaces", "add_member"),
    ("DELETE", "/v1/org/workspaces/{}/members/{}", "workspaces", "remove_member"),
    # Beyond B2 — Users
    ("GET", "/v1/users/me", "users", "me"),
    ("GET", "/v1/users/me/organizations", "users", "organizations"),
    # Beyond B2 — Additional Org
    ("PATCH", "/v1/org", "org", "update"),
    ("GET", "/v1/org/settings", "org", "get_settings"),
    ("PUT", "/v1/org/settings", "org", "update_settings"),
    ("GET", "/v1/org/ai-policy", "org", "get_ai_policy"),
    ("PATCH", "/v1/org/ai-policy", "org", "update_ai_policy"),
    ("GET", "/v1/org/ownership-transfer", "org", "get_transfer"),
    # Beyond B2 — Additional Members
    ("POST", "/v1/org/members/{}/suspend", "members", "suspend"),
    ("POST", "/v1/org/members/{}/reactivate", "members", "reactivate"),
    ("DELETE", "/v1/org/members/invitations/{}", "members", "revoke_invitation"),
    # Beyond B2 — Additional Projects
    ("POST", "/v1/projects/{}/archive", "projects", "archive"),
    ("DELETE", "/v1/projects/{}", "projects", "delete"),
    ("GET", "/v1/projects/{}/members", "projects", "list_members"),
    ("POST", "/v1/projects/{}/members", "projects", "add_member"),
    ("DELETE", "/v1/projects/{}/members/{}", "projects", "remove_member"),
    ("PATCH", "/v1/projects/{}/members/{}", "projects", "update_member"),
    # Beyond B2 — Additional Keys
    ("GET", "/v1/projects/{}/environments/{}/keys/{}", "keys", "get"),
    ("POST", "/v1/projects/{}/environments/{}/keys/{}/disable", "keys", "disable"),
    ("POST", "/v1/projects/{}/environments/{}/keys/{}/enable", "keys", "enable"),
    # Beyond B2 — Evaluation Sharing
    ("POST", "/v1/projects/{}/evaluations/{}/share", "evaluations", "share"),
    ("GET", "/v1/shared/evaluations/{}", "evaluations", "get_shared"),
    # Beyond B2 — Audit Log Addition
    ("GET", "/v1/org/audit-log/export/{}", "audit_log", "export_status"),
]


class TestEndpointManifest:
    def test_ledger_count(self) -> None:
        assert len(ENDPOINT_LEDGER) == 180

    @pytest.mark.parametrize(
        "http_method,path_template,namespace,method_name",
        ENDPOINT_LEDGER,
        ids=[
            f"{row[2]}.{row[3]}" if row[2] else row[3]
            for row in ENDPOINT_LEDGER
        ],
    )
    def test_sync_method_exists(
        self, http_method: str, path_template: str, namespace: str, method_name: str,
    ) -> None:
        if namespace:
            getattr(VBOSClient, "__init__", None)
            client = VBOSClient.__new__(VBOSClient)
            client._api_key = "test"
            client._base_url = "https://test"
            client._max_retries = 0
            import httpx
            client._client = httpx.Client(base_url="https://test")
            try:
                sub = getattr(client, namespace, None)
                if sub is None:
                    client.__init__(api_key="test")
                    sub = getattr(client, namespace)
                assert hasattr(sub, method_name), (
                    f"VBOSClient.{namespace} missing method {method_name}"
                )
            finally:
                client._client.close()
        else:
            assert hasattr(VBOSClient, method_name), (
                f"VBOSClient missing top-level method {method_name}"
            )

    @pytest.mark.parametrize(
        "http_method,path_template,namespace,method_name",
        ENDPOINT_LEDGER,
        ids=[
            f"{row[2]}.{row[3]}" if row[2] else row[3]
            for row in ENDPOINT_LEDGER
        ],
    )
    def test_async_method_exists(
        self, http_method: str, path_template: str, namespace: str, method_name: str,
    ) -> None:
        if namespace:
            client = AsyncVBOSClient.__new__(AsyncVBOSClient)
            client._api_key = "test"
            client._base_url = "https://test"
            client._max_retries = 0
            import httpx
            client._client = httpx.AsyncClient(base_url="https://test")
            try:
                sub = getattr(client, namespace, None)
                if sub is None:
                    client.__init__(api_key="test")
                    sub = getattr(client, namespace)
                assert hasattr(sub, method_name), (
                    f"AsyncVBOSClient.{namespace} missing method {method_name}"
                )
            finally:
                import asyncio
                try:
                    asyncio.get_running_loop()
                except RuntimeError:
                    asyncio.run(client._client.aclose())
        else:
            assert hasattr(AsyncVBOSClient, method_name), (
                f"AsyncVBOSClient missing top-level method {method_name}"
            )


class TestSyncAsyncParity:
    """XC-01: inspect.signature parity across sync/async clients."""

    def _get_namespace_methods(self, client_cls: type) -> dict[str, list[str]]:
        import asyncio

        if client_cls is VBOSClient:
            client = VBOSClient(api_key="test", base_url="https://test")
        else:
            client = AsyncVBOSClient(api_key="test", base_url="https://test")

        namespaces: dict[str, list[str]] = {}
        for attr_name in dir(client):
            if attr_name.startswith("_"):
                continue
            attr = getattr(client, attr_name)
            if hasattr(attr, "_client") and hasattr(attr, "_max_retries"):
                methods = [
                    m for m in dir(attr)
                    if not m.startswith("_") and callable(getattr(attr, m))
                ]
                namespaces[attr_name] = sorted(methods)

        if client_cls is VBOSClient:
            client.close()
        else:
            asyncio.run(client.close())

        return namespaces

    def test_namespace_parity(self) -> None:
        sync_ns = self._get_namespace_methods(VBOSClient)
        async_ns = self._get_namespace_methods(AsyncVBOSClient)
        assert set(sync_ns.keys()) == set(async_ns.keys()), (
            f"Namespace mismatch: sync={set(sync_ns.keys())}, async={set(async_ns.keys())}"
        )
        for ns_name in sync_ns:
            assert sync_ns[ns_name] == async_ns[ns_name], (
                f"Method mismatch in {ns_name}: "
                f"sync={sync_ns[ns_name]}, async={async_ns[ns_name]}"
            )

    def test_toplevel_method_parity(self) -> None:
        sync_methods = {
            m for m in dir(VBOSClient)
            if not m.startswith("_") and callable(getattr(VBOSClient, m))
            and m not in ("close",)
        }
        async_methods = {
            m for m in dir(AsyncVBOSClient)
            if not m.startswith("_") and callable(getattr(AsyncVBOSClient, m))
            and m not in ("close",)
        }
        toplevel_sync = {
            m for m in sync_methods
            if not hasattr(getattr(VBOSClient, m, None), "_client")
        }
        toplevel_async = {
            m for m in async_methods
            if not hasattr(
                getattr(AsyncVBOSClient, m, None), "_client",
            )
        }
        for method_name in ("verify", "verify_batch", "validate", "certify", "replay"):
            assert method_name in toplevel_sync, f"VBOSClient missing {method_name}"
            assert method_name in toplevel_async, f"AsyncVBOSClient missing {method_name}"

    def test_signature_parity(self) -> None:
        sync_client = VBOSClient(api_key="test", base_url="https://test")
        async_client = AsyncVBOSClient(api_key="test", base_url="https://test")
        try:
            for attr_name in dir(sync_client):
                if attr_name.startswith("_"):
                    continue
                sync_attr = getattr(sync_client, attr_name)
                async_attr = getattr(async_client, attr_name, None)
                if not (hasattr(sync_attr, "_client") and hasattr(sync_attr, "_max_retries")):
                    continue
                for method_name in dir(sync_attr):
                    if method_name.startswith("_"):
                        continue
                    sync_method = getattr(sync_attr, method_name)
                    async_method = getattr(async_attr, method_name, None)
                    if not callable(sync_method):
                        continue
                    assert async_method is not None, (
                        f"AsyncVBOSClient.{attr_name} missing {method_name}"
                    )
                    sync_sig = inspect.signature(sync_method)
                    async_sig = inspect.signature(async_method)
                    assert sync_sig == async_sig, (
                        f"Signature mismatch for {attr_name}.{method_name}: "
                        f"sync={sync_sig}, async={async_sig}"
                    )
        finally:
            sync_client.close()
            import asyncio
            asyncio.run(async_client.close())
