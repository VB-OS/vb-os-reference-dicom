"""Unit tests for evaluations sub-client — replay, list, get."""

import httpx
import pytest
import respx

from tests.conftest import MOCK_API_KEY, MOCK_BASE_URL
from vbos.client import _EVALUATIONS_PATH, VBOSClient
from vbos.exceptions import VBOSAuthenticationError, VBOSNotFoundError
from vbos.models import (
    EvaluationDetailResult,
    PaginatedEvaluationResult,
    ReplayResult,
)

PROJECT_ID = "019062a1-0000-7000-0000-000000000001"
EVAL_ID = "019062a1-0000-7000-0000-000000000002"

MOCK_REPLAY_RESPONSE = {
    "replay_execution_id": "019062a1-0000-7000-0000-000000000099",
    "evaluation_id": EVAL_ID,
    "initiated_by": "019062a1-0000-7000-0000-000000000003",
    "api_key_id": None,
    "replay_type": "STANDARD",
    "decision": "ASSERT",
    "result_match": True,
    "replay_id_match": True,
    "binary_version": "1.0.3",
    "binary_sha256": "a" * 64,
    "binary_version_match": True,
    "latency_ms": 12,
    "failure_reason": None,
    "created_at": "2026-06-20T12:00:00Z",
}

MOCK_EVALUATION_LIST_ITEM = {
    "id": EVAL_ID,
    "environment_id": "019062a1-0000-7000-0000-000000000010",
    "org_id": "019062a1-0000-7000-0000-000000000020",
    "boundary_ref": "B_FIN_PAYMENT",
    "boundary_version_number": 3,
    "decision": "ASSERT",
    "replay_id": "abc123",
    "latency_ms": 42,
    "admissibility_satisfied": True,
    "failure_reason_types": None,
    "created_at": "2026-06-20T12:00:00Z",
}

MOCK_PAGINATED_RESPONSE = {
    "items": [MOCK_EVALUATION_LIST_ITEM],
    "cursor": "eyJjcmVhdGVkX2F0IjoiMjAyNi0wNi0yMFQxMjowMDowMFoiLCJpZCI6IjAxOTA2MmExIn0=",
}

MOCK_EVALUATION_RECORD = {
    "id": EVAL_ID,
    "environment_id": "019062a1-0000-7000-0000-000000000010",
    "org_id": "019062a1-0000-7000-0000-000000000020",
    "boundary_version_id": "019062a1-0000-7000-0000-000000000030",
    "boundary_ref": "B_FIN_PAYMENT",
    "boundary_version_number": 3,
    "boundary_snapshot_hash": "b" * 64,
    "decision": "ASSERT",
    "replay_id": "abc123",
    "latency_ms": 42,
    "binary_version": "1.0.3",
    "binary_sha256": "a" * 64,
    "deployment_id": "019062a1-0000-7000-0000-000000000040",
    "api_key_id": "019062a1-0000-7000-0000-000000000050",
    "created_at": "2026-06-20T12:00:00Z",
    "predicate_summary": [{"predicate_name": "amount_check", "passed": True}],
    "admissibility_satisfied": True,
    "missing_fields": None,
    "admissibility_summary": {"status": "PASS"},
    "failure_reason_types": None,
    "artifact_s3_key": "artifacts/eval/019062a1.json",
    "artifact_expires_at": "2027-06-20T12:00:00Z",
    "metadata": {},
}

MOCK_DETAIL_RESPONSE = {
    "record": MOCK_EVALUATION_RECORD,
    "artifact_available": True,
    "artifact_status": "available",
    "artifact": {"sealed": True},
}


class TestSyncEvaluationsReplay:
    @respx.mock
    def test_replay_returns_replay_result(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}/replay"
        route = respx.post(path).mock(
            return_value=httpx.Response(200, json=MOCK_REPLAY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.evaluations.replay(PROJECT_ID, EVAL_ID)

        assert isinstance(result, ReplayResult)
        assert result.decision == "ASSERT"
        assert result.result_match is True
        assert result.replay_id_match is True
        assert route.called

    @respx.mock
    def test_replay_deprecated_alias_delegates(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}/replay"
        respx.post(path).mock(
            return_value=httpx.Response(200, json=MOCK_REPLAY_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.replay(PROJECT_ID, EVAL_ID)

        assert isinstance(result, ReplayResult)
        assert result.evaluation_id == EVAL_ID

    @respx.mock
    def test_replay_401_raises_auth_error(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}/replay"
        respx.post(path).mock(
            return_value=httpx.Response(
                401, json={"error": "unauthenticated", "message": "Invalid API key"}
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSAuthenticationError):
                client.evaluations.replay(PROJECT_ID, EVAL_ID)


class TestSyncEvaluationsList:
    @respx.mock
    def test_list_returns_paginated_result(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}"
        route = respx.get(path).mock(
            return_value=httpx.Response(200, json=MOCK_PAGINATED_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.evaluations.list(PROJECT_ID)

        assert isinstance(result, PaginatedEvaluationResult)
        assert len(result.items) == 1
        assert result.items[0].decision == "ASSERT"
        assert result.cursor is not None
        assert route.called

    @respx.mock
    def test_list_with_cursor_and_limit(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}"
        route = respx.get(path).mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None})
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.evaluations.list(PROJECT_ID, limit=5, cursor="abc")

        assert isinstance(result, PaginatedEvaluationResult)
        assert len(result.items) == 0
        assert result.cursor is None
        assert route.called

    @respx.mock
    def test_list_empty_returns_empty_items(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}"
        respx.get(path).mock(
            return_value=httpx.Response(200, json={"items": [], "cursor": None})
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.evaluations.list(PROJECT_ID)

        assert result.items == []


class TestSyncEvaluationsGet:
    @respx.mock
    def test_get_returns_detail_result(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}"
        route = respx.get(path).mock(
            return_value=httpx.Response(200, json=MOCK_DETAIL_RESPONSE)
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            result = client.evaluations.get(PROJECT_ID, EVAL_ID)

        assert isinstance(result, EvaluationDetailResult)
        assert result.record.id == EVAL_ID
        assert result.artifact_available is True
        assert result.record.decision == "ASSERT"
        assert route.called

    @respx.mock
    def test_get_404_raises_not_found(self) -> None:
        path = f"{MOCK_BASE_URL}{_EVALUATIONS_PATH.format(project_id=PROJECT_ID)}/{EVAL_ID}"
        respx.get(path).mock(
            return_value=httpx.Response(
                404, json={"error": "not_found", "message": "Evaluation not found"}
            )
        )
        with VBOSClient(api_key=MOCK_API_KEY, base_url=MOCK_BASE_URL, max_retries=0) as client:
            with pytest.raises(VBOSNotFoundError):
                client.evaluations.get(PROJECT_ID, EVAL_ID)
