"""Unit tests for vbos.exceptions — exception hierarchy and raise_for_status."""

import pytest

from vbos.exceptions import (
    VBOSAuthenticationError,
    VBOSAuthorizationError,
    VBOSError,
    VBOSNotFoundError,
    VBOSRateLimitError,
    VBOSServerError,
    VBOSValidationError,
    raise_for_status,
)


class TestExceptionHierarchy:
    def test_all_exceptions_inherit_from_vbos_error(self) -> None:
        for cls in [
            VBOSAuthenticationError,
            VBOSAuthorizationError,
            VBOSNotFoundError,
            VBOSValidationError,
            VBOSRateLimitError,
            VBOSServerError,
        ]:
            assert issubclass(cls, VBOSError)

    def test_vbos_error_carries_all_fields(self) -> None:
        exc = VBOSError(
            status_code=418,
            error_code="teapot",
            message="I am a teapot",
            details={"brew": "earl_grey"},
            request_id="req-123",
        )
        assert exc.status_code == 418
        assert exc.error_code == "teapot"
        assert exc.message == "I am a teapot"
        assert exc.details == {"brew": "earl_grey"}
        assert exc.request_id == "req-123"

    def test_vbos_error_str_is_message(self) -> None:
        exc = VBOSError(
            status_code=400,
            error_code="bad",
            message="Bad request",
            request_id="req-1",
        )
        assert str(exc) == "Bad request"

    def test_vbos_error_repr_includes_key_fields(self) -> None:
        exc = VBOSError(
            status_code=400,
            error_code="bad",
            message="Bad request",
            request_id="req-1",
        )
        r = repr(exc)
        assert "400" in r
        assert "bad" in r
        assert "req-1" in r

    def test_details_defaults_to_none(self) -> None:
        exc = VBOSError(
            status_code=400,
            error_code="bad",
            message="Bad",
            request_id="req-1",
        )
        assert exc.details is None

    def test_rate_limit_error_has_retry_after(self) -> None:
        exc = VBOSRateLimitError(
            error_code="rate_limited",
            message="Slow down",
            request_id="req-1",
            retry_after=5.0,
        )
        assert exc.retry_after == 5.0
        assert exc.status_code == 429

    def test_rate_limit_error_retry_after_defaults_to_none(self) -> None:
        exc = VBOSRateLimitError(
            error_code="rate_limited",
            message="Slow down",
            request_id="req-1",
        )
        assert exc.retry_after is None


class TestRaiseForStatus:
    def test_400_raises_validation_error(self) -> None:
        with pytest.raises(VBOSValidationError) as exc_info:
            raise_for_status(400, {"error": "bad", "message": "Invalid"}, "req-1")
        assert exc_info.value.status_code == 400

    def test_401_raises_authentication_error(self) -> None:
        with pytest.raises(VBOSAuthenticationError):
            raise_for_status(401, {"error": "unauthenticated", "message": "No key"}, "req-1")

    def test_403_raises_authorization_error(self) -> None:
        with pytest.raises(VBOSAuthorizationError):
            raise_for_status(403, {"error": "forbidden", "message": "No access"}, "req-1")

    def test_404_raises_not_found_error(self) -> None:
        with pytest.raises(VBOSNotFoundError):
            raise_for_status(404, {"error": "not_found", "message": "Gone"}, "req-1")

    def test_422_raises_validation_error(self) -> None:
        with pytest.raises(VBOSValidationError) as exc_info:
            raise_for_status(422, {"error": "invalid", "message": "Bad field"}, "req-1")
        assert exc_info.value.status_code == 422

    def test_429_raises_rate_limit_error_with_retry_after(self) -> None:
        with pytest.raises(VBOSRateLimitError) as exc_info:
            raise_for_status(
                429,
                {"error": "rate_limited", "message": "Slow down"},
                "req-1",
                retry_after=10.0,
            )
        assert exc_info.value.retry_after == 10.0

    def test_500_raises_server_error(self) -> None:
        with pytest.raises(VBOSServerError):
            raise_for_status(500, {"error": "internal", "message": "Oops"}, "req-1")

    def test_502_raises_server_error(self) -> None:
        with pytest.raises(VBOSServerError):
            raise_for_status(502, {"error": "bad_gateway", "message": "Down"}, "req-1")

    def test_unknown_4xx_raises_base_error(self) -> None:
        with pytest.raises(VBOSError) as exc_info:
            raise_for_status(418, {"error": "teapot", "message": "I am a teapot"}, "req-1")
        assert type(exc_info.value) is VBOSError
        assert exc_info.value.status_code == 418

    def test_error_carries_details(self) -> None:
        with pytest.raises(VBOSError) as exc_info:
            raise_for_status(
                400,
                {"error": "bad", "message": "Bad", "details": {"field": "name"}},
                "req-1",
            )
        assert exc_info.value.details == {"field": "name"}

    def test_missing_error_fields_use_defaults(self) -> None:
        with pytest.raises(VBOSError) as exc_info:
            raise_for_status(400, {}, "req-1")
        assert exc_info.value.error_code == "unknown_error"
        assert exc_info.value.message == "Unknown error"
