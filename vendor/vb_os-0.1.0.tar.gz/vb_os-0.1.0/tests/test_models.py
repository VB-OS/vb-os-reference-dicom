"""Unit tests for vbos.models — typed Pydantic models."""

from tests.conftest import MOCK_DEFER_RESPONSE, MOCK_VERIFY_RESPONSE
from vbos.models import (
    AdmissibilityResult,
    AuditArtifactResult,
    EvaluationResult,
    FailureReason,
    PredicateResult,
    ProhibitionsResult,
)


class TestEvaluationResult:
    def test_assert_response_parses(self) -> None:
        result = EvaluationResult.model_validate(MOCK_VERIFY_RESPONSE)
        assert result.decision == "ASSERT"
        assert result.replay_id == "abc123def456"
        assert result.evaluation_id == "019062a1-4c7e-7f3a-8b2c-1a2b3c4d5e6f"
        assert result.latency_ms == 42
        assert result.project == "payment-auth"
        assert result.environment == "production"
        assert result.boundary_ref == "B_FIN_PAYMENT"
        assert result.boundary_version == 3

    def test_defer_response_parses(self) -> None:
        result = EvaluationResult.model_validate(MOCK_DEFER_RESPONSE)
        assert result.decision == "DEFER"
        assert result.admissibility.status == "FAIL"
        assert result.admissibility.missing == ["currency"]
        assert len(result.failure_reasons) == 1
        assert result.failure_reasons[0].type == "ADMISSIBILITY"

    def test_invalid_decision_rejected(self) -> None:
        import pytest

        bad = {**MOCK_VERIFY_RESPONSE, "decision": "REJECT"}
        with pytest.raises(Exception):
            EvaluationResult.model_validate(bad)

    def test_predicate_results_typed(self) -> None:
        result = EvaluationResult.model_validate(MOCK_VERIFY_RESPONSE)
        pred = result.predicate_results["amount_under_limit"]
        assert isinstance(pred, PredicateResult)
        assert pred.passed is True
        assert pred.expression == "amount <= 10000"
        assert pred.actual == 5000

    def test_audit_artifact_typed(self) -> None:
        result = EvaluationResult.model_validate(MOCK_VERIFY_RESPONSE)
        audit = result.audit_artifact
        assert isinstance(audit, AuditArtifactResult)
        assert audit.sealed is True
        assert len(audit.artifact_hash) == 64


class TestSubModels:
    def test_admissibility_result(self) -> None:
        data = {"status": "PASS", "required": ["a"], "present": ["a"], "missing": []}
        result = AdmissibilityResult.model_validate(data)
        assert result.status == "PASS"
        assert result.missing == []

    def test_prohibitions_result(self) -> None:
        data = {"status": "PASS", "prohibited": ["secret"], "detected": []}
        result = ProhibitionsResult.model_validate(data)
        assert result.prohibited == ["secret"]

    def test_failure_reason_optional_fields(self) -> None:
        data = {"type": "ADMISSIBILITY", "reason": "Missing field"}
        result = FailureReason.model_validate(data)
        assert result.type == "ADMISSIBILITY"
        assert result.field is None
        assert result.predicate is None

    def test_predicate_result_optional_actual(self) -> None:
        data = {"passed": False, "expression": "x > 0"}
        result = PredicateResult.model_validate(data)
        assert result.actual is None
