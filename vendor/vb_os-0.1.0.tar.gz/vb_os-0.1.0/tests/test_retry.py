"""Unit tests for vbos.retry — full jitter exponential backoff."""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from vbos.retry import (
    DEFAULT_BASE_DELAY,
    DEFAULT_MAX_DELAY,
    DEFAULT_MAX_RETRIES,
    async_retry,
    compute_delay,
    is_retryable_status,
    sync_retry,
)


class TestIsRetryableStatus:
    def test_5xx_is_retryable(self) -> None:
        for code in [500, 502, 503, 504, 599]:
            assert is_retryable_status(code) is True

    def test_4xx_is_not_retryable(self) -> None:
        for code in [400, 401, 403, 404, 422, 429]:
            assert is_retryable_status(code) is False

    def test_2xx_is_not_retryable(self) -> None:
        assert is_retryable_status(200) is False

    def test_429_never_retried(self) -> None:
        assert is_retryable_status(429) is False


class TestComputeDelay:
    def test_delay_within_bounds(self) -> None:
        for attempt in range(5):
            delay = compute_delay(attempt, 1.0, 30.0)
            assert 0 <= delay <= 30.0

    def test_delay_never_negative(self) -> None:
        for _ in range(100):
            delay = compute_delay(0, 1.0, 30.0)
            assert delay >= 0

    def test_delay_capped_at_max(self) -> None:
        for _ in range(100):
            delay = compute_delay(100, 1.0, 5.0)
            assert delay <= 5.0

    def test_full_jitter_is_random(self) -> None:
        delays = {compute_delay(1, 1.0, 30.0) for _ in range(20)}
        assert len(delays) > 1

    def test_defaults_exist(self) -> None:
        assert DEFAULT_MAX_RETRIES == 3
        assert DEFAULT_BASE_DELAY == 1.0
        assert DEFAULT_MAX_DELAY == 30.0


class TestSyncRetry:
    def _make_response(self, status_code: int) -> httpx.Response:
        return httpx.Response(status_code=status_code, request=httpx.Request("POST", "http://test"))

    @patch("vbos.retry.time.sleep")
    def test_returns_on_success(self, mock_sleep: MagicMock) -> None:
        send = MagicMock(return_value=self._make_response(200))
        result = sync_retry(send, MagicMock(), max_retries=3, base_delay=1.0, max_delay=30.0)
        assert result.status_code == 200
        send.assert_called_once()
        mock_sleep.assert_not_called()

    @patch("vbos.retry.time.sleep")
    def test_retries_on_500(self, mock_sleep: MagicMock) -> None:
        responses = [self._make_response(500), self._make_response(500), self._make_response(200)]
        send = MagicMock(side_effect=responses)
        result = sync_retry(send, MagicMock(), max_retries=3, base_delay=0.01, max_delay=0.1)
        assert result.status_code == 200
        assert send.call_count == 3
        assert mock_sleep.call_count == 2

    @patch("vbos.retry.time.sleep")
    def test_returns_last_5xx_after_exhaustion(self, mock_sleep: MagicMock) -> None:
        send = MagicMock(return_value=self._make_response(503))
        result = sync_retry(send, MagicMock(), max_retries=2, base_delay=0.01, max_delay=0.1)
        assert result.status_code == 503
        assert send.call_count == 3  # initial + 2 retries

    @patch("vbos.retry.time.sleep")
    def test_does_not_retry_on_4xx(self, mock_sleep: MagicMock) -> None:
        send = MagicMock(return_value=self._make_response(429))
        result = sync_retry(send, MagicMock(), max_retries=3, base_delay=0.01, max_delay=0.1)
        assert result.status_code == 429
        send.assert_called_once()

    @patch("vbos.retry.time.sleep")
    def test_retries_on_exception(self, mock_sleep: MagicMock) -> None:
        send = MagicMock(side_effect=[httpx.ConnectError("down"), self._make_response(200)])
        result = sync_retry(send, MagicMock(), max_retries=3, base_delay=0.01, max_delay=0.1)
        assert result.status_code == 200

    @patch("vbos.retry.time.sleep")
    def test_raises_after_all_retries_fail_with_exception(self, mock_sleep: MagicMock) -> None:
        send = MagicMock(side_effect=httpx.ConnectError("down"))
        with pytest.raises(httpx.ConnectError):
            sync_retry(send, MagicMock(), max_retries=2, base_delay=0.01, max_delay=0.1)
        assert send.call_count == 3


class TestAsyncRetry:
    def _make_response(self, status_code: int) -> httpx.Response:
        return httpx.Response(status_code=status_code, request=httpx.Request("POST", "http://test"))

    @pytest.mark.asyncio
    async def test_returns_on_success(self) -> None:
        send = AsyncMock(return_value=self._make_response(200))
        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await async_retry(
                send, MagicMock(), max_retries=3, base_delay=1.0, max_delay=30.0,
            )
        assert result.status_code == 200
        send.assert_called_once()

    @pytest.mark.asyncio
    async def test_retries_on_500(self) -> None:
        responses = [self._make_response(502), self._make_response(200)]
        send = AsyncMock(side_effect=responses)
        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await async_retry(
                send, MagicMock(), max_retries=3, base_delay=0.01, max_delay=0.1,
            )
        assert result.status_code == 200
        assert send.call_count == 2

    @pytest.mark.asyncio
    async def test_does_not_retry_on_429(self) -> None:
        send = AsyncMock(return_value=self._make_response(429))
        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await async_retry(
                send, MagicMock(), max_retries=3, base_delay=0.01, max_delay=0.1,
            )
        assert result.status_code == 429
        send.assert_called_once()
