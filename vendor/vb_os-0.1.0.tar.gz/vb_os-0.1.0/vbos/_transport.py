from __future__ import annotations

from typing import Any

import httpx

from vbos.exceptions import raise_for_status


def extract_request_id(response: httpx.Response) -> str:
    return response.headers.get("x-request-id", "unknown")


def parse_error_body(response: httpx.Response) -> dict[str, Any]:
    try:
        return response.json()  # type: ignore[no-any-return]
    except Exception:
        return {
            "error": "unknown_error",
            "message": response.text or "Unknown error",
        }


def extract_retry_after(response: httpx.Response) -> float | None:
    raw = response.headers.get("retry-after")
    if raw is None:
        return None
    try:
        return float(raw)
    except (ValueError, TypeError):
        return None


def handle_json_response(response: httpx.Response) -> dict[str, Any]:
    if response.status_code >= 400:
        body = parse_error_body(response)
        request_id = extract_request_id(response)
        retry_after = extract_retry_after(response)
        raise_for_status(response.status_code, body, request_id, retry_after)
    return response.json()
