from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.models import (
    EvaluationDetailResult,
    EvaluationResult,
    PaginatedEvaluationResult,
    ReplayResult,
)
from vbos.resources.account import AsyncAccount, SyncAccount
from vbos.resources.alert_rules import AsyncAlertRules, SyncAlertRules
from vbos.resources.analytics import AsyncAnalytics, SyncAnalytics
from vbos.resources.audit_log import AsyncAuditLog, SyncAuditLog
from vbos.resources.billing import AsyncBilling, SyncBilling
from vbos.resources.boundaries import AsyncBoundaries, SyncBoundaries
from vbos.resources.certification_models import (
    AsyncCertificationModels,
    SyncCertificationModels,
)
from vbos.resources.certifications import AsyncCertifications, SyncCertifications
from vbos.resources.connector_providers import (
    AsyncConnectorProviders,
    SyncConnectorProviders,
)
from vbos.resources.connectors import AsyncConnectors, SyncConnectors
from vbos.resources.deployments import AsyncDeployments, SyncDeployments
from vbos.resources.environments import AsyncEnvironments, SyncEnvironments
from vbos.resources.flow_templates import AsyncFlowTemplates, SyncFlowTemplates
from vbos.resources.flows import AsyncFlows, SyncFlows
from vbos.resources.governed_workspaces import (
    AsyncGovernedWorkspaces,
    SyncGovernedWorkspaces,
)
from vbos.resources.keys import AsyncKeys, SyncKeys
from vbos.resources.members import AsyncMembers, SyncMembers
from vbos.resources.named_sets import AsyncNamedSets, SyncNamedSets
from vbos.resources.notifications import AsyncNotifications, SyncNotifications
from vbos.resources.org import AsyncOrg, SyncOrg
from vbos.resources.projects import AsyncProjects, SyncProjects
from vbos.resources.service_accounts import AsyncServiceAccounts, SyncServiceAccounts
from vbos.resources.templates import AsyncTemplates, SyncTemplates
from vbos.resources.users import AsyncUsers, SyncUsers
from vbos.resources.webhooks import AsyncWebhooks, SyncWebhooks
from vbos.resources.workspaces import AsyncWorkspaces, SyncWorkspaces
from vbos.retry import (
    DEFAULT_BASE_DELAY,
    DEFAULT_MAX_DELAY,
    DEFAULT_MAX_RETRIES,
    async_retry,
    sync_retry,
)

_DEFAULT_BASE_URL = "https://api.vb-os.org"
_DEFAULT_TIMEOUT = 30.0
_VERIFY_PATH = "/v1/verify"
_VERIFY_BATCH_PATH = "/v1/verify/batch"
_VALIDATE_PATH = "/v1/validate"
_CERTIFY_PATH = "/v1/projects/{project_id}/certify"
_EVALUATIONS_PATH = "/v1/projects/{project_id}/evaluations"
_USER_AGENT = "vb-os-python-sdk/0.1.0"


def _build_verify_payload(
    workload: dict[str, Any],
    project: str | None,
    boundary_ref: str | None,
    metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"workload": workload}
    if project is not None:
        payload["project"] = project
    if boundary_ref is not None:
        payload["boundary_ref"] = boundary_ref
    if metadata is not None:
        payload["metadata"] = metadata
    return payload


def _handle_response(response: httpx.Response) -> EvaluationResult:
    data = handle_json_response(response)
    return EvaluationResult.model_validate(data)


class SyncEvaluations:
    """Synchronous evaluations sub-client."""

    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def replay(self, project_id: str, evaluation_id: str) -> ReplayResult:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/{evaluation_id}/replay"
        request = self._client.build_request("POST", path, json={})
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        data = handle_json_response(response)
        return ReplayResult.model_validate(data)

    def list(
        self,
        project_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> PaginatedEvaluationResult:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        path = _EVALUATIONS_PATH.format(project_id=project_id)
        request = self._client.build_request("GET", path, params=params)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        data = handle_json_response(response)
        return PaginatedEvaluationResult.model_validate(data)

    def get(self, project_id: str, evaluation_id: str) -> EvaluationDetailResult:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/{evaluation_id}"
        request = self._client.build_request("GET", path)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        data = handle_json_response(response)
        return EvaluationDetailResult.model_validate(data)

    def export(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/export"
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        request = self._client.build_request("POST", path, json=body)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def share(self, project_id: str, evaluation_id: str) -> dict[str, Any]:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/{evaluation_id}/share"
        request = self._client.build_request("POST", path, json={})
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def get_shared(self, token: str) -> dict[str, Any]:
        path = f"/v1/shared/evaluations/{token}"
        request = self._client.build_request("GET", path)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)


class AsyncEvaluations:
    """Asynchronous evaluations sub-client."""

    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def replay(self, project_id: str, evaluation_id: str) -> ReplayResult:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/{evaluation_id}/replay"
        request = self._client.build_request("POST", path, json={})
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        data = handle_json_response(response)
        return ReplayResult.model_validate(data)

    async def list(
        self,
        project_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> PaginatedEvaluationResult:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        path = _EVALUATIONS_PATH.format(project_id=project_id)
        request = self._client.build_request("GET", path, params=params)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        data = handle_json_response(response)
        return PaginatedEvaluationResult.model_validate(data)

    async def get(self, project_id: str, evaluation_id: str) -> EvaluationDetailResult:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/{evaluation_id}"
        request = self._client.build_request("GET", path)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        data = handle_json_response(response)
        return EvaluationDetailResult.model_validate(data)

    async def export(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/export"
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        request = self._client.build_request("POST", path, json=body)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def share(self, project_id: str, evaluation_id: str) -> dict[str, Any]:
        path = f"{_EVALUATIONS_PATH.format(project_id=project_id)}/{evaluation_id}/share"
        request = self._client.build_request("POST", path, json={})
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def get_shared(self, token: str) -> dict[str, Any]:
        path = f"/v1/shared/evaluations/{token}"
        request = self._client.build_request("GET", path)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)


class VBOSClient:
    """Synchronous VB-OS SDK client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": _USER_AGENT,
            },
            timeout=timeout,
        )
        self.evaluations = SyncEvaluations(self._client, self._max_retries)
        self.boundaries = SyncBoundaries(self._client, self._max_retries)
        self.deployments = SyncDeployments(self._client, self._max_retries)
        self.certifications = SyncCertifications(self._client, self._max_retries)
        self.certification_models = SyncCertificationModels(self._client, self._max_retries)
        self.projects = SyncProjects(self._client, self._max_retries)
        self.environments = SyncEnvironments(self._client, self._max_retries)
        self.templates = SyncTemplates(self._client, self._max_retries)
        self.org = SyncOrg(self._client, self._max_retries)
        self.members = SyncMembers(self._client, self._max_retries)
        self.keys = SyncKeys(self._client, self._max_retries)
        self.service_accounts = SyncServiceAccounts(self._client, self._max_retries)
        self.webhooks = SyncWebhooks(self._client, self._max_retries)
        self.analytics = SyncAnalytics(self._client, self._max_retries)
        self.audit_log = SyncAuditLog(self._client, self._max_retries)
        self.billing = SyncBilling(self._client, self._max_retries)
        self.flows = SyncFlows(self._client, self._max_retries)
        self.flow_templates = SyncFlowTemplates(self._client, self._max_retries)
        self.alert_rules = SyncAlertRules(self._client, self._max_retries)
        self.connectors = SyncConnectors(self._client, self._max_retries)
        self.connector_providers = SyncConnectorProviders(self._client, self._max_retries)
        self.named_sets = SyncNamedSets(self._client, self._max_retries)
        self.governed_workspaces = SyncGovernedWorkspaces(self._client, self._max_retries)
        self.notifications = SyncNotifications(self._client, self._max_retries)
        self.account = SyncAccount(self._client, self._max_retries)
        self.workspaces = SyncWorkspaces(self._client, self._max_retries)
        self.users = SyncUsers(self._client, self._max_retries)

    def verify(
        self,
        workload: dict[str, Any],
        project: str | None = None,
        boundary_ref: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        payload = _build_verify_payload(workload, project, boundary_ref, metadata)
        request = self._client.build_request("POST", _VERIFY_PATH, json=payload)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return _handle_response(response)

    def verify_batch(
        self,
        workloads: list[dict[str, Any]],
        project: str | None = None,
        boundary_ref: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workloads": workloads}
        if project is not None:
            payload["project"] = project
        if boundary_ref is not None:
            payload["boundary_ref"] = boundary_ref
        request = self._client.build_request("POST", _VERIFY_BATCH_PATH, json=payload)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def validate(
        self,
        workload: dict[str, Any],
        project: str | None = None,
        boundary_ref: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workload": workload}
        if project is not None:
            payload["project"] = project
        if boundary_ref is not None:
            payload["boundary_ref"] = boundary_ref
        request = self._client.build_request("POST", _VALIDATE_PATH, json=payload)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def certify(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        path = _CERTIFY_PATH.format(project_id=project_id)
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        request = self._client.build_request("POST", path, json=body)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def replay(self, project_id: str, evaluation_id: str) -> ReplayResult:
        """Deprecated: use client.evaluations.replay() instead."""
        return self.evaluations.replay(project_id, evaluation_id)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> VBOSClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncVBOSClient:
    """Asynchronous VB-OS SDK client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": _USER_AGENT,
            },
            timeout=timeout,
        )
        self.evaluations = AsyncEvaluations(self._client, self._max_retries)
        self.boundaries = AsyncBoundaries(self._client, self._max_retries)
        self.deployments = AsyncDeployments(self._client, self._max_retries)
        self.certifications = AsyncCertifications(self._client, self._max_retries)
        self.certification_models = AsyncCertificationModels(self._client, self._max_retries)
        self.projects = AsyncProjects(self._client, self._max_retries)
        self.environments = AsyncEnvironments(self._client, self._max_retries)
        self.templates = AsyncTemplates(self._client, self._max_retries)
        self.org = AsyncOrg(self._client, self._max_retries)
        self.members = AsyncMembers(self._client, self._max_retries)
        self.keys = AsyncKeys(self._client, self._max_retries)
        self.service_accounts = AsyncServiceAccounts(self._client, self._max_retries)
        self.webhooks = AsyncWebhooks(self._client, self._max_retries)
        self.analytics = AsyncAnalytics(self._client, self._max_retries)
        self.audit_log = AsyncAuditLog(self._client, self._max_retries)
        self.billing = AsyncBilling(self._client, self._max_retries)
        self.flows = AsyncFlows(self._client, self._max_retries)
        self.flow_templates = AsyncFlowTemplates(self._client, self._max_retries)
        self.alert_rules = AsyncAlertRules(self._client, self._max_retries)
        self.connectors = AsyncConnectors(self._client, self._max_retries)
        self.connector_providers = AsyncConnectorProviders(self._client, self._max_retries)
        self.named_sets = AsyncNamedSets(self._client, self._max_retries)
        self.governed_workspaces = AsyncGovernedWorkspaces(self._client, self._max_retries)
        self.notifications = AsyncNotifications(self._client, self._max_retries)
        self.account = AsyncAccount(self._client, self._max_retries)
        self.workspaces = AsyncWorkspaces(self._client, self._max_retries)
        self.users = AsyncUsers(self._client, self._max_retries)

    async def verify(
        self,
        workload: dict[str, Any],
        project: str | None = None,
        boundary_ref: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult:
        payload = _build_verify_payload(workload, project, boundary_ref, metadata)
        request = self._client.build_request("POST", _VERIFY_PATH, json=payload)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return _handle_response(response)

    async def verify_batch(
        self,
        workloads: list[dict[str, Any]],
        project: str | None = None,
        boundary_ref: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workloads": workloads}
        if project is not None:
            payload["project"] = project
        if boundary_ref is not None:
            payload["boundary_ref"] = boundary_ref
        request = self._client.build_request("POST", _VERIFY_BATCH_PATH, json=payload)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def validate(
        self,
        workload: dict[str, Any],
        project: str | None = None,
        boundary_ref: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workload": workload}
        if project is not None:
            payload["project"] = project
        if boundary_ref is not None:
            payload["boundary_ref"] = boundary_ref
        request = self._client.build_request("POST", _VALIDATE_PATH, json=payload)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def certify(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        path = _CERTIFY_PATH.format(project_id=project_id)
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        request = self._client.build_request("POST", path, json=body)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def replay(self, project_id: str, evaluation_id: str) -> ReplayResult:
        """Deprecated: use client.evaluations.replay() instead."""
        return await self.evaluations.replay(project_id, evaluation_id)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncVBOSClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
