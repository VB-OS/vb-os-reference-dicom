from __future__ import annotations


class VBOSError(Exception):
    """Base exception for all VB-OS SDK errors."""

    def __init__(
        self,
        *,
        status_code: int,
        error_code: str,
        message: str,
        details: dict[str, object] | None = None,
        request_id: str,
    ) -> None:
        self.status_code = status_code
        self.error_code = error_code
        self.message = message
        self.details = details
        self.request_id = request_id
        super().__init__(message)

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"status_code={self.status_code}, "
            f"error_code={self.error_code!r}, "
            f"message={self.message!r}, "
            f"request_id={self.request_id!r})"
        )


class VBOSAuthenticationError(VBOSError):
    """Raised on HTTP 401 — invalid or missing API key."""


class VBOSAuthorizationError(VBOSError):
    """Raised on HTTP 403 — insufficient permissions."""


class VBOSNotFoundError(VBOSError):
    """Raised on HTTP 404 — resource not found."""


class VBOSValidationError(VBOSError):
    """Raised on HTTP 400 or 422 — request validation failure."""


class VBOSRateLimitError(VBOSError):
    """Raised on HTTP 429 — rate limit exceeded. No automatic retry."""

    def __init__(
        self,
        *,
        status_code: int = 429,
        error_code: str,
        message: str,
        details: dict[str, object] | None = None,
        request_id: str,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(
            status_code=status_code,
            error_code=error_code,
            message=message,
            details=details,
            request_id=request_id,
        )
        self.retry_after = retry_after


class VBOSServerError(VBOSError):
    """Raised on HTTP 5xx after all retries are exhausted."""


_STATUS_TO_EXCEPTION: dict[int, type[VBOSError]] = {
    400: VBOSValidationError,
    401: VBOSAuthenticationError,
    403: VBOSAuthorizationError,
    404: VBOSNotFoundError,
    422: VBOSValidationError,
    429: VBOSRateLimitError,
}


def raise_for_status(
    status_code: int,
    body: dict[str, object],
    request_id: str,
    retry_after: float | None = None,
) -> None:
    error_code = str(body.get("error", "unknown_error"))
    message = str(body.get("message", "Unknown error"))
    details = body.get("details")
    if isinstance(details, dict):
        detail_dict: dict[str, object] | None = details
    else:
        detail_dict = None

    exc_cls = _STATUS_TO_EXCEPTION.get(status_code)

    if exc_cls is VBOSRateLimitError:
        raise VBOSRateLimitError(
            status_code=status_code,
            error_code=error_code,
            message=message,
            details=detail_dict,
            request_id=request_id,
            retry_after=retry_after,
        )

    if exc_cls is not None:
        raise exc_cls(
            status_code=status_code,
            error_code=error_code,
            message=message,
            details=detail_dict,
            request_id=request_id,
        )

    if status_code >= 500:
        raise VBOSServerError(
            status_code=status_code,
            error_code=error_code,
            message=message,
            details=detail_dict,
            request_id=request_id,
        )

    raise VBOSError(
        status_code=status_code,
        error_code=error_code,
        message=message,
        details=detail_dict,
        request_id=request_id,
    )
