from __future__ import annotations

import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class AdmissibilityResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    status: str
    required: list[str]
    present: list[str]
    missing: list[str]


class ProhibitionsResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    status: str
    prohibited: list[str]
    detected: list[str]


class PredicateResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    passed: bool
    expression: str
    actual: int | str | bool | None = None
    message: str | None = None


class FailureReason(BaseModel):
    model_config = ConfigDict(extra="ignore")
    type: str
    field: str | None = None
    predicate: str | None = None
    expression: str | None = None
    actual: int | str | bool | None = None
    reason: str | None = None


class AuditArtifactResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    sealed: bool
    artifact_hash: str
    boundary_snapshot_hash: str
    workload_hash: str


class ConditionalEvidenceResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    field: str
    condition_expression: str
    condition_met: bool
    evidence_present: bool
    status: str


class ConditionalProhibitionResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    field: str
    condition_expression: str
    condition_met: bool
    evidence_present: bool
    status: str


class TypeValidationResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    field: str
    expected_type: str
    actual_type: str | None = None
    valid: bool


class EvaluationResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    decision: Literal["ASSERT", "DEFER"]
    replay_id: str
    evaluation_id: str
    timestamp: datetime.datetime
    latency_ms: int
    project: str
    environment: str
    boundary_ref: str
    boundary_version: int
    deployment_id: str
    boundary_version_id: str
    admissibility: AdmissibilityResult
    prohibitions: ProhibitionsResult
    predicate_results: dict[str, PredicateResult]
    failure_reasons: list[FailureReason]
    input_hash: str | None = None
    audit_artifact: AuditArtifactResult
    binary_version: str
    binary_sha256: str
    deployment_changed: bool = False
    metadata: dict[str, object]
    evidence_schema: dict | None = None
    conditional_evidence: list[ConditionalEvidenceResult] | None = None
    conditional_prohibitions: list[ConditionalProhibitionResult] | None = None
    type_validations: list[TypeValidationResult] | None = None


class EvaluationListItem(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    environment_id: str
    org_id: str
    boundary_ref: str
    boundary_version_number: int
    decision: Literal["ASSERT", "DEFER"]
    replay_id: str
    latency_ms: int
    admissibility_satisfied: bool
    failure_reason_types: list[str] | None = None
    created_at: datetime.datetime


class PaginatedEvaluationResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[EvaluationListItem]
    cursor: str | None = None


class EvaluationRecord(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    environment_id: str
    org_id: str
    boundary_version_id: str
    boundary_ref: str
    boundary_version_number: int
    boundary_snapshot_hash: str
    decision: Literal["ASSERT", "DEFER"]
    replay_id: str
    latency_ms: int
    binary_version: str
    binary_sha256: str
    deployment_id: str
    api_key_id: str
    created_at: datetime.datetime
    predicate_summary: list[dict[str, object]]
    admissibility_satisfied: bool
    missing_fields: list[str] | None = None
    admissibility_summary: dict[str, object]
    failure_reason_types: list[str] | None = None
    artifact_s3_key: str | None = None
    artifact_expires_at: datetime.datetime | None = None
    metadata: dict[str, object] | None = None


class EvaluationDetailResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    record: EvaluationRecord
    artifact_available: bool
    artifact_status: str = "available"
    artifact: dict[str, object] | None = None


class ReplayResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    replay_execution_id: str
    evaluation_id: str
    initiated_by: str
    api_key_id: str | None = None
    replay_type: Literal["STANDARD", "CONFORMANCE_REEVALUATION"]
    decision: Literal["ASSERT", "DEFER"]
    result_match: bool
    replay_id_match: bool
    binary_version: str
    binary_sha256: str
    binary_version_match: bool
    latency_ms: int
    failure_reason: str | None = None
    created_at: datetime.datetime


# --- New models for S0043 ---


class Boundary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    boundary_ref: str
    display_name: str | None = None
    description: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class BoundaryList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Boundary]
    cursor: str | None = None


class BoundaryVersion(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    boundary_ref: str
    version_number: int
    status: str
    dsl_source: str | None = None
    snapshot_hash: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class BoundaryVersionList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[BoundaryVersion]
    cursor: str | None = None


class BoundaryDiff(BaseModel):
    model_config = ConfigDict(extra="ignore")
    boundary_ref: str
    from_version: int | None = None
    to_version: int | None = None
    diff: str | None = None
    changes: list[dict[str, object]] | None = None


class Deployment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    environment_id: str
    boundary_version_id: str
    status: str
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class DeploymentList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Deployment]
    cursor: str | None = None


class ActiveDeployment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    environment_id: str
    boundary_version_id: str
    status: str
    boundary_ref: str | None = None
    boundary_version_number: int | None = None
    created_at: datetime.datetime | None = None


class CertificationRun(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    status: str
    created_at: datetime.datetime | None = None
    completed_at: datetime.datetime | None = None
    result: dict[str, object] | None = None


class CertificationList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[CertificationRun]
    cursor: str | None = None


class CertificationReport(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    certification_run_id: str
    report: dict[str, object] | None = None
    created_at: datetime.datetime | None = None


class CertificationModel(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    name: str
    description: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class CertificationModelList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[CertificationModel]
    cursor: str | None = None


class CertificationModelVersion(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    certification_model_id: str
    version_number: int
    status: str | None = None
    created_at: datetime.datetime | None = None


class Project(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str
    name: str
    slug: str | None = None
    description: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class ProjectList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Project]
    cursor: str | None = None


class ProjectMember(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    user_id: str
    project_id: str
    role: str
    created_at: datetime.datetime | None = None


class ProjectMemberList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[ProjectMember]
    cursor: str | None = None


class Environment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    name: str
    slug: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class EnvironmentList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Environment]
    cursor: str | None = None


class Template(BaseModel):
    model_config = ConfigDict(extra="ignore")
    slug: str
    name: str
    description: str | None = None
    category: str | None = None
    created_at: datetime.datetime | None = None


class TemplateList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Template]
    cursor: str | None = None


class ForkResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    project_id: str
    boundary_ref: str | None = None
    message: str | None = None


class Organization(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    slug: str | None = None
    plan: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class OrgSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    org_id: str | None = None
    settings: dict[str, object] | None = None


class AIPolicy(BaseModel):
    model_config = ConfigDict(extra="ignore")
    org_id: str | None = None
    policy: dict[str, object] | None = None
    enabled: bool | None = None
    updated_at: datetime.datetime | None = None


class OwnershipTransfer(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str
    from_user_id: str
    to_user_id: str
    status: str
    created_at: datetime.datetime | None = None


class Member(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    user_id: str
    org_id: str
    role: str
    status: str | None = None
    email: str | None = None
    display_name: str | None = None
    created_at: datetime.datetime | None = None


class MemberList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Member]
    cursor: str | None = None


class APIKey(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str | None = None
    prefix: str | None = None
    environment_id: str | None = None
    status: str | None = None
    last_used_at: datetime.datetime | None = None
    created_at: datetime.datetime | None = None
    expires_at: datetime.datetime | None = None


class APIKeyList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[APIKey]
    cursor: str | None = None


class APIKeyCreated(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    key: str
    name: str | None = None
    prefix: str | None = None
    environment_id: str | None = None
    created_at: datetime.datetime | None = None


class ServiceAccount(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str
    name: str
    description: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class ServiceAccountList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[ServiceAccount]
    cursor: str | None = None


class Webhook(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    url: str
    events: list[str] | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class WebhookList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Webhook]
    cursor: str | None = None


class WebhookCreated(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    url: str
    secret: str
    events: list[str] | None = None
    created_at: datetime.datetime | None = None


class WebhookDelivery(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    webhook_id: str
    event_type: str | None = None
    status_code: int | None = None
    success: bool | None = None
    delivered_at: datetime.datetime | None = None


class WebhookDeliveryList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[WebhookDelivery]
    cursor: str | None = None


class AssertionRateResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    rate: float | None = None
    total: int | None = None
    asserted: int | None = None
    period: str | None = None
    time_series: list[dict[str, object]] | None = None


class DeferralRateResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    rate: float | None = None
    total: int | None = None
    deferred: int | None = None
    period: str | None = None
    time_series: list[dict[str, object]] | None = None


class EvaluationSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    total: int | None = None
    by_decision: dict[str, int] | None = None
    by_boundary: list[dict[str, object]] | None = None
    period: str | None = None
    time_series: list[dict[str, object]] | None = None


class FailureReasonResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    reasons: list[dict[str, object]] | None = None
    period: str | None = None


class LatencyResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    p50: float | None = None
    p95: float | None = None
    p99: float | None = None
    avg: float | None = None
    period: str | None = None
    time_series: list[dict[str, object]] | None = None


class AuditLogEntry(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str
    actor_id: str | None = None
    action: str
    resource_type: str | None = None
    resource_id: str | None = None
    details: dict[str, object] | None = None
    created_at: datetime.datetime | None = None


class AuditLogList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[AuditLogEntry]
    cursor: str | None = None


class AuditExportJob(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str
    status: str
    format: str | None = None
    download_url: str | None = None
    created_at: datetime.datetime | None = None
    completed_at: datetime.datetime | None = None


class UsageSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    org_id: str | None = None
    period: str | None = None
    total_evaluations: int | None = None
    by_project: list[dict[str, object]] | None = None


class Subscription(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str | None = None
    org_id: str | None = None
    plan: str | None = None
    status: str | None = None
    current_period_start: datetime.datetime | None = None
    current_period_end: datetime.datetime | None = None


class Invoice(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str | None = None
    amount: int | None = None
    currency: str | None = None
    status: str | None = None
    period_start: datetime.datetime | None = None
    period_end: datetime.datetime | None = None
    created_at: datetime.datetime | None = None


class InvoiceList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Invoice]
    cursor: str | None = None


class Flow(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    name: str
    description: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class FlowList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Flow]
    cursor: str | None = None


class FlowVersion(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    flow_id: str
    version_number: int
    status: str | None = None
    definition: dict[str, object] | None = None
    created_at: datetime.datetime | None = None


class FlowVersionList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[FlowVersion]
    cursor: str | None = None


class FlowExecution(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    flow_id: str
    flow_version_id: str | None = None
    status: str | None = None
    started_at: datetime.datetime | None = None
    completed_at: datetime.datetime | None = None
    result: dict[str, object] | None = None


class FlowExecutionList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[FlowExecution]
    cursor: str | None = None


class FlowTemplate(BaseModel):
    model_config = ConfigDict(extra="ignore")
    slug: str
    name: str
    description: str | None = None
    category: str | None = None


class FlowTemplateList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[FlowTemplate]
    cursor: str | None = None


class DryRunResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    success: bool
    errors: list[dict[str, object]] | None = None
    warnings: list[dict[str, object]] | None = None


class AlertRule(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    name: str
    condition: dict[str, object] | None = None
    actions: list[dict[str, object]] | None = None
    enabled: bool | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class AlertRuleList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[AlertRule]
    cursor: str | None = None


class Connector(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    provider: str
    name: str | None = None
    status: str | None = None
    config: dict[str, object] | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class ConnectorList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Connector]
    cursor: str | None = None


class ConnectionTestResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    success: bool
    message: str | None = None
    latency_ms: int | None = None


class GatherResult(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str | None = None
    connector_id: str | None = None
    status: str | None = None
    records_gathered: int | None = None
    started_at: datetime.datetime | None = None
    completed_at: datetime.datetime | None = None


class GatherList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[GatherResult]
    cursor: str | None = None


class ConnectorSchedule(BaseModel):
    model_config = ConfigDict(extra="ignore")
    connector_id: str | None = None
    enabled: bool | None = None
    interval: str | None = None
    next_run_at: datetime.datetime | None = None


class ConnectorProvider(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    description: str | None = None
    auth_type: str | None = None


class ConnectorProviderList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[ConnectorProvider]
    cursor: str | None = None


class NamedSet(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    name: str
    description: str | None = None
    values: list[str] | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class NamedSetList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[NamedSet]
    cursor: str | None = None


class NamedSetUsage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    named_set_id: str
    boundaries: list[str] | None = None
    usage_count: int | None = None


class GovernedWorkspace(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    project_id: str
    name: str
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class GovernedWorkspaceList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[GovernedWorkspace]
    cursor: str | None = None


class GovernedWorkspaceVersion(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    workspace_id: str
    version_number: int
    status: str | None = None
    created_at: datetime.datetime | None = None


class GovernedWorkspaceInstance(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    workspace_id: str
    status: str | None = None
    created_at: datetime.datetime | None = None
    submitted_at: datetime.datetime | None = None


class Notification(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    type: str | None = None
    title: str | None = None
    message: str | None = None
    read: bool = False
    created_at: datetime.datetime | None = None


class NotificationList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Notification]
    cursor: str | None = None


class DeletionStatus(BaseModel):
    model_config = ConfigDict(extra="ignore")
    status: str
    scheduled_at: datetime.datetime | None = None
    completed_at: datetime.datetime | None = None


class DataExport(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    status: str
    format: str | None = None
    download_url: str | None = None
    created_at: datetime.datetime | None = None
    completed_at: datetime.datetime | None = None
    expires_at: datetime.datetime | None = None


class DataExportList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[DataExport]


class Workspace(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    org_id: str
    name: str
    description: str | None = None
    status: str | None = None
    created_at: datetime.datetime | None = None
    updated_at: datetime.datetime | None = None


class WorkspaceList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[Workspace]
    cursor: str | None = None


class WorkspaceMember(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    workspace_id: str
    user_id: str
    role: str | None = None
    created_at: datetime.datetime | None = None


class WorkspaceMemberList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[WorkspaceMember]
    cursor: str | None = None


class UserProfile(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str | None = None
    display_name: str | None = None
    created_at: datetime.datetime | None = None


class UserOrganization(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    role: str | None = None


class UserOrganizationList(BaseModel):
    model_config = ConfigDict(extra="ignore")
    items: list[UserOrganization]
