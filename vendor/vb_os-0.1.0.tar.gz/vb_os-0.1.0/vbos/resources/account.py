from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_DELETE_PATH = "/v1/auth/account/delete"
_CANCEL_DELETE_PATH = "/v1/auth/account/delete/cancel"
_DELETION_STATUS_PATH = "/v1/auth/account/deletion-status"
_EXPORT_PATH = "/v1/auth/account/export"
_EXPORT_LATEST_PATH = "/v1/auth/account/export/latest"
_EXPORT_STATUS_PATH = "/v1/auth/account/export/{export_id}"
_EXPORT_DOWNLOAD_PATH = "/v1/auth/account/export/{export_id}/download"


class SyncAccount:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def delete(self) -> dict[str, Any]:
        return self._request("POST", _DELETE_PATH, json={})

    def cancel_delete(self) -> dict[str, Any]:
        return self._request("POST", _CANCEL_DELETE_PATH, json={})

    def deletion_status(self) -> dict[str, Any]:
        return self._request("GET", _DELETION_STATUS_PATH)

    def export(self) -> dict[str, Any]:
        return self._request("POST", _EXPORT_PATH, json={})

    def export_latest(self) -> dict[str, Any]:
        return self._request("GET", _EXPORT_LATEST_PATH)

    def export_status(self, export_id: str) -> dict[str, Any]:
        return self._request(
            "GET", _EXPORT_STATUS_PATH.format(export_id=export_id),
        )

    def export_download(self, export_id: str) -> dict[str, Any]:
        return self._request(
            "GET", _EXPORT_DOWNLOAD_PATH.format(export_id=export_id),
        )


class AsyncAccount:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def delete(self) -> dict[str, Any]:
        return await self._request("POST", _DELETE_PATH, json={})

    async def cancel_delete(self) -> dict[str, Any]:
        return await self._request("POST", _CANCEL_DELETE_PATH, json={})

    async def deletion_status(self) -> dict[str, Any]:
        return await self._request("GET", _DELETION_STATUS_PATH)

    async def export(self) -> dict[str, Any]:
        return await self._request("POST", _EXPORT_PATH, json={})

    async def export_latest(self) -> dict[str, Any]:
        return await self._request("GET", _EXPORT_LATEST_PATH)

    async def export_status(self, export_id: str) -> dict[str, Any]:
        return await self._request(
            "GET", _EXPORT_STATUS_PATH.format(export_id=export_id),
        )

    async def export_download(self, export_id: str) -> dict[str, Any]:
        return await self._request(
            "GET", _EXPORT_DOWNLOAD_PATH.format(export_id=export_id),
        )
