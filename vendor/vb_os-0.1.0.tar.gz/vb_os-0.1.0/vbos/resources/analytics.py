from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_ASSERTION_RATE_PATH = "/v1/projects/{project_id}/analytics/assertion-rate"
_DEFERRAL_RATE_PATH = "/v1/projects/{project_id}/analytics/deferral-rate"
_EVALUATIONS_PATH = "/v1/projects/{project_id}/analytics/evaluations"
_FAILURE_REASONS_PATH = "/v1/projects/{project_id}/analytics/failure-reasons"
_LATENCY_PATH = "/v1/projects/{project_id}/analytics/latency"


class SyncAnalytics:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def assertion_rate(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _ASSERTION_RATE_PATH.format(project_id=project_id),
            params=params,
        )

    def deferral_rate(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _DEFERRAL_RATE_PATH.format(project_id=project_id),
            params=params,
        )

    def evaluations(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _EVALUATIONS_PATH.format(project_id=project_id),
            params=params,
        )

    def failure_reasons(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _FAILURE_REASONS_PATH.format(project_id=project_id),
            params=params,
        )

    def latency(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _LATENCY_PATH.format(project_id=project_id),
            params=params,
        )


class AsyncAnalytics:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def assertion_rate(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _ASSERTION_RATE_PATH.format(project_id=project_id),
            params=params,
        )

    async def deferral_rate(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _DEFERRAL_RATE_PATH.format(project_id=project_id),
            params=params,
        )

    async def evaluations(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _EVALUATIONS_PATH.format(project_id=project_id),
            params=params,
        )

    async def failure_reasons(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _FAILURE_REASONS_PATH.format(project_id=project_id),
            params=params,
        )

    async def latency(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _LATENCY_PATH.format(project_id=project_id),
            params=params,
        )
