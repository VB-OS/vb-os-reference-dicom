from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_AUDIT_LOG_PATH = "/v1/org/audit-log"
_AUDIT_LOG_EXPORT_PATH = "/v1/org/audit-log/export"
_AUDIT_LOG_EXPORT_STATUS_PATH = "/v1/org/audit-log/export/{export_id}"


class SyncAuditLog:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        params.update({k: v for k, v in kwargs.items() if v is not None})
        return self._request("GET", _AUDIT_LOG_PATH, params=params)

    def export(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _AUDIT_LOG_EXPORT_PATH, json=body)

    def export_status(self, export_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _AUDIT_LOG_EXPORT_STATUS_PATH.format(export_id=export_id),
        )


class AsyncAuditLog:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        params.update({k: v for k, v in kwargs.items() if v is not None})
        return await self._request("GET", _AUDIT_LOG_PATH, params=params)

    async def export(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("POST", _AUDIT_LOG_EXPORT_PATH, json=body)

    async def export_status(self, export_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _AUDIT_LOG_EXPORT_STATUS_PATH.format(export_id=export_id),
        )
