from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_USAGE_PATH = "/v1/org/usage"
_SUBSCRIPTION_PATH = "/v1/org/subscription"
_INVOICES_PATH = "/v1/org/invoices"


class SyncBilling:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def usage(self, **kwargs: Any) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("GET", _USAGE_PATH, params=params)

    def subscription(self) -> dict[str, Any]:
        return self._request("GET", _SUBSCRIPTION_PATH)

    def invoices(self, **kwargs: Any) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("GET", _INVOICES_PATH, params=params)


class AsyncBilling:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def usage(self, **kwargs: Any) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("GET", _USAGE_PATH, params=params)

    async def subscription(self) -> dict[str, Any]:
        return await self._request("GET", _SUBSCRIPTION_PATH)

    async def invoices(self, **kwargs: Any) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("GET", _INVOICES_PATH, params=params)
