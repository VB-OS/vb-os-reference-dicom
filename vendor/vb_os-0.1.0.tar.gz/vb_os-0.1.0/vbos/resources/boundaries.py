from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_BOUNDARIES_PATH = "/v1/projects/{project_id}/boundaries"
_BOUNDARY_PATH = "/v1/projects/{project_id}/boundaries/{boundary_ref}"
_BOUNDARY_DRAFT_PATH = "/v1/projects/{project_id}/boundaries/{boundary_ref}/draft"
_BOUNDARY_SUBMIT_PATH = "/v1/projects/{project_id}/boundaries/{boundary_ref}/submit"
_BOUNDARY_VERSIONS_PATH = "/v1/projects/{project_id}/boundaries/{boundary_ref}/versions"
_BOUNDARY_VERSION_PATH = (
    "/v1/projects/{project_id}/boundaries/{boundary_ref}/versions/{version_id}"
)
_BOUNDARY_APPROVE_PATH = (
    "/v1/projects/{project_id}/boundaries/{boundary_ref}/versions/{version_id}/approve"
)
_BOUNDARY_REJECT_PATH = (
    "/v1/projects/{project_id}/boundaries/{boundary_ref}/versions/{version_id}/reject"
)
_BOUNDARY_DIFF_PATH = "/v1/projects/{project_id}/boundaries/{boundary_ref}/diff"


class SyncBoundaries:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET", _BOUNDARIES_PATH.format(project_id=project_id), params=params,
        )

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _BOUNDARIES_PATH.format(project_id=project_id), json=body,
        )

    def get(self, project_id: str, boundary_ref: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _BOUNDARY_PATH.format(project_id=project_id, boundary_ref=boundary_ref),
        )

    def update_draft(
        self, project_id: str, boundary_ref: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _BOUNDARY_DRAFT_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            json=body,
        )

    def submit(self, project_id: str, boundary_ref: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _BOUNDARY_SUBMIT_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            json={},
        )

    def versions(
        self,
        project_id: str,
        boundary_ref: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _BOUNDARY_VERSIONS_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            params=params,
        )

    def get_version(
        self, project_id: str, boundary_ref: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _BOUNDARY_VERSION_PATH.format(
                project_id=project_id,
                boundary_ref=boundary_ref,
                version_id=version_id,
            ),
        )

    def approve(
        self, project_id: str, boundary_ref: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _BOUNDARY_APPROVE_PATH.format(
                project_id=project_id,
                boundary_ref=boundary_ref,
                version_id=version_id,
            ),
            json={},
        )

    def reject(
        self, project_id: str, boundary_ref: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _BOUNDARY_REJECT_PATH.format(
                project_id=project_id,
                boundary_ref=boundary_ref,
                version_id=version_id,
            ),
            json={},
        )

    def diff(
        self, project_id: str, boundary_ref: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _BOUNDARY_DIFF_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            params=params,
        )


class AsyncBoundaries:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET", _BOUNDARIES_PATH.format(project_id=project_id), params=params,
        )

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _BOUNDARIES_PATH.format(project_id=project_id), json=body,
        )

    async def get(self, project_id: str, boundary_ref: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _BOUNDARY_PATH.format(project_id=project_id, boundary_ref=boundary_ref),
        )

    async def update_draft(
        self, project_id: str, boundary_ref: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _BOUNDARY_DRAFT_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            json=body,
        )

    async def submit(self, project_id: str, boundary_ref: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _BOUNDARY_SUBMIT_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            json={},
        )

    async def versions(
        self,
        project_id: str,
        boundary_ref: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _BOUNDARY_VERSIONS_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            params=params,
        )

    async def get_version(
        self, project_id: str, boundary_ref: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _BOUNDARY_VERSION_PATH.format(
                project_id=project_id,
                boundary_ref=boundary_ref,
                version_id=version_id,
            ),
        )

    async def approve(
        self, project_id: str, boundary_ref: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _BOUNDARY_APPROVE_PATH.format(
                project_id=project_id,
                boundary_ref=boundary_ref,
                version_id=version_id,
            ),
            json={},
        )

    async def reject(
        self, project_id: str, boundary_ref: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _BOUNDARY_REJECT_PATH.format(
                project_id=project_id,
                boundary_ref=boundary_ref,
                version_id=version_id,
            ),
            json={},
        )

    async def diff(
        self, project_id: str, boundary_ref: str, **kwargs: Any,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _BOUNDARY_DIFF_PATH.format(
                project_id=project_id, boundary_ref=boundary_ref,
            ),
            params=params,
        )
