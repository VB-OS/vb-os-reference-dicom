from __future__ import annotations

import asyncio
import time
from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.exceptions import VBOSError
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_CERTIFICATIONS_PATH = "/v1/projects/{project_id}/certifications"
_CERTIFICATION_PATH = "/v1/projects/{project_id}/certifications/{run_id}"
_CERTIFICATION_REPORT_PATH = (
    "/v1/projects/{project_id}/certifications/{run_id}/report"
)

_TERMINAL_STATUSES = frozenset({"COMPLETED", "FAILED", "CANCELLED"})


class SyncCertifications:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _CERTIFICATIONS_PATH.format(project_id=project_id),
            params=params,
        )

    def get(self, project_id: str, run_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _CERTIFICATION_PATH.format(project_id=project_id, run_id=run_id),
        )

    def get_report(self, project_id: str, run_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _CERTIFICATION_REPORT_PATH.format(
                project_id=project_id, run_id=run_id,
            ),
        )

    def wait(
        self,
        project_id: str,
        run_id: str,
        *,
        poll_interval_seconds: float = 2.0,
        max_attempts: int = 150,
    ) -> dict[str, Any]:
        for _ in range(max_attempts):
            result = self.get(project_id, run_id)
            if result.get("status") in _TERMINAL_STATUSES:
                return result
            time.sleep(poll_interval_seconds)
        raise VBOSError(
            status_code=0,
            error_code="max_attempts_exceeded",
            message=(
                f"Certification run {run_id} did not reach a terminal status "
                f"after max attempts ({max_attempts})"
            ),
            request_id="local",
        )


class AsyncCertifications:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _CERTIFICATIONS_PATH.format(project_id=project_id),
            params=params,
        )

    async def get(self, project_id: str, run_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _CERTIFICATION_PATH.format(project_id=project_id, run_id=run_id),
        )

    async def get_report(self, project_id: str, run_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _CERTIFICATION_REPORT_PATH.format(
                project_id=project_id, run_id=run_id,
            ),
        )

    async def wait(
        self,
        project_id: str,
        run_id: str,
        *,
        poll_interval_seconds: float = 2.0,
        max_attempts: int = 150,
    ) -> dict[str, Any]:
        for _ in range(max_attempts):
            result = await self.get(project_id, run_id)
            if result.get("status") in _TERMINAL_STATUSES:
                return result
            await asyncio.sleep(poll_interval_seconds)
        raise VBOSError(
            status_code=0,
            error_code="max_attempts_exceeded",
            message=(
                f"Certification run {run_id} did not reach a terminal status "
                f"after max attempts ({max_attempts})"
            ),
            request_id="local",
        )
