from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_PROVIDERS_PATH = "/v1/connectors/providers"
_PROVIDER_SCHEMA_PATH = "/v1/connectors/providers/{provider_id}/schema"


class SyncConnectorProviders:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _PROVIDERS_PATH, params=params)

    def schema(self, provider_id: str) -> dict[str, Any]:
        return self._request(
            "GET", _PROVIDER_SCHEMA_PATH.format(provider_id=provider_id),
        )


class AsyncConnectorProviders:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _PROVIDERS_PATH, params=params)

    async def schema(self, provider_id: str) -> dict[str, Any]:
        return await self._request(
            "GET", _PROVIDER_SCHEMA_PATH.format(provider_id=provider_id),
        )
