from __future__ import annotations

import time
from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.exceptions import VBOSNotFoundError, VBOSServerError
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_TERMINAL_STATUSES = frozenset({
    "COMPLETED", "DECLINED", "FAILED", "EXPIRED", "SUPERSEDED",
})

_CONNECTORS_PATH = "/v1/projects/{project_id}/connectors"
_CONNECTOR_PATH = "/v1/projects/{project_id}/connectors/{connector_id}"
_CONNECTOR_TEST_PATH = "/v1/projects/{project_id}/connectors/{connector_id}/test"
_CONNECTOR_GATHER_PATH = "/v1/projects/{project_id}/connectors/{connector_id}/gather"
_CONNECTORS_ANALYTICS_PATH = "/v1/projects/{project_id}/connectors/analytics"
_CONNECTOR_RESOURCES_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/resources"
)
_CONNECTOR_SCHEMA_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/schema"
)
_CONNECTOR_SCHEDULE_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/schedule"
)
_CONNECTOR_GATHERS_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/gathers"
)
_CONNECTOR_OAUTH_AUTHORIZE_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/oauth/authorize"
)
_CONNECTOR_OAUTH_DISCONNECT_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/oauth/disconnect"
)
_CONNECTOR_OAUTH_RECONNECT_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/oauth/reconnect"
)
_CONNECTOR_OAUTH_STATUS_PATH = (
    "/v1/projects/{project_id}/connectors/{connector_id}/oauth/status"
)
_OAUTH_AUTHORIZATION_STATUS_PATH = (
    "/v1/connectors/oauth/authorizations/{authorization_id}/status"
)


class SyncConnectors:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _CONNECTORS_PATH.format(project_id=project_id),
            json=body,
        )

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _CONNECTORS_PATH.format(project_id=project_id),
            params=params,
        )

    def get(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _CONNECTOR_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    def update(
        self, project_id: str, connector_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _CONNECTOR_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json=body,
        )

    def delete(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _CONNECTOR_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    def test(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _CONNECTOR_TEST_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={},
        )

    def gather(
        self, project_id: str, connector_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _CONNECTOR_GATHER_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json=body,
        )

    def analytics(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "GET",
            _CONNECTORS_ANALYTICS_PATH.format(project_id=project_id),
            params=params,
        )

    def resources(
        self,
        project_id: str,
        connector_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _CONNECTOR_RESOURCES_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            params=params,
        )

    def schema(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _CONNECTOR_SCHEMA_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    def get_schedule(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _CONNECTOR_SCHEDULE_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    def set_schedule(
        self, project_id: str, connector_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PUT",
            _CONNECTOR_SCHEDULE_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json=body,
        )

    def list_gathers(
        self,
        project_id: str,
        connector_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _CONNECTOR_GATHERS_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            params=params,
        )

    def authorize(
        self,
        project_id: str,
        connector_id: str,
        *,
        mode: str = "REMOTE",
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _CONNECTOR_OAUTH_AUTHORIZE_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={"mode": mode},
        )

    def disconnect(
        self, project_id: str, connector_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _CONNECTOR_OAUTH_DISCONNECT_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={},
        )

    def reconnect(
        self,
        project_id: str,
        connector_id: str,
        *,
        mode: str = "REMOTE",
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _CONNECTOR_OAUTH_RECONNECT_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={"mode": mode},
        )

    def oauth_status(
        self, project_id: str, connector_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _CONNECTOR_OAUTH_STATUS_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    def wait_for_authorization(
        self,
        authorization_id: str,
        *,
        timeout: int = 600,
        poll_interval: int = 3,
    ) -> dict[str, Any]:
        path = _OAUTH_AUTHORIZATION_STATUS_PATH.format(
            authorization_id=authorization_id,
        )
        deadline = time.monotonic() + timeout
        max_transient_retries = 5
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return {"status": "TIMEOUT"}
            transient_retries = 0
            while True:
                try:
                    result = self._request("GET", path)
                    break
                except VBOSNotFoundError:
                    return {"status": "NOT_FOUND"}
                except VBOSServerError:
                    transient_retries += 1
                    if transient_retries > max_transient_retries:
                        raise
                    time.sleep(min(poll_interval * (2 ** (transient_retries - 1)), 30))
                    continue
            status = result.get("status", "")
            if status in _TERMINAL_STATUSES:
                return result
            time.sleep(min(poll_interval, max(0, deadline - time.monotonic())))


class AsyncConnectors:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _CONNECTORS_PATH.format(project_id=project_id),
            json=body,
        )

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _CONNECTORS_PATH.format(project_id=project_id),
            params=params,
        )

    async def get(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _CONNECTOR_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    async def update(
        self, project_id: str, connector_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _CONNECTOR_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json=body,
        )

    async def delete(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _CONNECTOR_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    async def test(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _CONNECTOR_TEST_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={},
        )

    async def gather(
        self, project_id: str, connector_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _CONNECTOR_GATHER_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json=body,
        )

    async def analytics(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "GET",
            _CONNECTORS_ANALYTICS_PATH.format(project_id=project_id),
            params=params,
        )

    async def resources(
        self,
        project_id: str,
        connector_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _CONNECTOR_RESOURCES_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            params=params,
        )

    async def schema(self, project_id: str, connector_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _CONNECTOR_SCHEMA_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    async def get_schedule(
        self, project_id: str, connector_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _CONNECTOR_SCHEDULE_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    async def set_schedule(
        self, project_id: str, connector_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PUT",
            _CONNECTOR_SCHEDULE_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json=body,
        )

    async def list_gathers(
        self,
        project_id: str,
        connector_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _CONNECTOR_GATHERS_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            params=params,
        )

    async def authorize(
        self,
        project_id: str,
        connector_id: str,
        *,
        mode: str = "REMOTE",
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _CONNECTOR_OAUTH_AUTHORIZE_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={"mode": mode},
        )

    async def disconnect(
        self, project_id: str, connector_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _CONNECTOR_OAUTH_DISCONNECT_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={},
        )

    async def reconnect(
        self,
        project_id: str,
        connector_id: str,
        *,
        mode: str = "REMOTE",
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _CONNECTOR_OAUTH_RECONNECT_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
            json={"mode": mode},
        )

    async def oauth_status(
        self, project_id: str, connector_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _CONNECTOR_OAUTH_STATUS_PATH.format(
                project_id=project_id, connector_id=connector_id,
            ),
        )

    async def wait_for_authorization(
        self,
        authorization_id: str,
        *,
        timeout: int = 600,
        poll_interval: int = 3,
    ) -> dict[str, Any]:
        import asyncio

        path = _OAUTH_AUTHORIZATION_STATUS_PATH.format(
            authorization_id=authorization_id,
        )
        deadline = time.monotonic() + timeout
        max_transient_retries = 5
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return {"status": "TIMEOUT"}
            transient_retries = 0
            while True:
                try:
                    result = await self._request("GET", path)
                    break
                except VBOSNotFoundError:
                    return {"status": "NOT_FOUND"}
                except VBOSServerError:
                    transient_retries += 1
                    if transient_retries > max_transient_retries:
                        raise
                    await asyncio.sleep(
                        min(poll_interval * (2 ** (transient_retries - 1)), 30),
                    )
                    continue
            status = result.get("status", "")
            if status in _TERMINAL_STATUSES:
                return result
            await asyncio.sleep(
                min(poll_interval, max(0, deadline - time.monotonic())),
            )
