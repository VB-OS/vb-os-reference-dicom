from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_DEPLOYMENTS_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/deployments"
)
_DEPLOYMENT_ACTIVE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/deployments/active"
)
_DEPLOYMENT_APPROVE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}"
    "/deployments/{deployment_id}/approve"
)
_DEPLOYMENT_REJECT_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}"
    "/deployments/{deployment_id}/reject"
)
_PROMOTE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/promote"
)
_ROLLBACK_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/rollback"
)


class SyncDeployments:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self,
        project_id: str,
        environment_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _DEPLOYMENTS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            params=params,
        )

    def create(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _DEPLOYMENTS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    def active(
        self, project_id: str, environment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _DEPLOYMENT_ACTIVE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
        )

    def approve(
        self, project_id: str, environment_id: str, deployment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _DEPLOYMENT_APPROVE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                deployment_id=deployment_id,
            ),
            json={},
        )

    def reject(
        self, project_id: str, environment_id: str, deployment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _DEPLOYMENT_REJECT_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                deployment_id=deployment_id,
            ),
            json={},
        )

    def promote(
        self,
        project_id: str,
        environment_id: str,
        *,
        source_environment: str,
        boundary_version_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "source_environment": source_environment,
            "boundary_version_id": boundary_version_id,
        }
        body.update({k: v for k, v in kwargs.items() if v is not None})
        return self._request(
            "POST",
            _PROMOTE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    def rollback(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _ROLLBACK_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )


class AsyncDeployments:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self,
        project_id: str,
        environment_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _DEPLOYMENTS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            params=params,
        )

    async def create(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _DEPLOYMENTS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    async def active(
        self, project_id: str, environment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _DEPLOYMENT_ACTIVE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
        )

    async def approve(
        self, project_id: str, environment_id: str, deployment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _DEPLOYMENT_APPROVE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                deployment_id=deployment_id,
            ),
            json={},
        )

    async def reject(
        self, project_id: str, environment_id: str, deployment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _DEPLOYMENT_REJECT_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                deployment_id=deployment_id,
            ),
            json={},
        )

    async def promote(
        self,
        project_id: str,
        environment_id: str,
        *,
        source_environment: str,
        boundary_version_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "source_environment": source_environment,
            "boundary_version_id": boundary_version_id,
        }
        body.update({k: v for k, v in kwargs.items() if v is not None})
        return await self._request(
            "POST",
            _PROMOTE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    async def rollback(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _ROLLBACK_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )
