from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_ENVIRONMENTS_PATH = "/v1/projects/{project_id}/environments"
_ENVIRONMENT_PATH = "/v1/projects/{project_id}/environments/{environment_id}"
_ENVIRONMENT_DEACTIVATE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/deactivate"
)
_ENVIRONMENT_REACTIVATE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/reactivate"
)


class SyncEnvironments:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _ENVIRONMENTS_PATH.format(project_id=project_id),
            params=params,
        )

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _ENVIRONMENTS_PATH.format(project_id=project_id),
            json=body,
        )

    def get(self, project_id: str, environment_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _ENVIRONMENT_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
        )

    def update(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _ENVIRONMENT_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    def deactivate(
        self, project_id: str, environment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _ENVIRONMENT_DEACTIVATE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json={},
        )

    def reactivate(
        self, project_id: str, environment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _ENVIRONMENT_REACTIVATE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json={},
        )


class AsyncEnvironments:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _ENVIRONMENTS_PATH.format(project_id=project_id),
            params=params,
        )

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _ENVIRONMENTS_PATH.format(project_id=project_id),
            json=body,
        )

    async def get(self, project_id: str, environment_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _ENVIRONMENT_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
        )

    async def update(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _ENVIRONMENT_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    async def deactivate(
        self, project_id: str, environment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _ENVIRONMENT_DEACTIVATE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json={},
        )

    async def reactivate(
        self, project_id: str, environment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _ENVIRONMENT_REACTIVATE_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json={},
        )
