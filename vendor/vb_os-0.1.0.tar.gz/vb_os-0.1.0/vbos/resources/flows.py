from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_FLOWS_PATH = "/v1/projects/{project_id}/flows"
_FLOW_PATH = "/v1/projects/{project_id}/flows/{flow_id}"
_FLOW_EXPORT_PATH = "/v1/projects/{project_id}/flows/{flow_id}/export"
_FLOW_IMPORT_PATH = "/v1/projects/{project_id}/flows/import"
_FLOW_FROM_TEMPLATE_PATH = "/v1/projects/{project_id}/flows/from-template"
_FLOW_VERSIONS_PATH = "/v1/projects/{project_id}/flows/{flow_id}/versions"
_FLOW_VERSION_PATH = (
    "/v1/projects/{project_id}/flows/{flow_id}/versions/{version_id}"
)
_FLOW_VERSION_APPROVE_PATH = (
    "/v1/projects/{project_id}/flows/{flow_id}/versions/{version_id}/approve"
)
_FLOW_VERSION_DEPLOY_PATH = (
    "/v1/projects/{project_id}/flows/{flow_id}/versions/{version_id}/deploy"
)
_FLOW_DEPLOYMENT_SUSPEND_PATH = (
    "/v1/projects/{project_id}/flows/{flow_id}/deployments/{deployment_id}/suspend"
)
_FLOW_VERSION_DRY_RUN_PATH = (
    "/v1/projects/{project_id}/flows/{flow_id}/versions/{version_id}/dry-run"
)
_FLOW_EXECUTIONS_PATH = "/v1/projects/{project_id}/flows/{flow_id}/executions"
_FLOW_EXECUTION_RECONSTRUCT_PATH = (
    "/v1/projects/{project_id}/flows/{flow_id}/executions/{execution_id}/reconstruct"
)


class SyncFlows:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _FLOWS_PATH.format(project_id=project_id), json=body,
        )

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET", _FLOWS_PATH.format(project_id=project_id), params=params,
        )

    def get(self, project_id: str, flow_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _FLOW_PATH.format(project_id=project_id, flow_id=flow_id),
        )

    def update(
        self, project_id: str, flow_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _FLOW_PATH.format(project_id=project_id, flow_id=flow_id),
            json=body,
        )

    def delete(self, project_id: str, flow_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _FLOW_PATH.format(project_id=project_id, flow_id=flow_id),
        )

    def export(self, project_id: str, flow_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _FLOW_EXPORT_PATH.format(project_id=project_id, flow_id=flow_id),
        )

    def import_flow(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _FLOW_IMPORT_PATH.format(project_id=project_id), json=body,
        )

    def from_template(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _FLOW_FROM_TEMPLATE_PATH.format(project_id=project_id),
            json=body,
        )

    def create_version(
        self, project_id: str, flow_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _FLOW_VERSIONS_PATH.format(project_id=project_id, flow_id=flow_id),
            json=body,
        )

    def list_versions(
        self,
        project_id: str,
        flow_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _FLOW_VERSIONS_PATH.format(project_id=project_id, flow_id=flow_id),
            params=params,
        )

    def get_version(
        self, project_id: str, flow_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _FLOW_VERSION_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
        )

    def update_version(
        self, project_id: str, flow_id: str, version_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _FLOW_VERSION_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json=body,
        )

    def delete_version(
        self, project_id: str, flow_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _FLOW_VERSION_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
        )

    def approve_version(
        self, project_id: str, flow_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _FLOW_VERSION_APPROVE_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json={},
        )

    def deploy(
        self, project_id: str, flow_id: str, version_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _FLOW_VERSION_DEPLOY_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json=body,
        )

    def suspend(
        self, project_id: str, flow_id: str, deployment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _FLOW_DEPLOYMENT_SUSPEND_PATH.format(
                project_id=project_id,
                flow_id=flow_id,
                deployment_id=deployment_id,
            ),
            json={},
        )

    def dry_run(
        self, project_id: str, flow_id: str, version_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _FLOW_VERSION_DRY_RUN_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json=body,
        )

    def list_executions(
        self,
        project_id: str,
        flow_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _FLOW_EXECUTIONS_PATH.format(
                project_id=project_id, flow_id=flow_id,
            ),
            params=params,
        )

    def reconstruct_execution(
        self, project_id: str, flow_id: str, execution_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _FLOW_EXECUTION_RECONSTRUCT_PATH.format(
                project_id=project_id,
                flow_id=flow_id,
                execution_id=execution_id,
            ),
            json={},
        )


class AsyncFlows:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _FLOWS_PATH.format(project_id=project_id), json=body,
        )

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET", _FLOWS_PATH.format(project_id=project_id), params=params,
        )

    async def get(self, project_id: str, flow_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _FLOW_PATH.format(project_id=project_id, flow_id=flow_id),
        )

    async def update(
        self, project_id: str, flow_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _FLOW_PATH.format(project_id=project_id, flow_id=flow_id),
            json=body,
        )

    async def delete(self, project_id: str, flow_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _FLOW_PATH.format(project_id=project_id, flow_id=flow_id),
        )

    async def export(self, project_id: str, flow_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _FLOW_EXPORT_PATH.format(project_id=project_id, flow_id=flow_id),
        )

    async def import_flow(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _FLOW_IMPORT_PATH.format(project_id=project_id), json=body,
        )

    async def from_template(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _FLOW_FROM_TEMPLATE_PATH.format(project_id=project_id),
            json=body,
        )

    async def create_version(
        self, project_id: str, flow_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _FLOW_VERSIONS_PATH.format(project_id=project_id, flow_id=flow_id),
            json=body,
        )

    async def list_versions(
        self,
        project_id: str,
        flow_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _FLOW_VERSIONS_PATH.format(project_id=project_id, flow_id=flow_id),
            params=params,
        )

    async def get_version(
        self, project_id: str, flow_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _FLOW_VERSION_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
        )

    async def update_version(
        self, project_id: str, flow_id: str, version_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _FLOW_VERSION_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json=body,
        )

    async def delete_version(
        self, project_id: str, flow_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _FLOW_VERSION_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
        )

    async def approve_version(
        self, project_id: str, flow_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _FLOW_VERSION_APPROVE_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json={},
        )

    async def deploy(
        self, project_id: str, flow_id: str, version_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _FLOW_VERSION_DEPLOY_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json=body,
        )

    async def suspend(
        self, project_id: str, flow_id: str, deployment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _FLOW_DEPLOYMENT_SUSPEND_PATH.format(
                project_id=project_id,
                flow_id=flow_id,
                deployment_id=deployment_id,
            ),
            json={},
        )

    async def dry_run(
        self, project_id: str, flow_id: str, version_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _FLOW_VERSION_DRY_RUN_PATH.format(
                project_id=project_id, flow_id=flow_id, version_id=version_id,
            ),
            json=body,
        )

    async def list_executions(
        self,
        project_id: str,
        flow_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _FLOW_EXECUTIONS_PATH.format(
                project_id=project_id, flow_id=flow_id,
            ),
            params=params,
        )

    async def reconstruct_execution(
        self, project_id: str, flow_id: str, execution_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _FLOW_EXECUTION_RECONSTRUCT_PATH.format(
                project_id=project_id,
                flow_id=flow_id,
                execution_id=execution_id,
            ),
            json={},
        )
