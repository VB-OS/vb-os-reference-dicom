from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_WORKSPACES_PATH = "/v1/projects/{project_id}/governed-workspaces"
_WORKSPACE_PATH = "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
_VERSIONS_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}/versions"
)
_VERSION_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/versions/{version_id}"
)
_VERSION_SUBMIT_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/versions/{version_id}/submit"
)
_VERSION_APPROVE_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/versions/{version_id}/approve"
)
_VERSION_DEPLOY_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/versions/{version_id}/deploy"
)
_VERSION_ARCHIVE_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/versions/{version_id}/archive"
)
_INSTANCES_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}/instances"
)
_INSTANCE_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/instances/{instance_id}"
)
_INSTANCE_SUBMIT_PATH = (
    "/v1/projects/{project_id}/governed-workspaces/{workspace_id}"
    "/instances/{instance_id}/submit"
)


class SyncGovernedWorkspaces:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _WORKSPACES_PATH.format(project_id=project_id), json=body,
        )

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET", _WORKSPACES_PATH.format(project_id=project_id), params=params,
        )

    def get(self, project_id: str, workspace_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _WORKSPACE_PATH.format(
                project_id=project_id, workspace_id=workspace_id,
            ),
        )

    def create_version(
        self, project_id: str, workspace_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _VERSIONS_PATH.format(
                project_id=project_id, workspace_id=workspace_id,
            ),
            json=body,
        )

    def get_version(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _VERSION_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
        )

    def submit(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _VERSION_SUBMIT_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    def approve(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _VERSION_APPROVE_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    def deploy(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _VERSION_DEPLOY_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    def archive(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _VERSION_ARCHIVE_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    def create_instance(
        self, project_id: str, workspace_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _INSTANCES_PATH.format(
                project_id=project_id, workspace_id=workspace_id,
            ),
            json=body,
        )

    def submit_instance(
        self, project_id: str, workspace_id: str, instance_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _INSTANCE_SUBMIT_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                instance_id=instance_id,
            ),
            json={},
        )

    def get_instance(
        self, project_id: str, workspace_id: str, instance_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _INSTANCE_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                instance_id=instance_id,
            ),
        )


class AsyncGovernedWorkspaces:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _WORKSPACES_PATH.format(project_id=project_id), json=body,
        )

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET", _WORKSPACES_PATH.format(project_id=project_id), params=params,
        )

    async def get(self, project_id: str, workspace_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _WORKSPACE_PATH.format(
                project_id=project_id, workspace_id=workspace_id,
            ),
        )

    async def create_version(
        self, project_id: str, workspace_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _VERSIONS_PATH.format(
                project_id=project_id, workspace_id=workspace_id,
            ),
            json=body,
        )

    async def get_version(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _VERSION_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
        )

    async def submit(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _VERSION_SUBMIT_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    async def approve(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _VERSION_APPROVE_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    async def deploy(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _VERSION_DEPLOY_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    async def archive(
        self, project_id: str, workspace_id: str, version_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _VERSION_ARCHIVE_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                version_id=version_id,
            ),
            json={},
        )

    async def create_instance(
        self, project_id: str, workspace_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _INSTANCES_PATH.format(
                project_id=project_id, workspace_id=workspace_id,
            ),
            json=body,
        )

    async def submit_instance(
        self, project_id: str, workspace_id: str, instance_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _INSTANCE_SUBMIT_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                instance_id=instance_id,
            ),
            json={},
        )

    async def get_instance(
        self, project_id: str, workspace_id: str, instance_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _INSTANCE_PATH.format(
                project_id=project_id,
                workspace_id=workspace_id,
                instance_id=instance_id,
            ),
        )
