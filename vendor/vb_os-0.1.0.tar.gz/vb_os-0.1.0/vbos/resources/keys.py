from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_KEYS_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/keys"
)
_KEY_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}/keys/{key_id}"
)
_KEY_ROTATE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}"
    "/keys/{key_id}/rotate"
)
_KEY_REVOKE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}"
    "/keys/{key_id}/revoke"
)
_KEY_DISABLE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}"
    "/keys/{key_id}/disable"
)
_KEY_ENABLE_PATH = (
    "/v1/projects/{project_id}/environments/{environment_id}"
    "/keys/{key_id}/enable"
)


class SyncKeys:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self,
        project_id: str,
        environment_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _KEYS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            params=params,
        )

    def create(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _KEYS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    def get(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            _KEY_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
        )

    def rotate(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _KEY_ROTATE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )

    def revoke(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _KEY_REVOKE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )

    def disable(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _KEY_DISABLE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )

    def enable(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            _KEY_ENABLE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )


class AsyncKeys:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self,
        project_id: str,
        environment_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _KEYS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            params=params,
        )

    async def create(
        self, project_id: str, environment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _KEYS_PATH.format(
                project_id=project_id, environment_id=environment_id,
            ),
            json=body,
        )

    async def get(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "GET",
            _KEY_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
        )

    async def rotate(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _KEY_ROTATE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )

    async def revoke(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _KEY_REVOKE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )

    async def disable(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _KEY_DISABLE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )

    async def enable(
        self, project_id: str, environment_id: str, key_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _KEY_ENABLE_PATH.format(
                project_id=project_id,
                environment_id=environment_id,
                key_id=key_id,
            ),
            json={},
        )
