from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_MEMBERS_PATH = "/v1/org/members"
_MEMBER_ROLE_PATH = "/v1/org/members/{user_id}/role"
_MEMBER_PATH = "/v1/org/members/{user_id}"
_MEMBER_SUSPEND_PATH = "/v1/org/members/{user_id}/suspend"
_MEMBER_REACTIVATE_PATH = "/v1/org/members/{user_id}/reactivate"
_MEMBER_INVITATION_PATH = "/v1/org/members/invitations/{user_id}"


class SyncMembers:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _MEMBERS_PATH, params=params)

    def invite(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _MEMBERS_PATH, json=body)

    def set_role(self, user_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _MEMBER_ROLE_PATH.format(user_id=user_id),
            json=body,
        )

    def remove(self, user_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE", _MEMBER_PATH.format(user_id=user_id),
        )

    def suspend(self, user_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _MEMBER_SUSPEND_PATH.format(user_id=user_id),
            json={},
        )

    def reactivate(self, user_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _MEMBER_REACTIVATE_PATH.format(user_id=user_id),
            json={},
        )

    def revoke_invitation(self, user_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _MEMBER_INVITATION_PATH.format(user_id=user_id),
        )


class AsyncMembers:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _MEMBERS_PATH, params=params)

    async def invite(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("POST", _MEMBERS_PATH, json=body)

    async def set_role(self, user_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _MEMBER_ROLE_PATH.format(user_id=user_id),
            json=body,
        )

    async def remove(self, user_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE", _MEMBER_PATH.format(user_id=user_id),
        )

    async def suspend(self, user_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _MEMBER_SUSPEND_PATH.format(user_id=user_id),
            json={},
        )

    async def reactivate(self, user_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _MEMBER_REACTIVATE_PATH.format(user_id=user_id),
            json={},
        )

    async def revoke_invitation(self, user_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _MEMBER_INVITATION_PATH.format(user_id=user_id),
        )
