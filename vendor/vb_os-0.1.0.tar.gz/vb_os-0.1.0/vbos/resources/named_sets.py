from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_NAMED_SETS_PATH = "/v1/projects/{project_id}/named-sets"
_NAMED_SET_PATH = "/v1/projects/{project_id}/named-sets/{named_set_id}"
_NAMED_SET_USAGE_PATH = "/v1/projects/{project_id}/named-sets/{named_set_id}/usage"


class SyncNamedSets:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _NAMED_SETS_PATH.format(project_id=project_id), json=body,
        )

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET", _NAMED_SETS_PATH.format(project_id=project_id), params=params,
        )

    def get(self, project_id: str, named_set_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _NAMED_SET_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
        )

    def update(
        self, project_id: str, named_set_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PUT",
            _NAMED_SET_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
            json=body,
        )

    def delete(self, project_id: str, named_set_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _NAMED_SET_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
        )

    def usage(self, project_id: str, named_set_id: str) -> dict[str, Any]:
        return self._request(
            "GET",
            _NAMED_SET_USAGE_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
        )


class AsyncNamedSets:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _NAMED_SETS_PATH.format(project_id=project_id), json=body,
        )

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET", _NAMED_SETS_PATH.format(project_id=project_id), params=params,
        )

    async def get(self, project_id: str, named_set_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _NAMED_SET_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
        )

    async def update(
        self, project_id: str, named_set_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PUT",
            _NAMED_SET_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
            json=body,
        )

    async def delete(self, project_id: str, named_set_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _NAMED_SET_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
        )

    async def usage(self, project_id: str, named_set_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            _NAMED_SET_USAGE_PATH.format(
                project_id=project_id, named_set_id=named_set_id,
            ),
        )
