from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_ORG_PATH = "/v1/org"
_ORG_SETTINGS_PATH = "/v1/org/settings"
_ORG_AI_POLICY_PATH = "/v1/org/ai-policy"
_ORG_OWNERSHIP_TRANSFER_PATH = "/v1/org/ownership-transfer"
_ORG_TRANSFER_ACCEPT_PATH = (
    "/v1/org/ownership-transfer/{transfer_id}/accept"
)
_ORG_TRANSFER_CANCEL_PATH = (
    "/v1/org/ownership-transfer/{transfer_id}/cancel"
)


class SyncOrg:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def get(self) -> dict[str, Any]:
        return self._request("GET", _ORG_PATH)

    def update(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("PATCH", _ORG_PATH, json=body)

    def get_settings(self) -> dict[str, Any]:
        return self._request("GET", _ORG_SETTINGS_PATH)

    def update_settings(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("PUT", _ORG_SETTINGS_PATH, json=body)

    def get_ai_policy(self) -> dict[str, Any]:
        return self._request("GET", _ORG_AI_POLICY_PATH)

    def update_ai_policy(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("PATCH", _ORG_AI_POLICY_PATH, json=body)

    def transfer_ownership(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _ORG_OWNERSHIP_TRANSFER_PATH, json=body)

    def accept_transfer(self, transfer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _ORG_TRANSFER_ACCEPT_PATH.format(transfer_id=transfer_id),
            json={},
        )

    def cancel_transfer(self, transfer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _ORG_TRANSFER_CANCEL_PATH.format(transfer_id=transfer_id),
            json={},
        )

    def get_transfer(self) -> dict[str, Any]:
        return self._request("GET", _ORG_OWNERSHIP_TRANSFER_PATH)


class AsyncOrg:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def get(self) -> dict[str, Any]:
        return await self._request("GET", _ORG_PATH)

    async def update(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("PATCH", _ORG_PATH, json=body)

    async def get_settings(self) -> dict[str, Any]:
        return await self._request("GET", _ORG_SETTINGS_PATH)

    async def update_settings(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("PUT", _ORG_SETTINGS_PATH, json=body)

    async def get_ai_policy(self) -> dict[str, Any]:
        return await self._request("GET", _ORG_AI_POLICY_PATH)

    async def update_ai_policy(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("PATCH", _ORG_AI_POLICY_PATH, json=body)

    async def transfer_ownership(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _ORG_OWNERSHIP_TRANSFER_PATH, json=body,
        )

    async def accept_transfer(self, transfer_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _ORG_TRANSFER_ACCEPT_PATH.format(transfer_id=transfer_id),
            json={},
        )

    async def cancel_transfer(self, transfer_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _ORG_TRANSFER_CANCEL_PATH.format(transfer_id=transfer_id),
            json={},
        )

    async def get_transfer(self) -> dict[str, Any]:
        return await self._request("GET", _ORG_OWNERSHIP_TRANSFER_PATH)
