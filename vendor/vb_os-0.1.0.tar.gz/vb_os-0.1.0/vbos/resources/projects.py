from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_PROJECTS_PATH = "/v1/projects"
_PROJECT_PATH = "/v1/projects/{project_id}"
_PROJECT_ARCHIVE_PATH = "/v1/projects/{project_id}/archive"
_PROJECT_MEMBERS_PATH = "/v1/projects/{project_id}/members"
_PROJECT_MEMBER_PATH = "/v1/projects/{project_id}/members/{assignment_id}"


class SyncProjects:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _PROJECTS_PATH, params=params)

    def create(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _PROJECTS_PATH, json=body)

    def get(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "GET", _PROJECT_PATH.format(project_id=project_id),
        )

    def update(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH", _PROJECT_PATH.format(project_id=project_id), json=body,
        )

    def archive(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _PROJECT_ARCHIVE_PATH.format(project_id=project_id),
            json={},
        )

    def delete(self, project_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE", _PROJECT_PATH.format(project_id=project_id),
        )

    def list_members(
        self,
        project_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _PROJECT_MEMBERS_PATH.format(project_id=project_id),
            params=params,
        )

    def add_member(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST",
            _PROJECT_MEMBERS_PATH.format(project_id=project_id),
            json=body,
        )

    def remove_member(
        self, project_id: str, assignment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _PROJECT_MEMBER_PATH.format(
                project_id=project_id, assignment_id=assignment_id,
            ),
        )

    def update_member(
        self, project_id: str, assignment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _PROJECT_MEMBER_PATH.format(
                project_id=project_id, assignment_id=assignment_id,
            ),
            json=body,
        )


class AsyncProjects:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _PROJECTS_PATH, params=params)

    async def create(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("POST", _PROJECTS_PATH, json=body)

    async def get(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "GET", _PROJECT_PATH.format(project_id=project_id),
        )

    async def update(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH", _PROJECT_PATH.format(project_id=project_id), json=body,
        )

    async def archive(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _PROJECT_ARCHIVE_PATH.format(project_id=project_id),
            json={},
        )

    async def delete(self, project_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE", _PROJECT_PATH.format(project_id=project_id),
        )

    async def list_members(
        self,
        project_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _PROJECT_MEMBERS_PATH.format(project_id=project_id),
            params=params,
        )

    async def add_member(
        self, project_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST",
            _PROJECT_MEMBERS_PATH.format(project_id=project_id),
            json=body,
        )

    async def remove_member(
        self, project_id: str, assignment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _PROJECT_MEMBER_PATH.format(
                project_id=project_id, assignment_id=assignment_id,
            ),
        )

    async def update_member(
        self, project_id: str, assignment_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _PROJECT_MEMBER_PATH.format(
                project_id=project_id, assignment_id=assignment_id,
            ),
            json=body,
        )
