from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_SERVICE_ACCOUNTS_PATH = "/v1/org/service-accounts"
_SERVICE_ACCOUNT_PATH = "/v1/org/service-accounts/{account_id}"
_SERVICE_ACCOUNT_DISABLE_PATH = "/v1/org/service-accounts/{account_id}/disable"
_SERVICE_ACCOUNT_ENABLE_PATH = "/v1/org/service-accounts/{account_id}/enable"


class SyncServiceAccounts:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _SERVICE_ACCOUNTS_PATH, params=params)

    def create(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _SERVICE_ACCOUNTS_PATH, json=body)

    def update(self, account_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _SERVICE_ACCOUNT_PATH.format(account_id=account_id),
            json=body,
        )

    def disable(self, account_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _SERVICE_ACCOUNT_DISABLE_PATH.format(account_id=account_id),
            json={},
        )

    def enable(self, account_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _SERVICE_ACCOUNT_ENABLE_PATH.format(account_id=account_id),
            json={},
        )


class AsyncServiceAccounts:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _SERVICE_ACCOUNTS_PATH, params=params)

    async def create(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("POST", _SERVICE_ACCOUNTS_PATH, json=body)

    async def update(self, account_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _SERVICE_ACCOUNT_PATH.format(account_id=account_id),
            json=body,
        )

    async def disable(self, account_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _SERVICE_ACCOUNT_DISABLE_PATH.format(account_id=account_id),
            json={},
        )

    async def enable(self, account_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _SERVICE_ACCOUNT_ENABLE_PATH.format(account_id=account_id),
            json={},
        )
