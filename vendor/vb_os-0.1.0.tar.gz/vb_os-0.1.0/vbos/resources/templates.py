from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_TEMPLATES_PATH = "/v1/templates"
_TEMPLATE_PATH = "/v1/templates/{slug}"
_TEMPLATE_FORK_PATH = "/v1/templates/{slug}/fork"


class SyncTemplates:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _TEMPLATES_PATH, params=params)

    def get(self, slug: str) -> dict[str, Any]:
        return self._request(
            "GET", _TEMPLATE_PATH.format(slug=slug),
        )

    def fork(self, slug: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _TEMPLATE_FORK_PATH.format(slug=slug), json=body,
        )


class AsyncTemplates:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _TEMPLATES_PATH, params=params)

    async def get(self, slug: str) -> dict[str, Any]:
        return await self._request(
            "GET", _TEMPLATE_PATH.format(slug=slug),
        )

    async def fork(self, slug: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _TEMPLATE_FORK_PATH.format(slug=slug), json=body,
        )
