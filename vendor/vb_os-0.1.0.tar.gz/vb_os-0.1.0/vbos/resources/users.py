from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_ME_PATH = "/v1/users/me"
_ORGANIZATIONS_PATH = "/v1/users/me/organizations"


class SyncUsers:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def me(self) -> dict[str, Any]:
        return self._request("GET", _ME_PATH)

    def organizations(self) -> dict[str, Any]:
        return self._request("GET", _ORGANIZATIONS_PATH)


class AsyncUsers:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def me(self) -> dict[str, Any]:
        return await self._request("GET", _ME_PATH)

    async def organizations(self) -> dict[str, Any]:
        return await self._request("GET", _ORGANIZATIONS_PATH)
