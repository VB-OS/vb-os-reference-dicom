from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_WEBHOOKS_PATH = "/v1/projects/{project_id}/webhooks"
_WEBHOOK_PATH = "/v1/projects/{project_id}/webhooks/{webhook_id}"
_WEBHOOK_ROTATE_SECRET_PATH = (
    "/v1/projects/{project_id}/webhooks/{webhook_id}/rotate-secret"
)
_WEBHOOK_DELIVERIES_PATH = (
    "/v1/projects/{project_id}/webhooks/{webhook_id}/deliveries"
)
_ORG_WEBHOOKS_PATH = "/v1/org/webhooks"


class SyncWebhooks:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET", _WEBHOOKS_PATH.format(project_id=project_id), params=params,
        )

    def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _WEBHOOKS_PATH.format(project_id=project_id), json=body,
        )

    def update(
        self, project_id: str, webhook_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH",
            _WEBHOOK_PATH.format(project_id=project_id, webhook_id=webhook_id),
            json=body,
        )

    def delete(self, project_id: str, webhook_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _WEBHOOK_PATH.format(project_id=project_id, webhook_id=webhook_id),
        )

    def rotate_secret(self, project_id: str, webhook_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _WEBHOOK_ROTATE_SECRET_PATH.format(
                project_id=project_id, webhook_id=webhook_id,
            ),
            json={},
        )

    def deliveries(
        self,
        project_id: str,
        webhook_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _WEBHOOK_DELIVERIES_PATH.format(
                project_id=project_id, webhook_id=webhook_id,
            ),
            params=params,
        )

    def list_org(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _ORG_WEBHOOKS_PATH, params=params)

    def create_org(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _ORG_WEBHOOKS_PATH, json=body)


class AsyncWebhooks:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, project_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET", _WEBHOOKS_PATH.format(project_id=project_id), params=params,
        )

    async def create(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _WEBHOOKS_PATH.format(project_id=project_id), json=body,
        )

    async def update(
        self, project_id: str, webhook_id: str, **kwargs: Any,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH",
            _WEBHOOK_PATH.format(project_id=project_id, webhook_id=webhook_id),
            json=body,
        )

    async def delete(self, project_id: str, webhook_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _WEBHOOK_PATH.format(project_id=project_id, webhook_id=webhook_id),
        )

    async def rotate_secret(
        self, project_id: str, webhook_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            _WEBHOOK_ROTATE_SECRET_PATH.format(
                project_id=project_id, webhook_id=webhook_id,
            ),
            json={},
        )

    async def deliveries(
        self,
        project_id: str,
        webhook_id: str,
        *,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _WEBHOOK_DELIVERIES_PATH.format(
                project_id=project_id, webhook_id=webhook_id,
            ),
            params=params,
        )

    async def list_org(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _ORG_WEBHOOKS_PATH, params=params)

    async def create_org(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("POST", _ORG_WEBHOOKS_PATH, json=body)
