from __future__ import annotations

from typing import Any

import httpx

from vbos._transport import handle_json_response
from vbos.retry import DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY, async_retry, sync_retry

_WORKSPACES_PATH = "/v1/org/workspaces"
_WORKSPACE_PATH = "/v1/org/workspaces/{workspace_id}"
_WORKSPACE_ARCHIVE_PATH = "/v1/org/workspaces/{workspace_id}/archive"
_MEMBERS_PATH = "/v1/org/workspaces/{workspace_id}/members"
_MEMBER_PATH = "/v1/org/workspaces/{workspace_id}/members/{assignment_id}"


class SyncWorkspaces:
    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = sync_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request("GET", _WORKSPACES_PATH, params=params)

    def create(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request("POST", _WORKSPACES_PATH, json=body)

    def get(self, workspace_id: str) -> dict[str, Any]:
        return self._request(
            "GET", _WORKSPACE_PATH.format(workspace_id=workspace_id),
        )

    def update(self, workspace_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "PATCH", _WORKSPACE_PATH.format(workspace_id=workspace_id), json=body,
        )

    def archive(self, workspace_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            _WORKSPACE_ARCHIVE_PATH.format(workspace_id=workspace_id),
            json={},
        )

    def delete(self, workspace_id: str) -> dict[str, Any]:
        return self._request(
            "DELETE", _WORKSPACE_PATH.format(workspace_id=workspace_id),
        )

    def list_members(
        self, workspace_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._request(
            "GET",
            _MEMBERS_PATH.format(workspace_id=workspace_id),
            params=params,
        )

    def add_member(self, workspace_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return self._request(
            "POST", _MEMBERS_PATH.format(workspace_id=workspace_id), json=body,
        )

    def remove_member(
        self, workspace_id: str, assignment_id: str,
    ) -> dict[str, Any]:
        return self._request(
            "DELETE",
            _MEMBER_PATH.format(
                workspace_id=workspace_id, assignment_id=assignment_id,
            ),
        )


class AsyncWorkspaces:
    def __init__(self, client: httpx.AsyncClient, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        request = self._client.build_request(method, path, **kwargs)
        response = await async_retry(
            self._client.send, request,
            max_retries=self._max_retries,
            base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY,
        )
        return handle_json_response(response)

    async def list(
        self, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request("GET", _WORKSPACES_PATH, params=params)

    async def create(self, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("POST", _WORKSPACES_PATH, json=body)

    async def get(self, workspace_id: str) -> dict[str, Any]:
        return await self._request(
            "GET", _WORKSPACE_PATH.format(workspace_id=workspace_id),
        )

    async def update(self, workspace_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "PATCH", _WORKSPACE_PATH.format(workspace_id=workspace_id), json=body,
        )

    async def archive(self, workspace_id: str) -> dict[str, Any]:
        return await self._request(
            "POST",
            _WORKSPACE_ARCHIVE_PATH.format(workspace_id=workspace_id),
            json={},
        )

    async def delete(self, workspace_id: str) -> dict[str, Any]:
        return await self._request(
            "DELETE", _WORKSPACE_PATH.format(workspace_id=workspace_id),
        )

    async def list_members(
        self, workspace_id: str, *, limit: int = 20, cursor: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._request(
            "GET",
            _MEMBERS_PATH.format(workspace_id=workspace_id),
            params=params,
        )

    async def add_member(self, workspace_id: str, **kwargs: Any) -> dict[str, Any]:
        body: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request(
            "POST", _MEMBERS_PATH.format(workspace_id=workspace_id), json=body,
        )

    async def remove_member(
        self, workspace_id: str, assignment_id: str,
    ) -> dict[str, Any]:
        return await self._request(
            "DELETE",
            _MEMBER_PATH.format(
                workspace_id=workspace_id, assignment_id=assignment_id,
            ),
        )
