from __future__ import annotations

import random
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import httpx

_RETRYABLE_STATUS_CODES = frozenset(range(500, 600))

DEFAULT_MAX_RETRIES = 3
DEFAULT_BASE_DELAY = 1.0
DEFAULT_MAX_DELAY = 30.0


def is_retryable_status(status_code: int) -> bool:
    return status_code in _RETRYABLE_STATUS_CODES


def compute_delay(attempt: int, base_delay: float, max_delay: float) -> float:
    """Full jitter: delay = uniform(0, base_delay * 2^attempt), capped at max_delay."""
    ceiling = min(base_delay * (2 ** attempt), max_delay)
    return random.uniform(0, ceiling)  # noqa: S311


def sync_retry(
    send: callable,  # type: ignore[type-arg]
    request: httpx.Request,
    *,
    max_retries: int,
    base_delay: float,
    max_delay: float,
) -> httpx.Response:
    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            response = send(request)
            if not is_retryable_status(response.status_code) or attempt == max_retries:
                return response
        except Exception as exc:
            last_exc = exc
            if attempt == max_retries:
                raise
        delay = compute_delay(attempt, base_delay, max_delay)
        time.sleep(delay)
    raise last_exc  # type: ignore[misc]


async def async_retry(
    send: callable,  # type: ignore[type-arg]
    request: httpx.Request,
    *,
    max_retries: int,
    base_delay: float,
    max_delay: float,
) -> httpx.Response:
    import asyncio

    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            response = await send(request)
            if not is_retryable_status(response.status_code) or attempt == max_retries:
                return response
        except Exception as exc:
            last_exc = exc
            if attempt == max_retries:
                raise
        delay = compute_delay(attempt, base_delay, max_delay)
        await asyncio.sleep(delay)
    raise last_exc  # type: ignore[misc]
