"""VB-OS CLI — Command-line interface for the VB-OS Verification Cloud Platform."""

__version__ = "0.1.0"
