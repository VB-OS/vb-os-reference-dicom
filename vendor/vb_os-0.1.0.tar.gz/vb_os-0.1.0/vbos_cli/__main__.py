"""Support ``python -m vbos_cli``."""

from vbos_cli.cli import main

main()
