"""Main CLI group with global flags (REQ-A1-148, REQ-A1-149, REQ-A1-151)."""

from __future__ import annotations

import json
import sys
from enum import Enum

import click
import httpx

from vbos_cli import __version__
from vbos_cli.errors import CLIError, UnsupportedInLocalModeError
from vbos_cli.output import print_error, print_json
from vbos_cli.profiles import resolve_profile


class ExecutionMode(Enum):
    CLOUD = "cloud"
    LOCAL = "local"


class CloudOnlyCommand(click.Command):
    """Command that rejects --local mode before execution."""

    def invoke(self, ctx: click.Context) -> None:
        mode = ctx.find_root().obj.get("mode", ExecutionMode.CLOUD)
        if mode == ExecutionMode.LOCAL:
            click.echo(
                json.dumps(
                    {
                        "error": "unsupported_in_local_mode",
                        "message": (
                            "Authentication commands require --cloud mode. "
                            "Local SRB execution does not use VB-OS Cloud credentials."
                        ),
                    }
                ),
            )
            ctx.exit(2)
            return
        return super().invoke(ctx)


class CLIGroup(click.Group):
    """Group that catches CLIError and converts to structured exit."""

    def invoke(self, ctx: click.Context) -> None:
        try:
            return super().invoke(ctx)
        except CLIError as e:
            click.echo(
                json.dumps({"error": "cli_error", "message": str(e)}),
                err=True,
            )
            ctx.exit(e.exit_code)
        except httpx.ConnectError:
            from vbos_cli import config as cfg

            profile = ctx.params.get("profile") or "default"
            api_url = cfg.get_api_url(profile)
            click.echo(
                json.dumps(
                    {
                        "error": "connection_error",
                        "message": (
                            f"Cannot connect to VB-OS API at {api_url}. "
                            "Check your network connection or run "
                            "`vbos config set api-url <url>` to update the API endpoint."
                        ),
                    }
                ),
                err=True,
            )
            ctx.exit(2)
        except httpx.TimeoutException:
            click.echo(
                json.dumps(
                    {
                        "error": "timeout_error",
                        "message": "Request to VB-OS API timed out. Try again later.",
                    }
                ),
                err=True,
            )
            ctx.exit(2)


@click.group(cls=CLIGroup)
@click.version_option(__version__, prog_name="vbos")
@click.option("--profile", default=None, help="Named profile to use.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "table"]),
    default="json",
    help="Output format (default: json).",
)
@click.option("--cloud", "mode_cloud", is_flag=True, default=False, help="Cloud mode (default).")
@click.option("--local", "mode_local", is_flag=True, default=False, help="Local execution mode.")
@click.pass_context
def cli(
    ctx: click.Context,
    profile: str | None,
    output_format: str,
    mode_cloud: bool,
    mode_local: bool,
) -> None:
    """VB-OS CLI — Verification Cloud Platform command-line interface."""
    if mode_cloud and mode_local:
        raise click.UsageError("--cloud and --local are mutually exclusive.")
    ctx.ensure_object(dict)
    ctx.obj["profile"] = resolve_profile(profile)
    ctx.obj["format"] = output_format
    ctx.obj["mode"] = ExecutionMode.LOCAL if mode_local else ExecutionMode.CLOUD


def _register_commands() -> None:
    from vbos_cli.commands.account import account
    from vbos_cli.commands.alert_rules import alert_rules
    from vbos_cli.commands.analytics import analytics
    from vbos_cli.commands.audit_log import audit_log
    from vbos_cli.commands.auth import login, logout, resend_verification
    from vbos_cli.commands.boundaries import boundaries
    from vbos_cli.commands.certify import certification_models, certifications, certify
    from vbos_cli.commands.completions import completions
    from vbos_cli.commands.config_cmd import config
    from vbos_cli.commands.connectors import connectors
    from vbos_cli.commands.deployments import deployments
    from vbos_cli.commands.environments import environments
    from vbos_cli.commands.evaluations import evaluations
    from vbos_cli.commands.flows import flows
    from vbos_cli.commands.governed_workspaces import governed_workspaces
    from vbos_cli.commands.keys import keys
    from vbos_cli.commands.members import members
    from vbos_cli.commands.named_sets import named_sets
    from vbos_cli.commands.notifications import notifications
    from vbos_cli.commands.org import switch_org
    from vbos_cli.commands.org_mgmt import org
    from vbos_cli.commands.projects import projects
    from vbos_cli.commands.replay import replay
    from vbos_cli.commands.templates import templates
    from vbos_cli.commands.verify import verify
    from vbos_cli.commands.webhooks import webhooks
    from vbos_cli.commands.workspaces import workspaces

    cli.add_command(login)
    cli.add_command(logout)
    cli.add_command(resend_verification)
    cli.add_command(switch_org)
    cli.add_command(config)
    cli.add_command(completions)

    cli.add_command(verify)
    cli.add_command(replay)
    cli.add_command(evaluations)
    cli.add_command(boundaries)
    cli.add_command(projects)
    cli.add_command(environments)
    cli.add_command(keys)
    cli.add_command(connectors)
    cli.add_command(webhooks)
    cli.add_command(flows)
    cli.add_command(alert_rules)
    cli.add_command(deployments)
    cli.add_command(templates)
    cli.add_command(named_sets)
    cli.add_command(org)
    cli.add_command(members)
    cli.add_command(workspaces)
    cli.add_command(audit_log)
    cli.add_command(certify)
    cli.add_command(certifications)
    cli.add_command(certification_models)
    cli.add_command(analytics)
    cli.add_command(governed_workspaces)
    cli.add_command(notifications)
    cli.add_command(account)


_register_commands()


def main() -> None:
    try:
        rv = cli(standalone_mode=False)
        if isinstance(rv, int) and rv != 0:
            sys.exit(rv)
    except CLIError as e:
        if isinstance(e, UnsupportedInLocalModeError):
            print_json(
                {"error": "unsupported_in_local_mode", "message": str(e)},
                file=sys.stderr,
            )
        else:
            print_error("cli_error", str(e))
        sys.exit(e.exit_code)
    except httpx.ConnectError:
        from vbos_cli import config as cfg

        api_url = cfg.get_api_url("default")
        print_error(
            "connection_error",
            f"Cannot connect to VB-OS API at {api_url}. "
            "Check your network connection or run "
            "`vbos config set api-url <url>` to update the API endpoint.",
        )
        sys.exit(2)
    except httpx.TimeoutException:
        print_error("timeout_error", "Request to VB-OS API timed out. Try again later.")
        sys.exit(2)
    except click.exceptions.Exit as e:
        sys.exit(e.code)
    except click.exceptions.Abort:
        sys.exit(130)
    except click.exceptions.UsageError as e:
        print_error("usage_error", str(e))
        sys.exit(2)
