"""HTTP client with auth injection, pre-request refresh, and method-aware retry."""

from __future__ import annotations

import base64
import json
import time
from typing import Any

import httpx

from vbos_cli import __version__
from vbos_cli.credentials.store import (
    APIKeyCredential,
    Credential,
    CredentialStore,
    SessionCredential,
    resolve_credential,
)
from vbos_cli.errors import (
    APIKeyInvalidError,
    AuthenticationError,
    CLIError,
    CredentialStoreError,
    SessionExpiredError,
)

REFRESH_LEEWAY_SECONDS = 30
MAX_GET_RETRIES = 3
USER_AGENT = f"vbos-cli/{__version__}"


def _jwt_exp(token: str) -> int | None:
    """Non-authoritative local decode of JWT exp claim."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload = parts[1]
        padding = 4 - len(payload) % 4
        if padding != 4:
            payload += "=" * padding
        decoded = json.loads(base64.urlsafe_b64decode(payload))
        exp = decoded.get("exp")
        return int(exp) if exp is not None else None
    except Exception:
        return None


def _is_expired(token: str) -> bool:
    """Check if JWT access token is expired (with leeway). Malformed = expired."""
    exp = _jwt_exp(token)
    if exp is None:
        return True
    return time.time() >= (exp - REFRESH_LEEWAY_SECONDS)


class AuthenticatedClient:
    """HTTP client that injects auth and handles pre-request refresh."""

    def __init__(
        self,
        base_url: str,
        profile: str = "default",
        credential: Credential | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._profile = profile
        self._credential = credential
        self._store = CredentialStore(profile)
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={"User-Agent": USER_AGENT},
            timeout=30.0,
        )

    def close(self) -> None:
        self._http.close()

    def _get_credential(self) -> Credential | None:
        if self._credential is not None:
            return self._credential
        return resolve_credential(self._profile)

    def _refresh_session(self, cred: SessionCredential) -> SessionCredential:
        """Attempt silent token refresh. Returns new credential or raises."""
        resp = self._http.post(
            "/v1/auth/refresh",
            headers={"Authorization": f"Bearer {cred.refresh_token}"},
        )

        if resp.status_code == 401:
            try:
                self._store.delete()
            except Exception:
                pass
            raise SessionExpiredError

        if resp.status_code != 200:
            raise AuthenticationError(f"Token refresh failed: {resp.status_code}")

        data = resp.json()
        new_cred = SessionCredential(
            kind="session",
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )

        try:
            self._store.store(new_cred)
        except Exception:
            try:
                self._store.delete()
            except Exception:
                raise CredentialStoreError(
                    "Failed to persist refreshed credentials and could not clean up. "
                    "Run `vbos login` to re-authenticate."
                ) from None
            raise CredentialStoreError(
                "Failed to persist refreshed credentials. Local session cleared. "
                "Run `vbos login` to re-authenticate."
            ) from None

        self._credential = new_cred
        return new_cred

    def _ensure_auth(self) -> dict[str, str]:
        """Return authorization headers, refreshing if needed."""
        cred = self._get_credential()
        if cred is None:
            raise AuthenticationError("Not authenticated. Run `vbos login`.")

        if isinstance(cred, APIKeyCredential):
            return {"Authorization": f"Bearer {cred.api_key}"}

        if _is_expired(cred.access_token):
            cred = self._refresh_session(cred)

        return {"Authorization": f"Bearer {cred.access_token}"}

    def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        auth: bool = True,
    ) -> httpx.Response:
        """Make an authenticated API request with method-aware retry."""
        req_headers = dict(headers or {})
        if auth:
            req_headers.update(self._ensure_auth())

        is_safe = method.upper() in ("GET", "HEAD")

        for attempt in range(MAX_GET_RETRIES if is_safe else 1):
            resp = self._http.request(
                method,
                path,
                json=json,
                params=params,
                headers=req_headers,
            )

            if resp.status_code == 401 and auth:
                cred = self._get_credential()
                if isinstance(cred, APIKeyCredential):
                    raise APIKeyInvalidError
                raise AuthenticationError(f"Request returned 401: {path}")

            if is_safe and resp.status_code == 429:
                retry_after = int(resp.headers.get("retry-after", "5"))
                if attempt < MAX_GET_RETRIES - 1:
                    time.sleep(min(retry_after, 30))
                    continue
                raise CLIError(f"Rate limited. Retry after {retry_after}s.", exit_code=2)

            if is_safe and resp.status_code >= 500:
                if attempt < MAX_GET_RETRIES - 1:
                    time.sleep(2**attempt)
                    continue

            return resp

        return resp  # type: ignore[possibly-undefined]

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("DELETE", path, **kwargs)


def parse_api_error(resp: httpx.Response) -> tuple[str, str, str | None]:
    """Parse VB-OS error response. Returns (error_code, message, request_id)."""
    try:
        data = resp.json()
        return (
            data.get("error", "unknown_error"),
            data.get("message", resp.text),
            data.get("request_id"),
        )
    except Exception:
        return ("unknown_error", resp.text, None)
