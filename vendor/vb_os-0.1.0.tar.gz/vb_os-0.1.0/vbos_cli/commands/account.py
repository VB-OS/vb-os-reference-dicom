"""Account: delete, delete-status, delete-cancel, export, export-status."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    quiet_id,
)


@click.group("account")
def account() -> None:
    """Manage account."""


@account.command("delete")
@add_confirm_option
@add_output_options
@click.pass_context
def account_delete(
    ctx: click.Context,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    confirm_destructive(ctx, "delete your account", confirm)
    client = make_client(ctx)
    try:
        resp = client.post("/v1/auth/account/delete")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@account.command("delete-status")
@add_output_options
@click.pass_context
def account_delete_status(
    ctx: click.Context,
    quiet: bool,
    output_file: str | None,
) -> None:
    client = make_client(ctx)
    try:
        resp = client.get("/v1/auth/account/deletion-status")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@account.command("delete-cancel")
@add_output_options
@click.pass_context
def account_delete_cancel(
    ctx: click.Context,
    quiet: bool,
    output_file: str | None,
) -> None:
    client = make_client(ctx)
    try:
        resp = client.post("/v1/auth/account/delete/cancel")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@account.command("export")
@add_output_options
@click.pass_context
def account_export(
    ctx: click.Context,
    quiet: bool,
    output_file: str | None,
) -> None:
    client = make_client(ctx)
    try:
        resp = client.post("/v1/auth/account/export")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@account.command("export-status")
@click.option("--export-id", default=None, help="Specific export ID to check.")
@add_output_options
@click.pass_context
def account_export_status(
    ctx: click.Context,
    export_id: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    client = make_client(ctx)
    try:
        if export_id:
            path = f"/v1/auth/account/export/{export_id}"
        else:
            path = "/v1/auth/account/export/latest"
        resp = client.get(path)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
