"""Alert rules commands: create, list, get, update, delete."""

from __future__ import annotations

import json

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("alert-rules")
def alert_rules() -> None:
    """Manage alert rules."""


@alert_rules.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--config", "config_file", required=True, type=click.Path(exists=True), help="JSON config file."
)
@add_output_options
@click.pass_context
def alert_rules_create(
    ctx: click.Context,
    project: str | None,
    config_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create an alert rule."""
    project_slug = resolve_project(ctx, project)
    with open(config_file) as f:
        config = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/alert-rules", json=config)
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@alert_rules.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def alert_rules_list(
    ctx: click.Context,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List alert rules."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/alert-rules"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@alert_rules.command("get")
@click.argument("rule_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def alert_rules_get(
    ctx: click.Context,
    rule_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get alert rule detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/alert-rules/{rule_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@alert_rules.command("update")
@click.argument("rule_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--config", "config_file", required=True, type=click.Path(exists=True), help="JSON config file."
)
@add_output_options
@click.pass_context
def alert_rules_update(
    ctx: click.Context,
    rule_id: str,
    project: str | None,
    config_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update an alert rule."""
    project_slug = resolve_project(ctx, project)
    with open(config_file) as f:
        config = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.put(
            f"/v1/projects/{project_slug}/alert-rules/{rule_id}",
            json=config,
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@alert_rules.command("delete")
@click.argument("rule_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def alert_rules_delete(
    ctx: click.Context,
    rule_id: str,
    project: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Delete an alert rule."""
    confirm_destructive(ctx, "delete this alert rule", confirm)
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_slug}/alert-rules/{rule_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": True}, fmt=get_format(ctx), output_file=output_file, quiet=quiet
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()
