from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    quiet_id,
    resolve_project,
)


@click.group("analytics")
def analytics() -> None:
    """View analytics."""


@analytics.command("assertion-rate")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--since", default=None, help="Start date (ISO 8601).")
@click.option("--until", default=None, help="End date (ISO 8601).")
@click.option("--environment", default=None, help="Filter by environment.")
@add_output_options
@click.pass_context
def assertion_rate(ctx, project, since, until, environment, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        if environment:
            params["environment"] = environment
        resp = client.get(
            f"/v1/projects/{project_slug}/evaluations/dashboard", params=params
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
