"""Audit log: list, export, export-status."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    add_pagination_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id_list,
)


@click.group("audit-log")
def audit_log() -> None:
    """Query organization audit log."""


@audit_log.command("list")
@click.option("--since", default=None, help="Start timestamp (ISO 8601).")
@click.option("--until", "until_ts", default=None, help="End timestamp (ISO 8601).")
@click.option("--actor", default=None, help="Filter by actor ID.")
@click.option("--action", default=None, help="Filter by action type.")
@add_pagination_options
@add_output_options
@click.pass_context
def audit_log_list(
    ctx, since, until_ts, actor, action, limit, cursor, fetch_all, quiet, output_file
):
    client = make_client(ctx)
    try:
        path = "/v1/org/audit-log"
        params: dict = {}
        if since:
            params["since"] = since
        if until_ts:
            params["until"] = until_ts
        if actor:
            params["actor"] = actor
        if action:
            params["action"] = action
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@audit_log.command("export")
@click.option("--since", required=True, help="Start timestamp (ISO 8601).")
@click.option("--until", "until_ts", required=True, help="End timestamp (ISO 8601).")
@add_output_options
@click.pass_context
def audit_log_export(ctx, since, until_ts, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.post(
            "/v1/org/audit-log/export",
            json_body={"since": since, "until": until_ts},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(resp.json(), fmt=get_format(ctx), output_file=output_file, quiet=quiet)
    finally:
        client.close()


@audit_log.command("export-status")
@click.argument("export_id")
@add_output_options
@click.pass_context
def audit_log_export_status(ctx, export_id, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/org/audit-log/export/{export_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(resp.json(), fmt=get_format(ctx), output_file=output_file, quiet=quiet)
    finally:
        client.close()
