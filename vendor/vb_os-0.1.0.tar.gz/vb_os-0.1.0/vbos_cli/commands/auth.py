"""Authentication commands: login, logout, resend-verification."""

from __future__ import annotations

import getpass
import sys

import click

from vbos_cli import config as cfg
from vbos_cli.cli import CloudOnlyCommand
from vbos_cli.client import AuthenticatedClient, parse_api_error
from vbos_cli.credentials.store import (
    APIKeyCredential,
    CredentialStore,
    SessionCredential,
    resolve_credential,
)
from vbos_cli.errors import CLIError
from vbos_cli.output import print_banner, print_result, stderr


def _make_client(profile: str) -> AuthenticatedClient:
    api_url = cfg.get_api_url(profile)
    return AuthenticatedClient(base_url=api_url, profile=profile)


def _make_unauthed_client(profile: str) -> AuthenticatedClient:
    api_url = cfg.get_api_url(profile)
    return AuthenticatedClient(base_url=api_url, profile=profile)


def _handle_mfa(
    client: AuthenticatedClient,
    mfa_token: str,
    profile: str,
    fmt: str,
) -> None:
    """Complete MFA challenge: TOTP then recovery code fallback."""
    store = CredentialStore(profile)
    max_attempts = 5

    for attempt in range(max_attempts):
        code = getpass.getpass("TOTP code: ", stream=sys.stderr)
        resp = client.post(
            "/v1/auth/mfa/verify",
            json_body={"mfa_token": mfa_token, "code": code},
            auth=False,
        )

        if resp.status_code == 200:
            data = resp.json()
            cred = SessionCredential(
                kind="session",
                access_token=data["access_token"],
                refresh_token=data["refresh_token"],
            )
            store.store(cred)
            print_banner()
            stderr("MFA verification successful.")
            return

        if resp.status_code == 403:
            err_code, msg, _ = parse_api_error(resp)
            remaining = max_attempts - attempt - 1
            if remaining > 0:
                stderr(f"Invalid code. {remaining} attempt(s) remaining.")
                stderr("Enter 'r' to use a recovery code instead.")
                choice = getpass.getpass("Code or 'r': ", stream=sys.stderr)
                if choice.strip().lower() == "r":
                    _handle_recovery_code(client, mfa_token, profile, fmt)
                    return
            else:
                raise CLIError(
                    "Too many failed MFA attempts. Run `vbos login` again.",
                    exit_code=2,
                )
        else:
            err_code, msg, req_id = parse_api_error(resp)
            raise CLIError(f"MFA verification failed: {msg}", exit_code=2)

    raise CLIError("Too many failed MFA attempts. Run `vbos login` again.", exit_code=2)


def _handle_recovery_code(
    client: AuthenticatedClient,
    mfa_token: str,
    profile: str,
    fmt: str,
) -> None:
    store = CredentialStore(profile)
    recovery_code = getpass.getpass("Recovery code: ", stream=sys.stderr)
    resp = client.post(
        "/v1/auth/mfa/verify-recovery",
        json_body={"mfa_token": mfa_token, "recovery_code": recovery_code},
        auth=False,
    )

    if resp.status_code == 200:
        data = resp.json()
        cred = SessionCredential(
            kind="session",
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )
        store.store(cred)
        print_banner()
        stderr("Recovery code accepted. MFA verification successful.")
        return

    err_code, msg, _ = parse_api_error(resp)
    raise CLIError(f"Recovery code verification failed: {msg}", exit_code=2)


def _handle_multi_org(
    client: AuthenticatedClient,
    orgs: list[dict],
    email: str,
    password: str,
    profile: str,
    fmt: str,
) -> None:
    """Display org selector and re-submit login with selected org_id."""
    stderr("Multiple organizations found. Select one:")
    for i, org in enumerate(orgs, 1):
        stderr(f"  {i}. {org['org_name']} ({org['org_role']})")

    while True:
        choice = input("Selection (number): ")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(orgs):
                break
        except ValueError:
            pass
        stderr(f"Invalid selection. Enter 1-{len(orgs)}.")

    selected_org_id = orgs[idx]["org_id"]
    _do_login(client, email, password, profile, fmt, org_id=selected_org_id)


def _do_login(
    client: AuthenticatedClient,
    email: str,
    password: str,
    profile: str,
    fmt: str,
    org_id: str | None = None,
) -> None:
    """Submit login request and handle all response branches."""
    body: dict = {"email": email, "password": password, "client_type": "cli"}
    if org_id:
        body["org_id"] = org_id

    resp = client.post("/v1/auth/login", json_body=body, auth=False)
    data = resp.json()

    if resp.status_code == 200:
        if data.get("mfa_required"):
            _handle_mfa(client, data["mfa_token"], profile, fmt)
            return

        if data.get("tos_update_required"):
            _handle_tos(client, data, profile, fmt)
            return

        store = CredentialStore(profile)
        cred = SessionCredential(
            kind="session",
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )
        store.store(cred)
        cfg.set_value("email", email, profile)

        print_banner()

        if data.get("membership_suspended"):
            stderr("Warning: Your membership in this organization is suspended.")

        print_result(
            {"authenticated": True, "email": email},
            fmt,
        )
        stderr(f"Logged in as {email}")
        return

    if resp.status_code == 400:
        err_code, msg, _ = parse_api_error(resp)
        if err_code == "org_selection_required" and "organizations" in data:
            _handle_multi_org(client, data["organizations"], email, password, profile, fmt)
            return

    if resp.status_code == 403:
        err_code, msg, _ = parse_api_error(resp)
        if err_code == "email_not_verified":
            raise CLIError(
                "Email not verified. Check your inbox or run `vbos resend-verification`.",
                exit_code=2,
            )
        if err_code == "account_pending_deletion":
            raise CLIError(
                "Account is pending deletion. Only limited operations are available. "
                "Contact support to cancel the deletion request.",
                exit_code=2,
            )
        raise CLIError(msg, exit_code=2)

    if resp.status_code == 429:
        retry_after = data.get(
            "retry_after_seconds",
            data.get("detail", {}).get("retry_after_seconds", "unknown"),
        )
        raise CLIError(
            f"Account temporarily locked. Try again in {retry_after} seconds.",
            exit_code=2,
        )

    if resp.status_code == 401:
        raise CLIError("Invalid email or password.", exit_code=2)

    err_code, msg, req_id = parse_api_error(resp)
    raise CLIError(f"Login failed: {msg}", exit_code=2)


def _handle_tos(
    client: AuthenticatedClient,
    data: dict,
    profile: str,
    fmt: str,
) -> None:
    tos_version = data.get("tos_version", "unknown")
    tos_url = data.get("tos_url", "")
    stderr(f"Terms of Service v{tos_version} require acceptance.")
    if tos_url:
        stderr(f"View at {tos_url}")
    choice = input("Accept? [y/N]: ")
    if choice.strip().lower() != "y":
        raise CLIError("Terms of Service must be accepted to continue.", exit_code=2)

    resp = client.post("/v1/auth/accept-tos", auth=False)
    if resp.status_code != 200:
        err_code, msg, _ = parse_api_error(resp)
        raise CLIError(f"Failed to accept TOS: {msg}", exit_code=2)

    store = CredentialStore(profile)
    cred = SessionCredential(
        kind="session",
        access_token=data["access_token"],
        refresh_token=data["refresh_token"],
    )
    store.store(cred)
    stderr("Terms of Service accepted.")


@click.command(cls=CloudOnlyCommand)
@click.option("--token", default=None, help="API key for non-interactive auth (CI/CD).")
@click.option("--org", "org_id", default=None, help="Organization ID for direct selection.")
@click.pass_context
def login(ctx: click.Context, token: str | None, org_id: str | None) -> None:
    """Authenticate with the VB-OS Cloud Platform."""
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]
    client = _make_client(profile)

    try:
        if token:
            _login_api_key(client, token, profile, fmt)
        else:
            email = input("Email: ")
            password = getpass.getpass("Password: ", stream=sys.stderr)
            _do_login(client, email, password, profile, fmt, org_id=org_id)
    finally:
        client.close()


def _login_api_key(
    client: AuthenticatedClient,
    api_key: str,
    profile: str,
    fmt: str,
) -> None:
    """Validate API key via GET /v1/users/me and store it."""
    resp = client.get(
        "/v1/users/me",
        headers={"Authorization": f"Bearer {api_key}"},
        auth=False,
    )

    if resp.status_code == 401:
        raise CLIError("Invalid API key.", exit_code=2)

    if resp.status_code != 200:
        err_code, msg, _ = parse_api_error(resp)
        raise CLIError(f"API key validation failed: {msg}", exit_code=2)

    store = CredentialStore(profile)
    cred = APIKeyCredential(kind="api_key", api_key=api_key)
    store.store(cred)

    print_banner()
    data = resp.json()
    print_result(
        {"authenticated": True, "email": data.get("email", ""), "auth_type": "api_key"},
        fmt,
    )
    stderr(f"Authenticated with API key as {data.get('email', 'unknown')}")


@click.command(cls=CloudOnlyCommand)
@click.pass_context
def logout(ctx: click.Context) -> None:
    """Sign out and clear stored credentials."""
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]

    import os

    env_key = os.environ.get("VBOS_API_KEY")

    cred = resolve_credential(profile)

    if cred is None:
        if env_key:
            stderr(
                "No stored credentials to remove. Authentication is provided "
                "by the VBOS_API_KEY environment variable. Unset it to stop "
                "authenticating: `unset VBOS_API_KEY`."
            )
        else:
            stderr("No stored credentials.")
        print_result({"logged_out": True}, fmt)
        return

    store = CredentialStore(profile)

    if isinstance(cred, APIKeyCredential) and not env_key:
        store.delete()
        print_result({"logged_out": True}, fmt)
        stderr("API key removed from credential store.")
        return

    if isinstance(cred, APIKeyCredential) and env_key:
        stderr(
            "No stored credentials to remove. Authentication is provided "
            "by the VBOS_API_KEY environment variable. Unset it to stop "
            "authenticating: `unset VBOS_API_KEY`."
        )
        print_result({"logged_out": True}, fmt)
        return

    if isinstance(cred, SessionCredential):
        client = _make_client(profile)
        try:
            resp = client.post(
                "/v1/auth/logout",
                headers={"Authorization": f"Bearer {cred.refresh_token}"},
                auth=False,
            )
            if resp.status_code != 200:
                stderr("Logged out locally. Server-side session revocation could not be confirmed.")
        except Exception:
            stderr("Logged out locally. Server-side session revocation could not be confirmed.")
        finally:
            client.close()

        store.delete()
        print_result({"logged_out": True}, fmt)
        stderr("Logged out.")


@click.command("resend-verification", cls=CloudOnlyCommand)
@click.pass_context
def resend_verification(ctx: click.Context) -> None:
    """Resend email verification link."""
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]

    email = cfg.get_email(profile)
    if not email:
        email = input("Email: ")

    client = _make_client(profile)
    try:
        resp = client.post(
            "/v1/auth/resend-verification",
            json_body={"email": email},
            auth=False,
        )
        if resp.status_code == 200:
            print_result({"message": "Verification email sent."}, fmt)
            stderr(f"Verification email sent to {email}")
        else:
            err_code, msg, _ = parse_api_error(resp)
            raise CLIError(f"Failed: {msg}", exit_code=2)
    finally:
        client.close()
