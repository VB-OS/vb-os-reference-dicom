"""Boundaries commands: CRUD, compile, validate, versions, diff, promote."""

from __future__ import annotations

import json

import click

from vbos_cli.formatters import (
    add_output_options,
    add_pagination_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_environment,
    resolve_project,
)


@click.group("boundaries")
def boundaries() -> None:
    """Manage boundaries."""


@boundaries.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", required=True, help="Boundary name.")
@click.option("--ref", required=True, help="Boundary reference.")
@click.option("--source", required=True, type=click.Path(exists=True), help="DSL source file.")
@add_output_options
@click.pass_context
def boundaries_create(ctx, project, name, ref, source, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    with open(source) as f:
        dsl_source = f.read()
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/boundaries",
            json_body={"name": name, "boundary_ref": ref, "dsl_source": dsl_source},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def boundaries_list(ctx, project, limit, cursor, fetch_all, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/boundaries"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@boundaries.command("get")
@click.argument("boundary_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def boundaries_get(ctx, boundary_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/boundaries/{boundary_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("update")
@click.argument("boundary_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", default=None, help="New boundary name.")
@add_output_options
@click.pass_context
def boundaries_update(ctx, boundary_id, project, name, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    body: dict = {}
    if name:
        body["name"] = name
    client = make_client(ctx)
    try:
        resp = client.patch(f"/v1/projects/{project_slug}/boundaries/{boundary_id}", json_body=body)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("archive")
@click.argument("boundary_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def boundaries_archive(ctx, boundary_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/boundaries/{boundary_id}/archive")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("compile")
@click.option("--source", required=True, type=click.Path(exists=True), help="DSL source file.")
@add_output_options
@click.pass_context
def boundaries_compile(ctx, source, quiet, output_file):
    with open(source) as f:
        dsl_source = f.read()
    client = make_client(ctx)
    try:
        resp = client.post("/v1/boundaries/compile", json_body={"dsl_source": dsl_source})
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("validate")
@click.option("--source", required=True, type=click.Path(exists=True), help="Boundary DSL file.")
@click.option("--workload", required=True, type=click.Path(exists=True), help="Workload JSON file.")
@add_output_options
@click.pass_context
def boundaries_validate(ctx, source, workload, quiet, output_file):
    with open(source) as f:
        dsl_source = f.read()
    with open(workload) as f:
        workload_data = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            "/v1/validate", json_body={"dsl_source": dsl_source, "workload": workload_data}
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("diff")
@click.argument("boundary_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--v1", "version_1", required=True, help="First version ID.")
@click.option("--v2", "version_2", required=True, help="Second version ID.")
@add_output_options
@click.pass_context
def boundaries_diff(ctx, boundary_id, project, version_1, version_2, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/diff",
            params={"v1": version_1, "v2": version_2},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.command("promote")
@click.argument("boundary_ref")
@click.option(
    "--version", "version_id", required=True, help="Explicit boundary version ID (A1 Edit 41)."
)
@click.option("--environment", default=None, help="Target environment.")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def boundaries_promote(ctx, boundary_ref, version_id, environment, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{env_name}/deployments",
            json_body={"boundary_ref": boundary_ref, "boundary_version_id": version_id},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundaries.group("versions")
def boundary_versions() -> None:
    """Manage boundary versions."""


@boundary_versions.command("create")
@click.argument("boundary_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--source", required=True, type=click.Path(exists=True), help="DSL source file.")
@add_output_options
@click.pass_context
def versions_create(ctx, boundary_id, project, source, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    with open(source) as f:
        dsl_source = f.read()
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions",
            json_body={"dsl_source": dsl_source},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundary_versions.command("list")
@click.argument("boundary_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def versions_list(ctx, boundary_id, project, limit, cursor, fetch_all, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@boundary_versions.command("get")
@click.argument("boundary_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def versions_get(ctx, boundary_id, version_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions/{version_id}"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundary_versions.command("update")
@click.argument("boundary_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--source", required=True, type=click.Path(exists=True), help="Updated DSL source file."
)
@add_output_options
@click.pass_context
def versions_update(ctx, boundary_id, version_id, project, source, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    with open(source) as f:
        dsl_source = f.read()
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions/{version_id}",
            json_body={"dsl_source": dsl_source},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundary_versions.command("submit")
@click.argument("boundary_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def versions_submit(ctx, boundary_id, version_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions/{version_id}/submit"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundary_versions.command("approve")
@click.argument("boundary_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def versions_approve(ctx, boundary_id, version_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions/{version_id}/approve"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@boundary_versions.command("reject")
@click.argument("boundary_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def versions_reject(ctx, boundary_id, version_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/boundaries/{boundary_id}/versions/{version_id}/reject"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
