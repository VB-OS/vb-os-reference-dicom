from __future__ import annotations

import json

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.command("certify")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", required=True, help="Target environment.")
@click.option("--model", required=True, help="Certification model ID.")
@click.option("--evidence", required=True, type=click.Path(exists=True), help="Evidence JSON file.")
@add_output_options
@click.pass_context
def certify(ctx, project, environment, model, evidence, quiet, output_file):
    """Initiate a certification run."""
    project_slug = resolve_project(ctx, project)
    with open(evidence) as f:
        evidence_data = json.load(f)
    body = {
        "model_id": model,
        "evidence": evidence_data,
        "environment_id": environment,
    }
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/certify", json_body=body)
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@click.group("certifications")
def certifications() -> None:
    """Manage certification runs."""


@certifications.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def certifications_list(ctx, project, limit, cursor, fetch_all, quiet, output_file):
    """List certification runs."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/certifications"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@certifications.command("get")
@click.argument("run_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def certifications_get(ctx, run_id, project, quiet, output_file):
    """Get certification run detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/certifications/{run_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@certifications.command("report")
@click.argument("run_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--output", "output_path", required=True, type=click.Path(), help="Output file path.")
@click.pass_context
def certifications_report(ctx, run_id, project, output_path):
    """Download certification report."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/certifications/{run_id}/report")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        with open(output_path, "w") as f:
            json.dump(resp.json(), f, indent=2)
        click.echo(f"Report written to {output_path}")
    finally:
        client.close()


@certifications.command("revoke")
@click.argument("run_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def certifications_revoke(ctx, run_id, project, quiet, output_file):
    """Revoke (cancel) a certification run."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/certifications/{run_id}/cancel")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@click.group("certification-models")
def certification_models() -> None:
    """Manage certification models."""


@certification_models.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", required=True, help="Model name.")
@click.option(
    "--config", "config_file", required=True,
    type=click.Path(exists=True), help="Config JSON file.",
)
@add_output_options
@click.pass_context
def cm_create(ctx, project, name, config_file, quiet, output_file):
    """Create a certification model."""
    project_slug = resolve_project(ctx, project)
    with open(config_file) as f:
        config = json.load(f)
    body = {"name": name, "config": config}
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/certification-models", json_body=body)
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@certification_models.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def cm_list(ctx, project, limit, cursor, fetch_all, quiet, output_file):
    """List certification models."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/certification-models"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@certification_models.command("get")
@click.argument("model_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def cm_get(ctx, model_id, project, quiet, output_file):
    """Get certification model detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/certification-models/{model_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@certification_models.command("update")
@click.argument("model_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--config", "config_file", required=True,
    type=click.Path(exists=True), help="Config JSON file.",
)
@add_output_options
@click.pass_context
def cm_update(ctx, model_id, project, config_file, quiet, output_file):
    """Update a certification model."""
    project_slug = resolve_project(ctx, project)
    with open(config_file) as f:
        config = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/certification-models/{model_id}",
            json_body=config,
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@certification_models.command("delete")
@click.argument("model_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def cm_delete(ctx, model_id, project, confirm, quiet, output_file):
    """Delete (archive) a certification model."""
    project_slug = resolve_project(ctx, project)
    confirm_destructive(ctx, f"delete certification model {model_id}", confirm)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/certification-models/{model_id}/archive",
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
