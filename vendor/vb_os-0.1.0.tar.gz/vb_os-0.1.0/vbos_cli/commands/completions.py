"""Shell completion script generation."""

from __future__ import annotations

import click

from vbos_cli.output import stderr


@click.group()
def completions() -> None:
    """Generate shell completion scripts."""


@completions.command("bash")
def completions_bash() -> None:
    """Output bash completion script."""
    script = 'eval "$(_VBOS_COMPLETE=bash_source vbos)"'
    click.echo(script)
    stderr('Add to ~/.bashrc: eval "$(_VBOS_COMPLETE=bash_source vbos)"')


@completions.command("zsh")
def completions_zsh() -> None:
    """Output zsh completion script."""
    script = 'eval "$(_VBOS_COMPLETE=zsh_source vbos)"'
    click.echo(script)
    stderr('Add to ~/.zshrc: eval "$(_VBOS_COMPLETE=zsh_source vbos)"')


@completions.command("fish")
def completions_fish() -> None:
    """Output fish completion script."""
    script = "_VBOS_COMPLETE=fish_source vbos | source"
    click.echo(script)
    stderr("Add to ~/.config/fish/completions/vbos.fish: _VBOS_COMPLETE=fish_source vbos | source")
