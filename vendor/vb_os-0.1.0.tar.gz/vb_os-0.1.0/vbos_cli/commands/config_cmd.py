"""Configuration management: config set/get/list."""

from __future__ import annotations

import click

from vbos_cli import config as cfg
from vbos_cli.credentials.file import FileStore
from vbos_cli.credentials.keychain import KeychainStore, is_supported_backend
from vbos_cli.credentials.migration import migrate_credentials
from vbos_cli.errors import CLIError
from vbos_cli.output import print_result, stderr


@click.group()
def config() -> None:
    """Manage CLI configuration."""


@config.command("set")
@click.argument("key")
@click.argument("value")
@click.pass_context
def config_set(ctx: click.Context, key: str, value: str) -> None:
    """Set a configuration value."""
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]

    if key == "credential-store":
        _handle_credential_store_switch(value, profile, fmt)
        return

    try:
        cfg.set_value(key, value, profile)
    except ValueError as e:
        raise CLIError(str(e), exit_code=2) from None

    print_result({"key": key, "value": value, "profile": profile}, fmt)


@config.command("get")
@click.argument("key")
@click.pass_context
def config_get(ctx: click.Context, key: str) -> None:
    """Get a configuration value."""
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]

    value = cfg.get_value(key, profile)
    if value is None:
        raise CLIError(f"Key '{key}' not set in profile '{profile}'.", exit_code=1)

    print_result({"key": key, "value": value, "profile": profile}, fmt)


@config.command("list")
@click.pass_context
def config_list(ctx: click.Context) -> None:
    """List all configuration values."""
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]

    values = cfg.list_values(profile)
    if fmt == "table":
        rows = [{"key": k, "value": v} for k, v in sorted(values.items())]
        print_result(rows, fmt)
    else:
        print_result({"profile": profile, **values}, fmt)


def _handle_credential_store_switch(value: str, profile: str, fmt: str) -> None:
    if value not in ("keychain", "file"):
        raise CLIError(
            "credential-store must be 'keychain' or 'file'.",
            exit_code=2,
        )

    current = cfg.get_credential_store_type(profile)
    if current == value:
        stderr(f"Credential store is already '{value}'.")
        return

    if current is not None and current != value:
        if value == "file":
            source = KeychainStore(profile)
            destination = FileStore(profile)
        else:
            source = FileStore(profile)
            if not is_supported_backend():
                raise CLIError(
                    "No supported OS keychain backend available. "
                    "Cannot switch to keychain storage.",
                    exit_code=2,
                )
            destination = KeychainStore(profile)

        migrate_credentials(source, destination)

    cfg.set_value("credential-store", value, profile)
    print_result({"credential-store": value, "profile": profile}, fmt)
    stderr(f"Credential store set to '{value}'.")
