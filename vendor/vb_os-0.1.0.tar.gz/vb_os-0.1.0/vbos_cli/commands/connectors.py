"""Connectors commands: create, list, get, update, delete, test, gather, providers, OAuth."""

from __future__ import annotations

import json
import sys
import time
import webbrowser

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("connectors")
def connectors() -> None:
    """Manage connectors."""


@connectors.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--provider", required=True, help="Connector provider name.")
@click.option(
    "--config", "config_file", required=True, type=click.Path(exists=True), help="JSON config file."
)
@add_output_options
@click.pass_context
def connectors_create(
    ctx: click.Context,
    project: str | None,
    provider: str,
    config_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a connector."""
    project_slug = resolve_project(ctx, project)
    with open(config_file) as f:
        config = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/connectors",
            json={"provider": provider, "config": config},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@connectors.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def connectors_list(
    ctx: click.Context,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List connectors."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/connectors"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@connectors.command("get")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def connectors_get(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get connector detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/connectors/{connector_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@connectors.command("update")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--config", "config_file", required=True, type=click.Path(exists=True), help="JSON config file."
)
@add_output_options
@click.pass_context
def connectors_update(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    config_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update a connector."""
    project_slug = resolve_project(ctx, project)
    with open(config_file) as f:
        config = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/connectors/{connector_id}",
            json={"config": config},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@connectors.command("delete")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def connectors_delete(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Delete a connector."""
    confirm_destructive(ctx, "delete this connector", confirm)
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_slug}/connectors/{connector_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": True}, fmt=get_format(ctx), output_file=output_file, quiet=quiet
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()


@connectors.command("test")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def connectors_test(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Test a connector."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/connectors/{connector_id}/test")
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@connectors.command("gather")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def connectors_gather(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Trigger evidence gathering for a connector."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/connectors/{connector_id}/gather")
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


_TERMINAL_STATUSES = frozenset({
    "COMPLETED", "DECLINED", "FAILED", "EXPIRED", "SUPERSEDED",
})

_EXIT_MESSAGES: dict[str, str] = {
    "COMPLETED": "Connected successfully.",
    "DECLINED": "Authorization was declined by the user.",
    "FAILED": "Authorization failed.",
    "EXPIRED": "Authorization request expired.",
    "SUPERSEDED": "Authorization was superseded by another request.",
}


def _poll_authorization(
    client: object,
    authorization_id: str,
    poll_interval: int,
    expires_in: int,
) -> dict:
    path = f"/v1/connectors/oauth/authorizations/{authorization_id}/status"
    deadline = time.monotonic() + expires_in
    max_transient_retries = 5
    click.echo("Waiting for authorization... (press Ctrl+C to stop)")
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                click.echo("\nAuthorization window expired.")
                return {"status": "EXPIRED"}
            transient_retries = 0
            while True:
                resp = client.get(path)  # type: ignore[union-attr]
                if resp.status_code == 503:
                    transient_retries += 1
                    if transient_retries > max_transient_retries:
                        click.echo("\nService temporarily unavailable.")
                        return {"status": "FAILED"}
                    time.sleep(min(poll_interval * (2 ** (transient_retries - 1)), 30))
                    continue
                break
            if resp.status_code == 404:
                click.echo("\nAuthorization not found.")
                return {"status": "NOT_FOUND"}
            if resp.status_code != 200:
                click.echo(f"\nUnexpected status {resp.status_code}.")
                return {"status": "FAILED"}
            result = resp.json()
            status = result.get("status", "")
            if status in _TERMINAL_STATUSES:
                return result
            click.echo(".", nl=False)
            time.sleep(min(poll_interval, max(0, deadline - time.monotonic())))
    except KeyboardInterrupt:
        click.echo("\nStopped waiting for authorization.")
        click.echo("The authorization request remains valid until it completes or expires.")
        sys.exit(130)


def _print_auth_result(result: dict) -> None:
    status = result.get("status", "UNKNOWN")
    click.echo()
    if status == "COMPLETED":
        provider_display = result.get("provider_account_display", "")
        scopes = result.get("granted_scopes", [])
        click.echo("Connected successfully.")
        if provider_display:
            click.echo(f"  Account: {provider_display}")
        if scopes:
            click.echo(f"  Scopes: {', '.join(scopes)}")
    else:
        click.echo(_EXIT_MESSAGES.get(status, f"Authorization ended with status: {status}"))


@connectors.command("authorize")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--no-browser", is_flag=True, default=False, help="Do not open URL in browser.")
@add_output_options
@click.pass_context
def connectors_authorize(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    no_browser: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Initiate OAuth authorization for a connector."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/connectors/{connector_id}/oauth/authorize",
            json={"mode": "REMOTE"},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()

        auth_url = data.get("authorization_url", "")
        authorization_id = data.get("authorization_id", "")
        poll_interval = data.get("poll_interval", 3)
        expires_in = data.get("expires_in", 600)

        if quiet:
            click.echo(authorization_id)
            return

        if output_file:
            fmt = get_format(ctx)
            format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
            return

        click.echo(f"\nAuthorize at:\n  {auth_url}\n")

        if not no_browser:
            webbrowser.open(auth_url)

        result = _poll_authorization(client, authorization_id, poll_interval, expires_in)
        _print_auth_result(result)

        status = result.get("status", "")
        if status != "COMPLETED":
            sys.exit(1)
    finally:
        client.close()


@connectors.command("disconnect")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def connectors_disconnect(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Disconnect OAuth authorization for a connector."""
    confirm_destructive(ctx, "disconnect this connector's OAuth authorization", confirm)
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/connectors/{connector_id}/oauth/disconnect",
            json={},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@connectors.command("reconnect")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--no-browser", is_flag=True, default=False, help="Do not open URL in browser.")
@add_output_options
@click.pass_context
def connectors_reconnect(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    no_browser: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Reconnect OAuth authorization for a connector (replacement authorization)."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/connectors/{connector_id}/oauth/reconnect",
            json={"mode": "REMOTE"},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()

        auth_url = data.get("authorization_url", "")
        authorization_id = data.get("authorization_id", "")
        poll_interval = data.get("poll_interval", 3)
        expires_in = data.get("expires_in", 600)

        if quiet:
            click.echo(authorization_id)
            return

        if output_file:
            fmt = get_format(ctx)
            format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
            return

        click.echo(f"\nReauthorize at:\n  {auth_url}\n")

        if not no_browser:
            webbrowser.open(auth_url)

        result = _poll_authorization(client, authorization_id, poll_interval, expires_in)
        _print_auth_result(result)

        status = result.get("status", "")
        if status != "COMPLETED":
            sys.exit(1)
    finally:
        client.close()


@connectors.command("status")
@click.argument("connector_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def connectors_status(
    ctx: click.Context,
    connector_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Show OAuth authorization and connector status."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(
            f"/v1/projects/{project_slug}/connectors/{connector_id}/oauth/status",
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()

        if output_file or quiet:
            fmt = get_format(ctx)
            format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
            return

        connector_resp = client.get(
            f"/v1/projects/{project_slug}/connectors/{connector_id}",
        )
        connector_data = connector_resp.json() if connector_resp.status_code == 200 else {}

        click.echo(f"Connector:      {connector_data.get('name', connector_id)}")
        click.echo(f"Provider:       {connector_data.get('provider', 'unknown')}")
        click.echo(f"Status:         {connector_data.get('status', 'unknown')}")
        click.echo(f"Authorization:  {data.get('authorization_status', 'unknown')}")

        account = data.get("provider_account_id", "")
        if account:
            click.echo(f"Account:        {account}")
        scopes = data.get("granted_scopes", [])
        if scopes:
            click.echo(f"Scopes:         {', '.join(scopes)}")
        last_refreshed = data.get("last_refreshed_at")
        if last_refreshed:
            click.echo(f"Last Refreshed: {last_refreshed}")
    finally:
        client.close()


@connectors.group("providers")
def providers() -> None:
    """Manage connector providers."""


@providers.command("list")
@add_output_options
@click.pass_context
def providers_list(
    ctx: click.Context,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List connector providers."""
    client = make_client(ctx)
    try:
        resp = client.get("/v1/connector-providers")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@providers.command("get")
@click.argument("provider")
@add_output_options
@click.pass_context
def providers_get(
    ctx: click.Context,
    provider: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get connector provider detail."""
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/connector-providers/{provider}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()
