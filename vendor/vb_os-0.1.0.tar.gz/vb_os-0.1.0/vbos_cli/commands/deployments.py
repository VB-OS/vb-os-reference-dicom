"""Deployments commands: list, get, active, promote, rollback, approve, reject."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_environment,
    resolve_project,
)


@click.group("deployments")
def deployments() -> None:
    """Manage deployments."""


@deployments.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name.")
@add_pagination_options
@add_output_options
@click.pass_context
def deployments_list(ctx, project, environment, limit, cursor, fetch_all, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/environments/{env_name}/deployments"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@deployments.command("get")
@click.argument("deployment_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name.")
@add_output_options
@click.pass_context
def deployments_get(ctx, deployment_id, project, environment, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.get(
            f"/v1/projects/{project_slug}/environments/{env_name}/deployments/{deployment_id}"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@deployments.command("active")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name.")
@add_output_options
@click.pass_context
def deployments_active(ctx, project, environment, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.get(
            f"/v1/projects/{project_slug}/environments/{env_name}/deployments/active"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@deployments.command("promote")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--from", "from_env", required=True, help="Source environment.",
)
@click.option("--to", "to_env", required=True, help="Target environment.")
@click.option(
    "--version", "version_id", required=True,
    help="Explicit boundary version ID.",
)
@add_output_options
@click.pass_context
def deployments_promote(
    ctx, project, from_env, to_env, version_id, quiet, output_file,
):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{to_env}/deployments",
            json_body={
                "source_environment": from_env,
                "boundary_version_id": version_id,
            },
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@deployments.command("rollback")
@click.argument("deployment_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name.")
@add_confirm_option
@add_output_options
@click.pass_context
def deployments_rollback(ctx, deployment_id, project, environment, confirm, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    confirm_destructive(ctx, f"rollback deployment {deployment_id}", confirm)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{env_name}/deployments/{deployment_id}/rollback",
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@deployments.command("approve")
@click.argument("deployment_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name.")
@add_output_options
@click.pass_context
def deployments_approve(ctx, deployment_id, project, environment, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{env_name}/deployments/{deployment_id}/approve",
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@deployments.command("reject")
@click.argument("deployment_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name.")
@add_output_options
@click.pass_context
def deployments_reject(ctx, deployment_id, project, environment, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    env_name = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{env_name}/deployments/{deployment_id}/reject",
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
