"""Environments commands: create, list, get, update, archive, unarchive."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    add_pagination_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("environments")
def environments() -> None:
    """Manage environments."""


@environments.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", required=True, help="Environment name.")
@add_output_options
@click.pass_context
def environments_create(
    ctx: click.Context,
    project: str | None,
    name: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a new environment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments",
            json_body={"name": name},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@environments.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def environments_list(
    ctx: click.Context,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List environments."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/environments"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@environments.command("get")
@click.argument("env_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def environments_get(
    ctx: click.Context,
    env_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get environment detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/environments/{env_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@environments.command("update")
@click.argument("env_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", required=True, help="New environment name.")
@add_output_options
@click.pass_context
def environments_update(
    ctx: click.Context,
    env_id: str,
    project: str | None,
    name: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update an environment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/environments/{env_id}",
            json_body={"name": name},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@environments.command("archive")
@click.argument("env_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def environments_archive(
    ctx: click.Context,
    env_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Archive an environment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/environments/{env_id}/archive")
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@environments.command("unarchive")
@click.argument("env_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def environments_unarchive(
    ctx: click.Context,
    env_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Unarchive an environment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/environments/{env_id}/unarchive")
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()
