"""Evaluations commands: list, get, search, export, share, replay-analysis."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    add_pagination_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("evaluations")
def evaluations() -> None:
    """Manage evaluations."""


@evaluations.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--decision", default=None, help="Filter by decision (ASSERT/DEFER).")
@click.option("--since", default=None, help="Filter: created after (ISO date).")
@click.option("--until", "until_date", default=None, help="Filter: created before (ISO date).")
@click.option("--boundary", default=None, help="Filter by boundary ref.")
@add_pagination_options
@add_output_options
@click.pass_context
def evaluations_list(
    ctx: click.Context,
    project: str | None,
    decision: str | None,
    since: str | None,
    until_date: str | None,
    boundary: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List evaluations."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if decision:
            params["decision"] = decision
        if since:
            params["since"] = since
        if until_date:
            params["until"] = until_date
        if boundary:
            params["boundary_ref"] = boundary
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/evaluations"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@evaluations.command("get")
@click.argument("evaluation_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def evaluations_get(
    ctx: click.Context,
    evaluation_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get evaluation detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/evaluations/{evaluation_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@evaluations.command("search")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--query", required=True, help="Search query.")
@add_pagination_options
@add_output_options
@click.pass_context
def evaluations_search(
    ctx: click.Context,
    project: str | None,
    query: str,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Search evaluations."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {"q": query}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        resp = client.get("/v1/evaluations/search", params={"project": project_slug, **params})
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@evaluations.command("export")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def evaluations_export(
    ctx: click.Context,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Request evaluation data export."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/evaluations/export")
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@evaluations.command("share")
@click.argument("evaluation_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def evaluations_share(
    ctx: click.Context,
    evaluation_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a share link for an evaluation."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/evaluations/{evaluation_id}/share")
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@evaluations.command("replay-analysis")
@click.argument("boundary_ref")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def evaluations_replay_analysis(
    ctx: click.Context,
    boundary_ref: str,
    version_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Trigger replay analysis for a boundary version."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/evaluations/replay-analysis",
            json_body={"boundary_ref": boundary_ref, "version_id": version_id},
        )
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()
