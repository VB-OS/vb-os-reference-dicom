"""Flows commands: create, list, get, update, delete, export, import,
from-template, versions, deploy, suspend, resume, dry-run,
executions, templates."""

from __future__ import annotations

import json

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("flows")
def flows() -> None:
    """Manage flows."""


@flows.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", required=True, help="Flow name.")
@click.option(
    "--definition",
    "definition_file",
    required=True,
    type=click.Path(exists=True),
    help="JSON definition file.",
)
@add_output_options
@click.pass_context
def flows_create(
    ctx: click.Context,
    project: str | None,
    name: str,
    definition_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a flow."""
    project_slug = resolve_project(ctx, project)
    with open(definition_file) as f:
        definition = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/flows",
            json={"name": name, "definition": definition},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def flows_list(
    ctx: click.Context,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List flows."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/flows"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@flows.command("get")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def flows_get(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get flow detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/flows/{flow_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("update")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", default=None, help="Flow name.")
@add_output_options
@click.pass_context
def flows_update(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    name: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update a flow."""
    project_slug = resolve_project(ctx, project)
    payload: dict = {}
    if name:
        payload["name"] = name
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/flows/{flow_id}",
            json=payload,
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("delete")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def flows_delete(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Delete a flow."""
    confirm_destructive(ctx, "delete this flow", confirm)
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_slug}/flows/{flow_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": True}, fmt=get_format(ctx), output_file=output_file, quiet=quiet
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()


@flows.command("export")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--output", "dest_file", required=True, type=click.Path(), help="Output file path.")
@click.pass_context
def flows_export(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    dest_file: str,
) -> None:
    """Export a flow definition to a file."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/flows/{flow_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        with open(dest_file, "w") as f:
            json.dump(data, f, indent=2, default=str)
        click.echo(f"Exported to {dest_file}", err=True)
    finally:
        client.close()


@flows.command("import")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--file",
    "import_file",
    required=True,
    type=click.Path(exists=True),
    help="JSON file to import.",
)
@add_output_options
@click.pass_context
def flows_import(
    ctx: click.Context,
    project: str | None,
    import_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Import a flow from a file."""
    project_slug = resolve_project(ctx, project)
    with open(import_file) as f:
        payload = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/flows/import", json=payload)
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("from-template")
@click.argument("template_slug")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def flows_from_template(
    ctx: click.Context,
    template_slug: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a flow from a template."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/flows/from-template",
            json={"template": template_slug},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.group("versions")
def versions() -> None:
    """Manage flow versions."""


@versions.command("create")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--definition",
    "definition_file",
    required=True,
    type=click.Path(exists=True),
    help="JSON definition file.",
)
@add_output_options
@click.pass_context
def versions_create(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    definition_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a flow version."""
    project_slug = resolve_project(ctx, project)
    with open(definition_file) as f:
        definition = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/flows/{flow_id}/versions",
            json={"definition": definition},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@versions.command("list")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def versions_list(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List flow versions."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/flows/{flow_id}/versions"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@versions.command("get")
@click.argument("flow_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def versions_get(
    ctx: click.Context,
    flow_id: str,
    version_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get flow version detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/flows/{flow_id}/versions/{version_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@versions.command("update")
@click.argument("flow_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--definition",
    "definition_file",
    required=True,
    type=click.Path(exists=True),
    help="JSON definition file.",
)
@add_output_options
@click.pass_context
def versions_update(
    ctx: click.Context,
    flow_id: str,
    version_id: str,
    project: str | None,
    definition_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update a flow version."""
    project_slug = resolve_project(ctx, project)
    with open(definition_file) as f:
        definition = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/flows/{flow_id}/versions/{version_id}",
            json={"definition": definition},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@versions.command("delete")
@click.argument("flow_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def versions_delete(
    ctx: click.Context,
    flow_id: str,
    version_id: str,
    project: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Delete a flow version."""
    confirm_destructive(ctx, "delete this flow version", confirm)
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_slug}/flows/{flow_id}/versions/{version_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": True}, fmt=get_format(ctx), output_file=output_file, quiet=quiet
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()


@versions.command("approve")
@click.argument("flow_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def versions_approve(
    ctx: click.Context,
    flow_id: str,
    version_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Approve a flow version."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/flows/{flow_id}/versions/{version_id}/approve"
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("deploy")
@click.argument("flow_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", required=True, help="Target environment.")
@add_output_options
@click.pass_context
def flows_deploy(
    ctx: click.Context,
    flow_id: str,
    version_id: str,
    project: str | None,
    environment: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Deploy a flow version to an environment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/flows/{flow_id}/versions/{version_id}/deploy",
            json={"environment": environment},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("suspend")
@click.argument("deployment_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def flows_suspend(
    ctx: click.Context,
    deployment_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Suspend a flow deployment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/deployments/{deployment_id}/suspend")
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("resume")
@click.argument("deployment_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def flows_resume(
    ctx: click.Context,
    deployment_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Resume a suspended flow deployment."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/deployments/{deployment_id}/resume")
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.command("dry-run")
@click.argument("flow_id")
@click.argument("version_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--decision", required=True, help="Decision value for dry run.")
@click.option(
    "--evidence",
    "evidence_file",
    required=True,
    type=click.Path(exists=True),
    help="JSON evidence file.",
)
@add_output_options
@click.pass_context
def flows_dry_run(
    ctx: click.Context,
    flow_id: str,
    version_id: str,
    project: str | None,
    decision: str,
    evidence_file: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Execute a dry run of a flow version."""
    project_slug = resolve_project(ctx, project)
    with open(evidence_file) as f:
        evidence = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/flows/{flow_id}/versions/{version_id}/dry-run",
            json={"decision": decision, "evidence": evidence},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.group("executions")
def executions() -> None:
    """Manage flow executions."""


@executions.command("list")
@click.argument("flow_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def executions_list(
    ctx: click.Context,
    flow_id: str,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List executions for a flow."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/flows/{flow_id}/executions"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@executions.command("reconstruct")
@click.argument("flow_id")
@click.argument("execution_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def executions_reconstruct(
    ctx: click.Context,
    flow_id: str,
    execution_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Reconstruct a flow execution."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(
            f"/v1/projects/{project_slug}/flows/{flow_id}/executions/{execution_id}/reconstruct",
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@flows.group("templates")
def templates() -> None:
    """Manage flow templates."""


@templates.command("list")
@add_output_options
@click.pass_context
def templates_list(
    ctx: click.Context,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List flow templates."""
    client = make_client(ctx)
    try:
        resp = client.get("/v1/flow-templates")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@templates.command("get")
@click.argument("slug")
@add_output_options
@click.pass_context
def templates_get(
    ctx: click.Context,
    slug: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get flow template detail."""
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/flow-templates/{slug}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()
