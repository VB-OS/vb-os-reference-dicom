from __future__ import annotations

import json

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("governed-workspaces")
def governed_workspaces() -> None:
    """Manage governed workspaces."""


@governed_workspaces.command("provision")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option(
    "--config",
    required=True,
    type=click.Path(exists=True),
    help="Workspace configuration JSON file.",
)
@add_output_options
@click.pass_context
def gw_provision(ctx, project, config, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    with open(config) as f:
        config_data = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/workspaces",
            json_body=config_data,
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@governed_workspaces.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def gw_list(ctx, project, limit, cursor, fetch_all, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/workspaces"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@governed_workspaces.command("get")
@click.argument("workspace_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def gw_get(ctx, workspace_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/workspaces/{workspace_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@governed_workspaces.command("deploy")
@click.argument("workspace_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--version", required=True, help="Version ID to deploy.")
@add_output_options
@click.pass_context
def gw_deploy(ctx, workspace_id, project, version, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/workspaces/{workspace_id}/versions/{version}/deploy",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@governed_workspaces.command("evaluate")
@click.argument("workspace_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def gw_evaluate(ctx, workspace_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/workspaces/{workspace_id}/instances",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        instance = resp.json()
        instance_id = instance.get("id", "")
        resp = client.post(
            f"/v1/projects/{project_slug}/workspaces/{workspace_id}/instances/{instance_id}/submit",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@governed_workspaces.command("seal")
@click.argument("workspace_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--version", required=True, help="Version ID to seal.")
@add_output_options
@click.pass_context
def gw_seal(ctx, workspace_id, project, version, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/workspaces/{workspace_id}/versions/{version}/archive",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@governed_workspaces.command("teardown")
@click.argument("workspace_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def gw_teardown(ctx, workspace_id, project, confirm, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    confirm_destructive(ctx, "tear down this governed workspace", confirm)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/workspaces/{workspace_id}/versions/latest/archive",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
