"""API keys commands: create, list, get, rotate, revoke."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    format_secret,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_environment,
    resolve_project,
)


@click.group("keys")
def keys() -> None:
    """Manage API keys."""


@keys.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name or ID.")
@click.option("--name", required=True, help="Key label.")
@click.option("--scopes", required=True, help="Comma-separated scopes.")
@add_output_options
@click.pass_context
def keys_create(
    ctx: click.Context,
    project: str | None,
    environment: str | None,
    name: str,
    scopes: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a new API key."""
    project_slug = resolve_project(ctx, project)
    env = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{env}/api-keys",
            json_body={"name": name, "scopes": [s.strip() for s in scopes.split(",")]},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_secret(data, secret_key="api_key", output_file=output_file, quiet=quiet, fmt=fmt)
    finally:
        client.close()


@keys.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def keys_list(
    ctx: click.Context,
    project: str | None,
    environment: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List API keys."""
    project_slug = resolve_project(ctx, project)
    env = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/environments/{env}/api-keys"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@keys.command("get")
@click.argument("key_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name or ID.")
@add_output_options
@click.pass_context
def keys_get(
    ctx: click.Context,
    key_id: str,
    project: str | None,
    environment: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get API key detail."""
    project_slug = resolve_project(ctx, project)
    env = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/environments/{env}/api-keys/{key_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@keys.command("rotate")
@click.argument("key_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name or ID.")
@add_output_options
@click.pass_context
def keys_rotate(
    ctx: click.Context,
    key_id: str,
    project: str | None,
    environment: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Rotate an API key."""
    project_slug = resolve_project(ctx, project)
    env = resolve_environment(ctx, environment)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/environments/{env}/api-keys/{key_id}/rotate",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_secret(data, secret_key="api_key", output_file=output_file, quiet=quiet, fmt=fmt)
    finally:
        client.close()


@keys.command("revoke")
@click.argument("key_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--environment", default=None, help="Environment name or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def keys_revoke(
    ctx: click.Context,
    key_id: str,
    project: str | None,
    environment: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Revoke an API key."""
    project_slug = resolve_project(ctx, project)
    env = resolve_environment(ctx, environment)
    confirm_destructive(ctx, f"revoke API key {key_id}", confirm)
    client = make_client(ctx)
    try:
        resp = client.delete(
            f"/v1/projects/{project_slug}/environments/{env}/api-keys/{key_id}",
        )
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            fmt = get_format(ctx)
            format_output(
                {"revoked": True, "id": key_id},
                fmt=fmt,
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id,
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()
