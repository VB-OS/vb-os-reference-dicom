"""Organization member management: list, invite, role, suspend, reactivate, remove."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
)


@click.group("members")
def members() -> None:
    """Manage organization members."""


@members.command("list")
@add_pagination_options
@add_output_options
@click.pass_context
def members_list(ctx, limit, cursor, fetch_all, quiet, output_file):
    client = make_client(ctx)
    try:
        path = "/v1/org/members"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@members.command("invite")
@click.option("--email", required=True, help="Email address to invite.")
@click.option("--role", required=True, help="Role to assign.")
@add_output_options
@click.pass_context
def members_invite(ctx, email, role, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.post(
            "/v1/org/members/invite",
            json_body={"email": email, "role": role},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@members.command("role")
@click.argument("member_id")
@click.option("--role", required=True, help="New role.")
@add_output_options
@click.pass_context
def members_role(ctx, member_id, role, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/org/members/{member_id}/role",
            json_body={"role": role},
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@members.command("suspend")
@click.argument("member_id")
@add_output_options
@click.pass_context
def members_suspend(ctx, member_id, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/org/members/{member_id}/suspend", json_body={})
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@members.command("reactivate")
@click.argument("member_id")
@add_output_options
@click.pass_context
def members_reactivate(ctx, member_id, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/org/members/{member_id}/reactivate", json_body={})
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@members.command("remove")
@click.argument("member_id")
@add_confirm_option
@add_output_options
@click.pass_context
def members_remove(ctx, member_id, confirm, quiet, output_file):
    confirm_destructive(ctx, "remove this member", confirm)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/org/members/{member_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": True}, fmt=get_format(ctx), output_file=output_file, quiet=quiet
            )
        else:
            format_output(
                resp.json(),
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id,
            )
    finally:
        client.close()
