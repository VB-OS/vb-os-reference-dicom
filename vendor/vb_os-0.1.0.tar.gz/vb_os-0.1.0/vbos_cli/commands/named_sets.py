"""Named sets commands: list, get, create, update, delete."""

from __future__ import annotations

import json

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("named-sets")
def named_sets() -> None:
    """Manage named sets."""


@named_sets.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def named_sets_list(ctx, project, limit, cursor, fetch_all, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/named-sets"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@named_sets.command("get")
@click.argument("set_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def named_sets_get(ctx, set_id, project, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/named-sets/{set_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@named_sets.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", required=True, help="Named set name.")
@click.option("--items", required=True, type=click.Path(exists=True), help="Items JSON file.")
@add_output_options
@click.pass_context
def named_sets_create(ctx, project, name, items, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    with open(items) as f:
        items_data = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/named-sets",
            json_body={"name": name, "items": items_data},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@named_sets.command("update")
@click.argument("set_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--name", default=None, help="New named set name.")
@click.option(
    "--items", default=None, type=click.Path(exists=True), help="Updated items JSON file."
)
@add_output_options
@click.pass_context
def named_sets_update(ctx, set_id, project, name, items, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    body: dict = {}
    if name:
        body["name"] = name
    if items:
        with open(items) as f:
            body["items"] = json.load(f)
    client = make_client(ctx)
    try:
        resp = client.patch(f"/v1/projects/{project_slug}/named-sets/{set_id}", json_body=body)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@named_sets.command("delete")
@click.argument("set_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def named_sets_delete(ctx, set_id, project, confirm, quiet, output_file):
    project_slug = resolve_project(ctx, project)
    confirm_destructive(ctx, f"delete named set {set_id}", confirm)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_slug}/named-sets/{set_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": set_id},
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id,
            )
        else:
            format_output(
                resp.json(),
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id,
            )
    finally:
        client.close()
