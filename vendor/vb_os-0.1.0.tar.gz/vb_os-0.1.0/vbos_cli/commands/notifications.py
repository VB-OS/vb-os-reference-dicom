"""Notifications: list, read, unread."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    add_pagination_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("notifications")
def notifications() -> None:
    """Manage notifications."""


@notifications.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def notifications_list(
    ctx: click.Context,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        path = f"/v1/projects/{project_slug}/notifications"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@notifications.command("read")
@click.argument("notification_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def notifications_read(
    ctx: click.Context,
    notification_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/notifications/{notification_id}/read"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@notifications.command("unread")
@click.argument("notification_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def notifications_unread(
    ctx: click.Context,
    notification_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.delete(
            f"/v1/projects/{project_slug}/notifications/{notification_id}/read"
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
