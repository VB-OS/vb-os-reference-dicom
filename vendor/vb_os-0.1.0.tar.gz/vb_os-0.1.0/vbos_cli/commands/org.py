"""Organization management: switch-org."""

from __future__ import annotations

import click

from vbos_cli import config as cfg
from vbos_cli.cli import CloudOnlyCommand
from vbos_cli.client import AuthenticatedClient, parse_api_error
from vbos_cli.credentials.store import CredentialStore, SessionCredential
from vbos_cli.errors import CLIError
from vbos_cli.output import print_banner, print_result, stderr


def _fetch_org_list(client: AuthenticatedClient) -> list[dict]:
    """Fetch the user's organizations via authenticated endpoint."""
    resp = client.get("/v1/users/me/organizations")

    if resp.status_code != 200:
        err_code, msg, _ = parse_api_error(resp)
        raise CLIError(f"Failed to retrieve organizations: {msg}", exit_code=2)

    return resp.json()


def _interactive_org_select(orgs: list[dict]) -> str:
    """Display org list and prompt for selection."""
    stderr("Your organizations:")
    for i, org in enumerate(orgs, 1):
        stderr(f"  {i}. {org['org_name']} ({org['org_role']})")

    while True:
        choice = input("Select organization (number): ")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(orgs):
                return orgs[idx]["org_id"]
        except ValueError:
            pass
        stderr(f"Invalid selection. Enter 1-{len(orgs)}.")


@click.command("switch-org", cls=CloudOnlyCommand)
@click.argument("org_id", required=False, default=None)
@click.pass_context
def switch_org(ctx: click.Context, org_id: str | None) -> None:
    """Switch to a different organization.

    If ORG_ID is omitted, lists your organizations and prompts for selection.
    """
    profile = ctx.obj["profile"]
    fmt = ctx.obj["format"]
    api_url = cfg.get_api_url(profile)

    client = AuthenticatedClient(base_url=api_url, profile=profile)
    try:
        if org_id is None:
            orgs = _fetch_org_list(client)
            if len(orgs) <= 1:
                stderr("You belong to a single organization. No switch needed.")
                return
            org_id = _interactive_org_select(orgs)

        resp = client.post("/v1/auth/switch-org", json_body={"org_id": org_id})

        if resp.status_code != 200:
            err_code, msg, _ = parse_api_error(resp)
            raise CLIError(f"Switch org failed: {msg}", exit_code=2)

        data = resp.json()
        store = CredentialStore(profile)
        cred = SessionCredential(
            kind="session",
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )
        store.store(cred)

        print_banner()
        print_result({"switched": True, "org_id": org_id}, fmt)
        stderr(f"Switched to organization {org_id}")
    finally:
        client.close()
