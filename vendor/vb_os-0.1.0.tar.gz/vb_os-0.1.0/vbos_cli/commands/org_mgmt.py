"""Organization management: get, update, settings."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    quiet_id,
)


@click.group("org")
def org() -> None:
    """Manage organization."""


@org.command("get")
@add_output_options
@click.pass_context
def org_get(ctx, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.get("/v1/org")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@org.command("update")
@click.option("--name", required=True, help="Organization name.")
@add_output_options
@click.pass_context
def org_update(ctx, name, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.patch("/v1/org", json_body={"name": name})
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@org.group("settings")
def settings() -> None:
    """Manage organization settings."""


@settings.command("get")
@add_output_options
@click.pass_context
def settings_get(ctx, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.get("/v1/org/settings")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
        )
    finally:
        client.close()


@settings.command("update")
@click.option(
    "--setting",
    multiple=True,
    required=True,
    help="Setting as key=value (repeatable).",
)
@add_output_options
@click.pass_context
def settings_update(ctx, setting, quiet, output_file):
    body: dict = {}
    for pair in setting:
        if "=" not in pair:
            click.echo(f"Invalid setting format: {pair} (expected key=value)", err=True)
            ctx.exit(2)
            return
        key, value = pair.split("=", 1)
        body[key] = value
    client = make_client(ctx)
    try:
        resp = client.put("/v1/org/settings", json_body=body)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
        )
    finally:
        client.close()
