"""Projects commands: create, list, get, update, archive, delete, members."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
)


@click.group("projects")
def projects() -> None:
    """Manage projects."""


@projects.command("create")
@click.option("--name", required=True, help="Project name.")
@click.option("--workspace", required=True, help="Workspace ID.")
@add_output_options
@click.pass_context
def projects_create(
    ctx: click.Context,
    name: str,
    workspace: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a new project."""
    client = make_client(ctx)
    try:
        resp = client.post("/v1/projects", json_body={"name": name, "workspace_id": workspace})
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@projects.command("list")
@add_pagination_options
@add_output_options
@click.pass_context
def projects_list(
    ctx: click.Context,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List projects."""
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = "/v1/projects"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@projects.command("get")
@click.argument("project_id")
@add_output_options
@click.pass_context
def projects_get(
    ctx: click.Context,
    project_id: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get project detail."""
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@projects.command("update")
@click.argument("project_id")
@click.option("--name", required=True, help="New project name.")
@add_output_options
@click.pass_context
def projects_update(
    ctx: click.Context,
    project_id: str,
    name: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update a project."""
    client = make_client(ctx)
    try:
        resp = client.patch(f"/v1/projects/{project_id}", json_body={"name": name})
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@projects.command("archive")
@click.argument("project_id")
@add_output_options
@click.pass_context
def projects_archive(
    ctx: click.Context,
    project_id: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Archive a project."""
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_id}/archive")
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@projects.command("delete")
@click.argument("project_id")
@add_confirm_option
@add_output_options
@click.pass_context
def projects_delete(
    ctx: click.Context,
    project_id: str,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Delete a project."""
    confirm_destructive(ctx, f"delete project {project_id}", confirm)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            fmt = get_format(ctx)
            format_output(
                {"deleted": True, "id": project_id},
                fmt=fmt,
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id,
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()


@projects.group("members")
def members() -> None:
    """Manage project members."""


@members.command("list")
@click.argument("project_id")
@add_pagination_options
@add_output_options
@click.pass_context
def members_list(
    ctx: click.Context,
    project_id: str,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List project members."""
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_id}/members"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@members.command("add")
@click.argument("project_id")
@click.option("--user", required=True, help="User ID to add.")
@click.option("--role", required=True, help="Role to assign.")
@add_output_options
@click.pass_context
def members_add(
    ctx: click.Context,
    project_id: str,
    user: str,
    role: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Add a member to a project."""
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_id}/members",
            json_body={"user_id": user, "role": role},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@members.command("remove")
@click.argument("project_id")
@click.option("--user", required=True, help="User ID to remove.")
@add_confirm_option
@add_output_options
@click.pass_context
def members_remove(
    ctx: click.Context,
    project_id: str,
    user: str,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Remove a member from a project."""
    confirm_destructive(ctx, f"remove user {user} from project {project_id}", confirm)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_id}/members/{user}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            fmt = get_format(ctx)
            format_output(
                {"removed": True, "user_id": user},
                fmt=fmt,
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id,
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()
