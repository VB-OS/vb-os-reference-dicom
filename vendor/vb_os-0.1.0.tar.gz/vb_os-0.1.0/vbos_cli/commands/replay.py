"""Replay command: replay prior evaluations (REQ-A1-148)."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    quiet_id,
    resolve_project,
)


@click.command("replay")
@click.argument("evaluation_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def replay(
    ctx: click.Context,
    evaluation_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Replay a prior evaluation."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/evaluations/{evaluation_id}/replay",
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()
