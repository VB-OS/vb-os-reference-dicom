from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_output_options,
    add_pagination_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("templates")
def templates() -> None:
    """Manage templates."""


@templates.command("list")
@click.option("--domain", default=None, help="Filter by domain.")
@add_pagination_options
@add_output_options
@click.pass_context
def templates_list(
    ctx: click.Context,
    domain: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List public templates."""
    client = make_client(ctx)
    try:
        path = "/v1/templates"
        params: dict = {}
        if domain:
            params["domain"] = domain
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@templates.command("get")
@click.argument("slug")
@add_output_options
@click.pass_context
def templates_get(
    ctx: click.Context,
    slug: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get template detail with versions."""
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/templates/{slug}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
        )
    finally:
        client.close()


@templates.command("fork")
@click.argument("slug")
@click.option("--project", required=True, help="Project slug or ID.")
@click.option("--name", required=True, help="Name for the forked boundary.")
@add_output_options
@click.pass_context
def templates_fork(
    ctx: click.Context,
    slug: str,
    project: str,
    name: str,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Fork template into project."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/templates/{slug}/fork",
            json_body={"project_id": project_slug, "name": name},
        )
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
        )
    finally:
        client.close()
