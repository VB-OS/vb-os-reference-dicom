"""Verify command: submit workloads for evaluation (REQ-A1-148, A1-149, A1-150)."""

from __future__ import annotations

import json
import sys

import click

from vbos_cli.cli import ExecutionMode
from vbos_cli.formatters import (
    add_output_options,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    quiet_verdict,
    resolve_environment,
    resolve_project,
)


@click.command("verify")
@click.option("--project", default=None, help="Target project slug or ID.")
@click.option("--environment", default=None, help="Target environment name or ID.")
@click.option("--boundary", default=None, help="Boundary reference.")
@click.option(
    "--workload",
    required=True,
    type=click.Path(exists=False),
    help="Workload JSON file or - for stdin.",
)
@click.option("--batch", is_flag=True, default=False, help="Batch mode: submit multiple workloads.")
@click.option("--idempotency-key", default=None, help="Idempotency key for safe retries.")
@add_output_options
@click.pass_context
def verify(
    ctx: click.Context,
    project: str | None,
    environment: str | None,
    boundary: str | None,
    workload: str,
    batch: bool,
    idempotency_key: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Submit a workload for evaluation."""
    mode = ctx.find_root().obj.get("mode", ExecutionMode.CLOUD)

    if batch and mode == ExecutionMode.LOCAL:
        click.echo(
            json.dumps(
                {
                    "error": "usage_error",
                    "message": (
                        "--batch and --local are mutually exclusive."
                        " --batch requires --cloud (default)."
                    ),
                }
            ),
            err=True,
        )
        ctx.exit(2)
        return

    if workload == "-":
        workload_data = json.load(sys.stdin)
    else:
        with open(workload) as f:
            workload_data = json.load(f)

    if mode == ExecutionMode.LOCAL:
        _verify_local(ctx, workload_data, boundary, quiet, output_file)
        return

    project_slug = resolve_project(ctx, project)
    environment_name = resolve_environment(ctx, environment)
    client = make_client(ctx)

    try:
        headers: dict[str, str] = {}
        if idempotency_key:
            headers["X-Idempotency-Key"] = idempotency_key

        if batch:
            resp = client.post(
                "/v1/verify/batch",
                json_body={
                    "workloads": workload_data,
                    "project": project_slug,
                    "environment": environment_name,
                },
                headers=headers if headers else None,
            )
        else:
            body: dict = {
                "workload": workload_data,
                "project": project_slug,
                "environment": environment_name,
            }
            if boundary:
                body["boundary_ref"] = boundary
            resp = client.post("/v1/verify", json_body=body, headers=headers if headers else None)

        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return

        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_verdict
        )

        decision = data.get("decision", "")
        if batch:
            decisions = [r.get("decision", "") for r in data.get("results", [])]
            if any(d == "DEFER" for d in decisions):
                ctx.exit(1)
        elif decision == "DEFER":
            ctx.exit(1)

    finally:
        client.close()


def _verify_local(
    ctx: click.Context,
    workload_data: dict,
    boundary: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    from vbos_cli.local_bridge import invoke_local

    try:
        result = invoke_local(workload_data, boundary_ref=boundary)
    except Exception as e:
        click.echo(json.dumps({"error": "local_error", "message": str(e)}), err=True)
        ctx.exit(2)
        return

    fmt = get_format(ctx)
    format_output(
        result, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_verdict
    )

    if result.get("verdict") == "DEFER":
        ctx.exit(1)
