"""Webhooks commands: create, list, get, update, delete, test, rotate-secret, deliveries, retry."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    format_secret,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
    resolve_project,
)


@click.group("webhooks")
def webhooks() -> None:
    """Manage webhooks."""


@webhooks.command("create")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--url", required=True, help="Webhook endpoint URL.")
@click.option("--events", required=True, help="Comma-separated list of event types.")
@click.option("--org", is_flag=True, default=False, help="Create org-scoped webhook.")
@add_output_options
@click.pass_context
def webhooks_create(
    ctx: click.Context,
    project: str | None,
    url: str,
    events: str,
    org: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Create a webhook."""
    event_list = [e.strip() for e in events.split(",") if e.strip()]
    client = make_client(ctx)
    try:
        if org:
            path = "/v1/org/webhooks"
        else:
            project_slug = resolve_project(ctx, project)
            path = f"/v1/projects/{project_slug}/webhooks"
        resp = client.post(path, json={"url": url, "events": event_list})
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@webhooks.command("list")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--org", is_flag=True, default=False, help="List org-scoped webhooks.")
@add_pagination_options
@add_output_options
@click.pass_context
def webhooks_list(
    ctx: click.Context,
    project: str | None,
    org: bool,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List webhooks."""
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        if org:
            path = "/v1/org/webhooks"
        else:
            project_slug = resolve_project(ctx, project)
            path = f"/v1/projects/{project_slug}/webhooks"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@webhooks.command("get")
@click.argument("webhook_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def webhooks_get(
    ctx: click.Context,
    webhook_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Get webhook detail."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/projects/{project_slug}/webhooks/{webhook_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@webhooks.command("update")
@click.argument("webhook_id")
@click.option("--project", default=None, help="Project slug or ID.")
@click.option("--url", default=None, help="Webhook endpoint URL.")
@click.option("--events", default=None, help="Comma-separated list of event types.")
@add_output_options
@click.pass_context
def webhooks_update(
    ctx: click.Context,
    webhook_id: str,
    project: str | None,
    url: str | None,
    events: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Update a webhook."""
    project_slug = resolve_project(ctx, project)
    payload: dict = {}
    if url:
        payload["url"] = url
    if events:
        payload["events"] = [e.strip() for e in events.split(",") if e.strip()]
    client = make_client(ctx)
    try:
        resp = client.patch(
            f"/v1/projects/{project_slug}/webhooks/{webhook_id}",
            json=payload,
        )
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@webhooks.command("delete")
@click.argument("webhook_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_confirm_option
@add_output_options
@click.pass_context
def webhooks_delete(
    ctx: click.Context,
    webhook_id: str,
    project: str | None,
    confirm: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Delete a webhook."""
    confirm_destructive(ctx, "delete this webhook", confirm)
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.delete(f"/v1/projects/{project_slug}/webhooks/{webhook_id}")
        if resp.status_code not in (200, 204):
            handle_api_error(resp, ctx)
            return
        if resp.status_code == 204:
            format_output(
                {"deleted": True}, fmt=get_format(ctx), output_file=output_file, quiet=quiet
            )
        else:
            data = resp.json()
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id
            )
    finally:
        client.close()


@webhooks.command("test")
@click.argument("webhook_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def webhooks_test(
    ctx: click.Context,
    webhook_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Send a test event to a webhook."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/webhooks/{webhook_id}/test")
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()


@webhooks.command("rotate-secret")
@click.argument("webhook_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def webhooks_rotate_secret(
    ctx: click.Context,
    webhook_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Rotate the signing secret for a webhook."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/projects/{project_slug}/webhooks/{webhook_id}/rotate-secret")
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_secret(
            data, secret_key="signing_secret", output_file=output_file, quiet=quiet, fmt=fmt
        )
    finally:
        client.close()


@webhooks.command("deliveries")
@click.argument("webhook_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_pagination_options
@add_output_options
@click.pass_context
def webhooks_deliveries(
    ctx: click.Context,
    webhook_id: str,
    project: str | None,
    limit: int | None,
    cursor: str | None,
    fetch_all: bool,
    quiet: bool,
    output_file: str | None,
) -> None:
    """List deliveries for a webhook."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor

        path = f"/v1/projects/{project_slug}/webhooks/{webhook_id}/deliveries"

        if fetch_all:
            data = paginate_all(client, path, params)
            fmt = get_format(ctx)
            format_output(
                data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
            )
            return

        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(
            data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id_list
        )
    finally:
        client.close()


@webhooks.command("retry")
@click.argument("webhook_id")
@click.argument("delivery_id")
@click.option("--project", default=None, help="Project slug or ID.")
@add_output_options
@click.pass_context
def webhooks_retry(
    ctx: click.Context,
    webhook_id: str,
    delivery_id: str,
    project: str | None,
    quiet: bool,
    output_file: str | None,
) -> None:
    """Retry a webhook delivery."""
    project_slug = resolve_project(ctx, project)
    client = make_client(ctx)
    try:
        resp = client.post(
            f"/v1/projects/{project_slug}/webhooks/{webhook_id}/deliveries/{delivery_id}/retry",
        )
        if resp.status_code not in (200, 201, 202):
            handle_api_error(resp, ctx)
            return
        data = resp.json()
        fmt = get_format(ctx)
        format_output(data, fmt=fmt, output_file=output_file, quiet=quiet, quiet_extractor=quiet_id)
    finally:
        client.close()
