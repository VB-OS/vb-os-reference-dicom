"""Workspace management: list, get, create, update, archive."""

from __future__ import annotations

import click

from vbos_cli.formatters import (
    add_confirm_option,
    add_output_options,
    add_pagination_options,
    confirm_destructive,
    format_output,
    get_format,
    handle_api_error,
    make_client,
    paginate_all,
    quiet_id,
    quiet_id_list,
)


@click.group("workspaces")
def workspaces() -> None:
    """Manage organization workspaces."""


@workspaces.command("list")
@add_pagination_options
@add_output_options
@click.pass_context
def workspaces_list(ctx, limit, cursor, fetch_all, quiet, output_file):
    client = make_client(ctx)
    try:
        path = "/v1/organizations/current/workspaces"
        params: dict = {}
        if limit:
            params["limit"] = limit
        if cursor:
            params["cursor"] = cursor
        if fetch_all:
            data = paginate_all(client, path, params)
            format_output(
                data,
                fmt=get_format(ctx),
                output_file=output_file,
                quiet=quiet,
                quiet_extractor=quiet_id_list,
            )
            return
        resp = client.get(path, params=params)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id_list,
        )
    finally:
        client.close()


@workspaces.command("get")
@click.argument("workspace_id")
@add_output_options
@click.pass_context
def workspaces_get(ctx, workspace_id, quiet, output_file):
    client = make_client(ctx)
    try:
        resp = client.get(f"/v1/organizations/current/workspaces/{workspace_id}")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@workspaces.command("create")
@click.option("--name", required=True, help="Workspace name.")
@click.option("--description", default=None, help="Workspace description.")
@add_output_options
@click.pass_context
def workspaces_create(ctx, name, description, quiet, output_file):
    body: dict = {"name": name}
    if description:
        body["description"] = description
    client = make_client(ctx)
    try:
        resp = client.post("/v1/organizations/current/workspaces", json_body=body)
        if resp.status_code not in (200, 201):
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@workspaces.command("update")
@click.argument("workspace_id")
@click.option("--name", default=None, help="New workspace name.")
@click.option("--description", default=None, help="New workspace description.")
@add_output_options
@click.pass_context
def workspaces_update(ctx, workspace_id, name, description, quiet, output_file):
    body: dict = {}
    if name:
        body["name"] = name
    if description:
        body["description"] = description
    client = make_client(ctx)
    try:
        resp = client.patch(f"/v1/organizations/current/workspaces/{workspace_id}", json_body=body)
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()


@workspaces.command("archive")
@click.argument("workspace_id")
@add_confirm_option
@add_output_options
@click.pass_context
def workspaces_archive(ctx, workspace_id, confirm, quiet, output_file):
    confirm_destructive(ctx, "archive this workspace", confirm)
    client = make_client(ctx)
    try:
        resp = client.post(f"/v1/organizations/current/workspaces/{workspace_id}/archive")
        if resp.status_code != 200:
            handle_api_error(resp, ctx)
            return
        format_output(
            resp.json(),
            fmt=get_format(ctx),
            output_file=output_file,
            quiet=quiet,
            quiet_extractor=quiet_id,
        )
    finally:
        client.close()
