"""Config file management at ~/.vbos/config (TOML format, profile-scoped)."""

from __future__ import annotations

import os
import stat
import sys
import tempfile
import tomllib
from pathlib import Path
from typing import Any

import tomli_w

VBOS_DIR = Path.home() / ".vbos"
CONFIG_PATH = VBOS_DIR / "config"

VALID_KEYS = frozenset(
    {
        "default-project",
        "default-environment",
        "default-org",
        "credential-store",
        "api-url",
        "email",
    }
)

DEFAULT_API_URL = "https://api.vb-os.org"


def _ensure_dir() -> None:
    VBOS_DIR.mkdir(mode=0o700, exist_ok=True)


def _read_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    with CONFIG_PATH.open("rb") as f:
        return tomllib.load(f)


def _write_config(data: dict[str, Any]) -> None:
    """Atomic write: temp file (0600) -> fsync -> rename."""
    _ensure_dir()
    fd, tmp_path = tempfile.mkstemp(dir=str(VBOS_DIR), prefix=".config_tmp_")
    try:
        if sys.platform != "win32":
            os.fchmod(fd, stat.S_IRUSR | stat.S_IWUSR)
        content = tomli_w.dumps(data).encode()
        os.write(fd, content)
        os.fsync(fd)
        os.close(fd)
        fd = -1
        os.replace(tmp_path, str(CONFIG_PATH))
    finally:
        if fd >= 0:
            os.close(fd)
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def _profile_key(profile: str) -> str:
    return f"profile.{profile}"


def get_value(key: str, profile: str = "default") -> Any:
    data = _read_config()
    section = data.get(_profile_key(profile), {})
    return section.get(key)


def set_value(key: str, value: str, profile: str = "default") -> None:
    if key not in VALID_KEYS:
        msg = f"Unknown config key: {key}. Valid keys: {', '.join(sorted(VALID_KEYS))}"
        raise ValueError(msg)
    data = _read_config()
    pk = _profile_key(profile)
    if pk not in data:
        data[pk] = {}
    data[pk][key] = value
    _write_config(data)


def list_values(profile: str = "default") -> dict[str, Any]:
    data = _read_config()
    return dict(data.get(_profile_key(profile), {}))


def get_api_url(profile: str = "default") -> str:
    return get_value("api-url", profile) or DEFAULT_API_URL


def get_email(profile: str = "default") -> str | None:
    return get_value("email", profile)


def get_credential_store_type(profile: str = "default") -> str | None:
    return get_value("credential-store", profile)
