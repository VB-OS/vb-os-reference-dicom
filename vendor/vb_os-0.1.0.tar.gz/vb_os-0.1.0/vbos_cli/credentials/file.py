"""Encrypted file-based credential store (REQ-C1-043).

PBKDF2-HMAC-SHA256 (600k iterations) → Fernet (AES-128-CBC + HMAC-SHA256).
Stored at ~/.vbos/credentials with 0600 permissions.
"""

from __future__ import annotations

import base64
import getpass
import hashlib
import json
import os
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any

from vbos_cli.errors import CredentialStoreError

VBOS_DIR = Path.home() / ".vbos"
CREDENTIALS_PATH = VBOS_DIR / "credentials"
FILE_VERSION = b"v1"
SALT_LENGTH = 16
PBKDF2_ITERATIONS = 600_000


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    """Derive a Fernet-compatible key from passphrase + salt."""
    dk = hashlib.pbkdf2_hmac("sha256", passphrase.encode(), salt, PBKDF2_ITERATIONS, dklen=32)
    return base64.urlsafe_b64encode(dk)


def _prompt_passphrase(confirm: bool = False) -> str:
    pp = getpass.getpass("Credential store passphrase: ", stream=sys.stderr)
    if not pp:
        raise CredentialStoreError("Passphrase cannot be empty.")
    if confirm:
        pp2 = getpass.getpass("Confirm passphrase: ", stream=sys.stderr)
        if pp != pp2:
            raise CredentialStoreError("Passphrases do not match.")
    return pp


class FileStore:
    """Profile-aware encrypted file store. Single file, profile sections inside."""

    def __init__(self, profile: str = "default") -> None:
        self._profile = profile

    def _read_all(self, passphrase: str) -> dict[str, Any]:
        """Read and decrypt the entire credentials file, returning all profiles."""
        from cryptography.fernet import Fernet, InvalidToken

        if not CREDENTIALS_PATH.exists():
            return {}

        raw = CREDENTIALS_PATH.read_bytes()
        if len(raw) < len(FILE_VERSION) + SALT_LENGTH + 1:
            raise CredentialStoreError("Credentials file is corrupted or truncated.")

        version = raw[: len(FILE_VERSION)]
        if version != FILE_VERSION:
            raise CredentialStoreError(f"Unsupported credentials file version: {version!r}")

        salt = raw[len(FILE_VERSION) : len(FILE_VERSION) + SALT_LENGTH]
        ciphertext = raw[len(FILE_VERSION) + SALT_LENGTH :]

        key = _derive_key(passphrase, salt)
        try:
            plaintext = Fernet(key).decrypt(ciphertext)
        except InvalidToken:
            raise CredentialStoreError(
                "Wrong passphrase or corrupted credentials file. "
                "If you forgot your passphrase, run `vbos login` to re-authenticate."
            ) from None

        return json.loads(plaintext)

    def _write_all(self, data: dict[str, Any], passphrase: str, salt: bytes | None = None) -> None:
        """Encrypt and atomically write all profile credentials."""
        from cryptography.fernet import Fernet

        VBOS_DIR.mkdir(mode=0o700, exist_ok=True)

        if salt is None:
            salt = os.urandom(SALT_LENGTH)

        key = _derive_key(passphrase, salt)
        plaintext = json.dumps(data).encode()
        ciphertext = Fernet(key).encrypt(plaintext)

        payload = FILE_VERSION + salt + ciphertext

        fd, tmp_path = tempfile.mkstemp(dir=str(VBOS_DIR), prefix=".cred_tmp_")
        try:
            if sys.platform != "win32":
                os.fchmod(fd, stat.S_IRUSR | stat.S_IWUSR)
            os.write(fd, payload)
            os.fsync(fd)
            os.close(fd)
            fd = -1
            os.replace(tmp_path, str(CREDENTIALS_PATH))
        finally:
            if fd >= 0:
                os.close(fd)
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    def write(self, data: str) -> None:
        if CREDENTIALS_PATH.exists():
            pp = _prompt_passphrase(confirm=False)
            all_data = self._read_all(pp)
        else:
            pp = _prompt_passphrase(confirm=True)
            all_data = {}

        all_data[self._profile] = json.loads(data)
        self._write_all(all_data, pp)

    def read(self) -> str | None:
        if not CREDENTIALS_PATH.exists():
            return None
        pp = _prompt_passphrase(confirm=False)
        all_data = self._read_all(pp)
        profile_data = all_data.get(self._profile)
        if profile_data is None:
            return None
        return json.dumps(profile_data)

    def delete(self) -> None:
        if not CREDENTIALS_PATH.exists():
            return
        pp = _prompt_passphrase(confirm=False)
        all_data = self._read_all(pp)
        all_data.pop(self._profile, None)
        if all_data:
            self._write_all(all_data, pp)
        else:
            CREDENTIALS_PATH.unlink(missing_ok=True)
