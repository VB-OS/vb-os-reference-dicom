"""OS keychain backend using the ``keyring`` library (REQ-C1-041)."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

SERVICE_PREFIX = "vbos-cli"

_SUPPORTED_BACKENDS = (
    "keyring.backends.macOS.Keyring",
    "keyring.backends.Windows.WinVaultKeyring",
    "keyring.backends.SecretService.Keyring",
)


def _get_backend_class_name() -> str:
    try:
        import keyring

        backend = keyring.get_keyring()
        return type(backend).__module__ + "." + type(backend).__qualname__
    except Exception:
        return ""


def is_supported_backend() -> bool:
    name = _get_backend_class_name()
    return any(name.endswith(s) or s in name for s in _SUPPORTED_BACKENDS)


class KeychainStore:
    def __init__(self, profile: str = "default") -> None:
        self._service = f"{SERVICE_PREFIX}/{profile}"
        self._username = "credentials"

    def write(self, data: str) -> None:
        import keyring

        keyring.set_password(self._service, self._username, data)

    def read(self) -> str | None:
        import keyring

        return keyring.get_password(self._service, self._username)

    def delete(self) -> None:
        import keyring

        try:
            keyring.delete_password(self._service, self._username)
        except keyring.errors.PasswordDeleteError:
            pass
