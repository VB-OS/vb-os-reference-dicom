"""Credential store migration: keychain <-> file (REQ-C1-042)."""

from __future__ import annotations

from vbos_cli.credentials.file import FileStore
from vbos_cli.credentials.keychain import KeychainStore
from vbos_cli.errors import CredentialStoreError
from vbos_cli.output import stderr


def migrate_credentials(
    source: KeychainStore | FileStore,
    destination: KeychainStore | FileStore,
) -> None:
    """Read → write → verify → delete old. Failure preserves the original."""
    raw = source.read()
    if raw is None:
        stderr("No credentials to migrate.")
        return

    destination.write(raw)

    readback = destination.read()
    if readback != raw:
        raise CredentialStoreError(
            "Migration verification failed: destination data does not match source. "
            "Original credentials preserved."
        )

    try:
        source.delete()
    except Exception:
        stderr(
            "WARNING: Credentials were migrated successfully but the old store "
            "could not be cleaned up. The new store is now authoritative. "
            "Manually remove the old credential data to avoid retaining a stale copy."
        )
        return
    stderr("Credentials migrated successfully.")
