"""CredentialStore abstraction with backend auto-detection and validation."""

from __future__ import annotations

import json
from dataclasses import dataclass

from vbos_cli import config as cfg
from vbos_cli.credentials.file import FileStore
from vbos_cli.credentials.keychain import KeychainStore, is_supported_backend
from vbos_cli.errors import CredentialStoreError


@dataclass
class SessionCredential:
    kind: str  # "session"
    access_token: str
    refresh_token: str


@dataclass
class APIKeyCredential:
    kind: str  # "api_key"
    api_key: str


Credential = SessionCredential | APIKeyCredential


def credential_to_dict(cred: Credential) -> dict[str, str]:
    if isinstance(cred, SessionCredential):
        return {
            "kind": "session",
            "access_token": cred.access_token,
            "refresh_token": cred.refresh_token,
        }
    return {"kind": "api_key", "api_key": cred.api_key}


def credential_from_dict(data: dict[str, str]) -> Credential:
    kind = data.get("kind", "")
    if kind == "session":
        return SessionCredential(
            kind="session",
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )
    if kind == "api_key":
        return APIKeyCredential(kind="api_key", api_key=data["api_key"])
    msg = f"Unknown credential kind: {kind}"
    raise CredentialStoreError(msg)


class CredentialStore:
    """Unified interface over keychain and file backends."""

    def __init__(self, profile: str = "default") -> None:
        self._profile = profile
        self._backend: KeychainStore | FileStore | None = None

    def _resolve_backend(self) -> KeychainStore | FileStore:
        if self._backend is not None:
            return self._backend

        store_type = cfg.get_credential_store_type(self._profile)

        if store_type == "file":
            self._backend = FileStore(self._profile)
            return self._backend

        if store_type == "keychain" or store_type is None:
            if is_supported_backend():
                self._backend = KeychainStore(self._profile)
                return self._backend

        if store_type is None:
            raise CredentialStoreError(
                "No credential store available. Run "
                "`vbos config set credential-store file` to configure "
                "file-based storage."
            )

        msg = f"Unknown credential-store type: {store_type}"
        raise CredentialStoreError(msg)

    def store(self, credential: Credential) -> None:
        backend = self._resolve_backend()
        data = json.dumps(credential_to_dict(credential))
        backend.write(data)

    def load(self) -> Credential | None:
        backend = self._resolve_backend()
        raw = backend.read()
        if raw is None:
            return None
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, KeyError) as e:
            msg = f"Corrupted credential data: {e}"
            raise CredentialStoreError(msg) from e
        return credential_from_dict(data)

    def delete(self) -> None:
        backend = self._resolve_backend()
        backend.delete()

    def exists(self) -> bool:
        backend = self._resolve_backend()
        return backend.read() is not None


def resolve_credential(profile: str = "default") -> Credential | None:
    """Resolve credential: VBOS_API_KEY env var > stored credentials."""
    import os

    api_key = os.environ.get("VBOS_API_KEY")
    if api_key:
        return APIKeyCredential(kind="api_key", api_key=api_key)

    try:
        store = CredentialStore(profile)
        return store.load()
    except CredentialStoreError:
        return None
