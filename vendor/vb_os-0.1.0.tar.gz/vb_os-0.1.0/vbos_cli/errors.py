"""Typed CLI error classes."""

from __future__ import annotations


class CLIError(Exception):
    """Base CLI error with exit code."""

    def __init__(self, message: str, exit_code: int = 1) -> None:
        super().__init__(message)
        self.exit_code = exit_code


class AuthenticationError(CLIError):
    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message, exit_code=2)


class CredentialStoreError(CLIError):
    def __init__(self, message: str) -> None:
        super().__init__(message, exit_code=2)


class UnsupportedInLocalModeError(CLIError):
    def __init__(self) -> None:
        super().__init__(
            "Authentication commands require --cloud mode. "
            "Local SRB execution does not use VB-OS Cloud credentials.",
            exit_code=2,
        )


class SessionExpiredError(AuthenticationError):
    def __init__(self) -> None:
        super().__init__("Session expired. Run `vbos login` to re-authenticate.")


class APIKeyInvalidError(AuthenticationError):
    def __init__(self) -> None:
        super().__init__("API key is invalid or revoked.")
