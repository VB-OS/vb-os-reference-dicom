"""Output formatting for CLI commands: JSON, table, quiet modes with --output file support."""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

import click

from vbos_cli.output import print_table


def _atomic_write(path: str, content: str, permissions: int = 0o600) -> None:
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=str(dest.parent), prefix=".vbos_out_")
    try:
        if sys.platform != "win32":
            os.fchmod(fd, permissions)
        os.write(fd, content.encode())
        os.fsync(fd)
        os.close(fd)
        fd = -1
        os.replace(tmp_path, str(dest))
    finally:
        if fd >= 0:
            os.close(fd)
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def format_output(
    data: Any,
    fmt: str = "json",
    output_file: str | None = None,
    quiet: bool = False,
    quiet_extractor: Any | None = None,
) -> None:
    if quiet and quiet_extractor is not None:
        text = quiet_extractor(data)
        if output_file:
            _atomic_write(output_file, text + "\n")
        else:
            click.echo(text)
        return

    if fmt == "json":
        content = json.dumps(data, indent=2, default=str)
    elif fmt == "table":
        if isinstance(data, list):
            if not data:
                click.echo("No results.")
                return
            print_table(data)
            return
        elif isinstance(data, dict):
            print_table([data])
            return
        else:
            content = str(data)
    else:
        content = json.dumps(data, indent=2, default=str)

    if output_file:
        _atomic_write(output_file, content + "\n")
        click.echo(f"Output written to {output_file}", err=True)
    else:
        click.echo(content)


def format_secret(
    data: dict[str, Any],
    secret_key: str,
    output_file: str | None = None,
    quiet: bool = False,
    fmt: str = "json",
) -> None:
    if quiet:
        secret = data.get(secret_key, "")
        if output_file:
            _atomic_write(output_file, str(secret) + "\n")
        else:
            click.echo(secret)
        return

    if output_file:
        content = json.dumps(data, indent=2, default=str)
        _atomic_write(output_file, content + "\n")
        click.echo(f"Output written to {output_file}", err=True)
    else:
        content = json.dumps(data, indent=2, default=str)
        click.echo(content)


def format_artifact_download(
    file_path: str,
    quiet: bool = False,
) -> None:
    if quiet:
        click.echo(file_path)
    else:
        click.echo(f"Downloaded to {file_path}", err=True)


def quiet_id(data: Any) -> str:
    if isinstance(data, dict):
        for key in ("id", "uuid", "key_id", "run_id", "rule_id"):
            if key in data:
                return str(data[key])
    return json.dumps(data, default=str)


def quiet_id_list(data: Any) -> str:
    if isinstance(data, list):
        return "\n".join(quiet_id(item) for item in data)
    if isinstance(data, dict) and "items" in data:
        return "\n".join(quiet_id(item) for item in data["items"])
    return quiet_id(data)


def quiet_verdict(data: Any) -> str:
    if isinstance(data, dict):
        return str(data.get("decision", data.get("verdict", "")))
    return str(data)


def handle_api_error(resp: Any, ctx: click.Context) -> None:
    from vbos_cli.client import parse_api_error

    error_code, message, request_id = parse_api_error(resp)

    if resp.status_code == 401:
        message = "Session expired. Run `vbos login` to re-authenticate."
    elif resp.status_code == 403:
        message = f"Permission denied: {message}"
    elif resp.status_code == 404:
        message = f"Not found: {message}"
    elif resp.status_code == 409:
        message = f"Conflict: {message}"
    elif resp.status_code == 422:
        message = f"Validation error: {message}"
    elif resp.status_code == 429:
        retry_after = resp.headers.get("retry-after", "unknown")
        message = f"Rate limited. Retry after {retry_after}s."

    err: dict[str, Any] = {"error": error_code, "message": message}
    if request_id:
        err["request_id"] = request_id

    click.echo(json.dumps(err, indent=2), err=True)
    ctx.exit(2)


def add_output_options(func: Any) -> Any:
    func = click.option("--quiet", "-q", is_flag=True, default=False, help="Minimal output.")(func)
    func = click.option("--output", "output_file", default=None, help="Write output to file.")(func)
    return func


def add_pagination_options(func: Any) -> Any:
    func = click.option("--limit", default=None, type=int, help="Max results per page.")(func)
    func = click.option("--cursor", default=None, help="Pagination cursor.")(func)
    func = click.option(
        "--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate all results."
    )(func)
    return func


def add_confirm_option(func: Any) -> Any:
    func = click.option("--confirm", is_flag=True, default=False, help="Skip confirmation prompt.")(
        func
    )
    return func


def confirm_destructive(ctx: click.Context, action: str, confirm: bool) -> None:
    if confirm:
        return
    if not sys.stdin.isatty():
        click.echo(
            json.dumps(
                {
                    "error": "confirmation_required",
                    "message": f"Pass --confirm to {action} in non-interactive mode.",
                }
            ),
            err=True,
        )
        ctx.exit(2)
        return
    if not click.confirm(f"Are you sure you want to {action}?", err=True):
        click.echo(json.dumps({"error": "aborted", "message": "Operation cancelled."}), err=True)
        ctx.exit(2)


def paginate_all(
    client: Any,
    path: str,
    params: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    all_items: list[dict[str, Any]] = []
    seen_cursors: set[str] = set()
    query_params = dict(params or {})

    while True:
        resp = client.get(path, params=query_params)
        if resp.status_code != 200:
            return all_items

        data = resp.json()
        items = data.get("items", data if isinstance(data, list) else [])
        all_items.extend(items)

        next_cursor = data.get("next_cursor") or data.get("cursor")
        if not next_cursor or next_cursor in seen_cursors:
            break
        seen_cursors.add(next_cursor)
        query_params["cursor"] = next_cursor

    return all_items


def make_client(ctx: click.Context) -> Any:
    from vbos_cli import config as cfg
    from vbos_cli.client import AuthenticatedClient

    profile = ctx.find_root().obj["profile"]
    api_url = cfg.get_api_url(profile)
    return AuthenticatedClient(base_url=api_url, profile=profile)


def resolve_project(ctx: click.Context, project: str | None) -> str:
    if project:
        return project
    from vbos_cli import config as cfg

    profile = ctx.find_root().obj["profile"]
    default = cfg.get_value("default-project", profile)
    if default:
        return default
    click.echo(
        json.dumps(
            {
                "error": "missing_project",
                "message": (
                    "No project specified. Use --project or run:"
                    " vbos config set default-project <slug>"
                ),
            }
        ),
        err=True,
    )
    ctx.exit(2)
    raise SystemExit(2)


def resolve_environment(ctx: click.Context, environment: str | None) -> str:
    if environment:
        return environment
    from vbos_cli import config as cfg

    profile = ctx.find_root().obj["profile"]
    default = cfg.get_value("default-environment", profile)
    if default:
        return default
    click.echo(
        json.dumps(
            {
                "error": "missing_environment",
                "message": (
                    "No environment specified. Use --environment"
                    " or run: vbos config set"
                    " default-environment <name>"
                ),
            }
        ),
        err=True,
    )
    ctx.exit(2)
    raise SystemExit(2)


def get_format(ctx: click.Context) -> str:
    return ctx.find_root().obj.get("format", "json")
