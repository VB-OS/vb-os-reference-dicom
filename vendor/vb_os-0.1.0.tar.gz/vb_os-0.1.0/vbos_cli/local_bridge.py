"""Local binary bridge: invoke vb-os binary for --local evaluation."""

from __future__ import annotations

import json
import os
import shutil
import struct
import subprocess
import tempfile
from typing import Any

BINARY_NAME = "vb-os"
DEFAULT_BINARY_PATH = "/opt/vbos/bin/vb-os"
DEFAULT_INSTALL_PATH = "/opt/vbos/current"
BUNDLE_MAGIC = b"VBOSRRE\x01"
FORMAT_VERSION = 1
CANONICAL_TOOLCHAIN_ID = bytes.fromhex(
    "a0b71f82e3d94c6a8f2b1e7d5c3a9f0e4b2d8a6c1e7f3b5d9a0c2e4f6b8d1a3e"
)
DEFAULT_BOUNDARY_REF = b"0" * 63 + b"1"
DEFAULT_TIMEOUT = 30
ENGINE_DECISION_MAP = {"ACCEPT": "ASSERT", "REJECT": "DEFER"}


def _find_binary() -> str:
    path = shutil.which(BINARY_NAME)
    if path:
        return path
    if os.path.isfile(DEFAULT_BINARY_PATH) and os.access(DEFAULT_BINARY_PATH, os.X_OK):
        return DEFAULT_BINARY_PATH
    raise FileNotFoundError(
        f"vb-os binary not found on PATH or {DEFAULT_BINARY_PATH}. "
        "Install the VB-OS reference deployment binary."
    )


def _verify_install(binary_path: str) -> None:
    try:
        proc = subprocess.run(
            [binary_path, "verify-install", "--install-path", DEFAULT_INSTALL_PATH],
            capture_output=True,
            shell=False,
            timeout=DEFAULT_TIMEOUT,
        )
        if proc.returncode != 0:
            stderr_text = proc.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(f"Binary integrity verification failed: {stderr_text}")
    except FileNotFoundError:
        raise RuntimeError("Binary integrity verification failed: verify-install not available")


def _build_a_input_001(workload_bytes: bytes, boundary_ref: bytes | None = None) -> bytes:
    ref = boundary_ref or DEFAULT_BOUNDARY_REF
    if len(ref) != 64:
        ref = ref.ljust(64, b"0")
    return (
        BUNDLE_MAGIC
        + struct.pack("B", FORMAT_VERSION)
        + CANONICAL_TOOLCHAIN_ID
        + ref
        + struct.pack("<Q", len(workload_bytes))
        + workload_bytes
    )


def _to_binary_dsl(dsl: str) -> str:
    lines = []
    for line in dsl.splitlines():
        stripped = line.strip()
        if stripped.startswith("require_type:"):
            continue
        line = line.replace("=>", ":")
        lines.append(line)

    result = "\n".join(lines)

    has_boundary_block = "BOUNDARY" in result and "{" in result
    if not has_boundary_block:
        content_lines = [
            line for line in lines
            if line.strip() and not line.strip().startswith(("#", "//"))
        ]
        expr_lines = [
            line
            for line in content_lines
            if not any(
                line.strip().startswith(k)
                for k in (
                    "require_evidence:",
                    "prohibit_evidence:",
                    "predicate:",
                    "require_provenance:",
                    "eta_cap:",
                    "boundary_id:",
                    "version:",
                    "scope:",
                )
            )
        ]
        if expr_lines:
            bare_expr = " ".join(line.strip() for line in expr_lines)
            non_expr = [line for line in lines if line not in expr_lines]
            result = "\n".join(non_expr) + f"\nBOUNDARY {{ {bare_expr} }}\n"

    return result


def _parse_audit_parity(audit: dict[str, Any]) -> dict[str, Any]:
    parity: dict[str, Any] = {}

    admissibility = audit.get("admissibility_check")
    if admissibility is not None:
        parity["admissibility"] = admissibility

    prohibitions = audit.get("prohibition_check")
    if prohibitions is not None:
        parity["prohibitions"] = prohibitions

    predicate_results = audit.get("predicate_results")
    if predicate_results is not None:
        parity["predicate_outcomes"] = [
            {
                "name": p.get("name"),
                "field": p.get("field"),
                "op": p.get("op"),
                "passed": p.get("passed"),
                "actual_value": p.get("actual_value"),
            }
            for p in predicate_results
        ]

    return parity


def invoke_local(
    workload: dict[str, Any],
    boundary_ref: str | None = None,
    boundary_dsl: str | None = None,
) -> dict[str, Any]:
    binary_path = _find_binary()

    try:
        _verify_install(binary_path)
    except RuntimeError as e:
        raise RuntimeError(str(e)) from None

    workload_bytes = json.dumps(workload, separators=(",", ":")).encode("utf-8")
    ref_bytes = boundary_ref.encode("ascii") if boundary_ref else None
    bundle = _build_a_input_001(workload_bytes, ref_bytes)

    tmp_dir = tempfile.mkdtemp(prefix="vbos_local_")
    try:
        input_path = os.path.join(tmp_dir, "input.bundle")
        output_path = os.path.join(tmp_dir, "output.json")
        audit_path = os.path.join(tmp_dir, "audit.json")

        with open(input_path, "wb") as f:
            f.write(bundle)

        cmd = [
            binary_path,
            "run",
            "--input",
            input_path,
            "--output",
            output_path,
            "--audit",
            audit_path,
        ]

        if boundary_dsl:
            boundary_path = os.path.join(tmp_dir, "boundary.vbos")
            converted = _to_binary_dsl(boundary_dsl)
            with open(boundary_path, "w") as f:
                f.write(converted)
            cmd.extend(["--boundary", boundary_path])

        proc = subprocess.run(
            cmd,
            capture_output=True,
            shell=False,
            timeout=DEFAULT_TIMEOUT,
        )

        if proc.returncode != 0:
            stderr_text = proc.stderr.decode("utf-8", errors="replace").strip()
            try:
                failure = json.loads(stderr_text)
                raise RuntimeError(
                    f"Binary evaluation failed: {failure.get('code', 'unknown')} — "
                    f"{failure.get('message', stderr_text)}"
                )
            except json.JSONDecodeError:
                raise RuntimeError(
                    f"Binary evaluation failed (exit {proc.returncode}): {stderr_text}"
                )

        with open(output_path) as f:
            derived = json.load(f)

        engine_decision = derived.get("decision", "")
        verdict = ENGINE_DECISION_MAP.get(engine_decision, engine_decision)
        reason = derived.get("reason", "")

        result: dict[str, Any] = {
            "verdict": verdict,
            "decision": verdict,
            "reason": reason,
        }

        if os.path.exists(audit_path):
            with open(audit_path) as f:
                audit = json.load(f)
            parity = _parse_audit_parity(audit)
            result.update(parity)
            result["local_metadata"] = {
                "binary_path": binary_path,
                "audit_artifact_path": audit_path,
                "engine_decision": engine_decision,
            }
        else:
            result["local_metadata"] = {
                "binary_path": binary_path,
                "engine_decision": engine_decision,
            }

        return result

    finally:
        import shutil as _shutil

        _shutil.rmtree(tmp_dir, ignore_errors=True)
