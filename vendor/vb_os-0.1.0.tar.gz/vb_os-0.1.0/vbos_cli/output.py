"""Output formatting: JSON (default) and table."""

from __future__ import annotations

import json
import sys
from typing import Any


def print_json(data: Any, file: Any = None) -> None:
    """Print data as JSON to stdout (default) or specified file."""
    json.dump(data, file or sys.stdout, indent=2, default=str)
    print(file=file or sys.stdout)


def print_table(rows: list[dict[str, Any]], columns: list[str] | None = None) -> None:
    """Print data as a human-readable table to stdout."""
    if not rows:
        return
    cols = columns or list(rows[0].keys())
    widths = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) for c in cols}

    header = "  ".join(c.upper().ljust(widths[c]) for c in cols)
    separator = "  ".join("-" * widths[c] for c in cols)
    print(header)
    print(separator)
    for row in rows:
        line = "  ".join(str(row.get(c, "")).ljust(widths[c]) for c in cols)
        print(line)


def print_result(data: Any, fmt: str = "json") -> None:
    """Print command result in the requested format."""
    if fmt == "table" and isinstance(data, list):
        print_table(data)
    elif fmt == "table" and isinstance(data, dict):
        print_table([data])
    else:
        print_json(data)


def print_error(error: str, message: str, request_id: str | None = None) -> None:
    """Print structured error to stderr."""
    err: dict[str, Any] = {"error": error, "message": message}
    if request_id:
        err["request_id"] = request_id
    print_json(err, file=sys.stderr)


def stderr(msg: str) -> None:
    """Print human-readable message to stderr."""
    print(msg, file=sys.stderr)


_LOGO = """\
\033[38;2;0;212;170m██╗   ██╗██████╗        ██████╗ ███████╗
██║   ██║██╔══██╗      ██╔═══██╗██╔════╝
██║   ██║██████╔╝█████╗██║   ██║███████╗
╚██╗ ██╔╝██╔══██╗╚════╝██║   ██║╚════██║
 ╚████╔╝ ██████╔╝      ╚██████╔╝███████║
  ╚═══╝  ╚═════╝        ╚═════╝ ╚══════╝\033[0m"""


def print_banner() -> None:
    if sys.stderr.isatty():
        print(_LOGO, file=sys.stderr)
        print("\033[38;2;139;148;158m  Deterministic Execution Authority\033[0m", file=sys.stderr)
