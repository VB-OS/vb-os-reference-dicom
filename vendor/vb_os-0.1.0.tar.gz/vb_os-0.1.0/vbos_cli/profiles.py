"""Profile resolution: --profile flag > VBOS_PROFILE env > 'default'."""

from __future__ import annotations

import os

DEFAULT_PROFILE = "default"
PROFILE_ENV_VAR = "VBOS_PROFILE"


def resolve_profile(flag_value: str | None) -> str:
    """Return the active profile name from flag, env var, or default."""
    if flag_value:
        return flag_value
    return os.environ.get(PROFILE_ENV_VAR, DEFAULT_PROFILE)
